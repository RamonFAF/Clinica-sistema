import datetime as dt

import pyotp

from sqlalchemy import text

from app.db import SessionLocal

from .conftest import PWD, client, login, pid_of, png_bytes


def next_monday() -> str:
    d = dt.date.today()
    return (d + dt.timedelta(days=7 - d.weekday())).isoformat()


# ---------- autenticação e segurança ----------

def test_login_requires_mfa_setup_then_mfa_code():
    c = client()
    r = c.post("/api/auth/login", json={"email": "ana@t.local", "password": PWD})
    assert r.json()["mfa_setup_required"] is True
    assert c.get("/api/patients").status_code == 403  # bloqueado até ativar o 2FA
    secret = c.post("/api/auth/mfa/setup").json()["secret"]
    assert c.post("/api/auth/mfa/enable", json={"code": "000000"}).status_code == 400
    assert c.post("/api/auth/mfa/enable", json={"code": pyotp.TOTP(secret).now()}).status_code == 200
    assert c.get("/api/patients").status_code == 200
    # Novo login exige o código
    c2 = client()
    r = c2.post("/api/auth/login", json={"email": "ana@t.local", "password": PWD})
    assert r.json()["mfa_pending"] is True
    assert c2.get("/api/patients").status_code == 401
    assert c2.post("/api/auth/mfa", json={"code": pyotp.TOTP(secret).now()}).status_code == 200
    assert c2.get("/api/patients").status_code == 200


def test_wrong_password_and_lockout():
    c = client()
    for _ in range(5):
        assert c.post("/api/auth/login", json={"email": "ana@t.local", "password": "errada-123"}).status_code == 401
    r = c.post("/api/auth/login", json={"email": "ana@t.local", "password": PWD})
    assert r.status_code == 429


def test_unknown_email_same_message():
    r = client().post("/api/auth/login", json={"email": "ninguem@t.local", "password": "x"})
    assert r.status_code == 401 and r.json()["detail"] == "E-mail ou senha inválidos."


def test_csrf_header_required():
    c = login("ana@t.local")
    del c.headers["X-Requested-With"]
    assert c.post("/api/patients", json={"name": "X"}).status_code == 403


def test_logout_invalidates_session():
    c = login("ana@t.local")
    assert c.post("/api/auth/logout").status_code == 200
    assert c.get("/api/patients").status_code == 401


def test_temp_password_must_be_changed():
    a = login("admin@t.local")
    r = a.post("/api/professionals", json={"name": "Nova", "email": "nova@clinica-teste.com.br", "specialty": "Nutrição"})
    assert r.status_code == 200, r.text
    temp = r.json()["temp_password"]
    c = client()
    assert c.post("/api/auth/login", json={"email": "nova@clinica-teste.com.br", "password": temp}).json()["password_change_required"]
    assert c.get("/api/patients").status_code == 403
    assert c.post("/api/auth/password", json={"current_password": temp, "new_password": "curta"}).status_code == 400
    r = c.post("/api/auth/password", json={"current_password": temp, "new_password": "Outra-senha-forte-1"})
    assert r.status_code == 200 and not r.json()["password_change_required"]


# ---------- isolamento entre profissionais ----------

def test_professional_sees_only_own_patients_and_records():
    ana, beto = login("ana@t.local"), login("beto@t.local")
    p = ana.post("/api/patients", json={"name": "Paciente da Ana", "consent_care": True, "notes": "alergia"}).json()
    assert ana.post(f"/api/patients/{p['id']}/records", json={"content": "Sessão 1: queixa de ansiedade."}).status_code == 200
    assert beto.get("/api/patients").json() == []
    assert beto.get(f"/api/patients/{p['id']}").status_code == 404
    assert beto.get(f"/api/patients/{p['id']}/records").status_code == 403
    rec = login("rec@t.local")
    assert rec.get(f"/api/patients/{p['id']}").status_code == 200
    assert "notes" not in rec.get(f"/api/patients/{p['id']}").json()
    assert rec.get(f"/api/patients/{p['id']}/records").status_code == 403
    adm = login("admin@t.local")
    assert adm.get(f"/api/patients/{p['id']}/records").status_code == 403
    recs = ana.get(f"/api/patients/{p['id']}/records").json()["entries"]
    assert recs[0]["content"].startswith("Sessão 1")


def test_record_is_encrypted_at_rest():
    ana = login("ana@t.local")
    p = ana.post("/api/patients", json={"name": "Cifrado"}).json()
    ana.post(f"/api/patients/{p['id']}/records", json={"content": "TEXTO-SECRETO"})
    with SessionLocal() as db:
        raw = db.execute(text("select content from record_entries")).scalar()
    assert "TEXTO-SECRETO" not in raw and raw.startswith("gAAAA")


def test_export_patient():
    ana = login("ana@t.local")
    p = ana.post("/api/patients", json={"name": "Exporta"}).json()
    ana.post(f"/api/patients/{p['id']}/records", json={"content": "abc"})
    data = ana.get(f"/api/patients/{p['id']}/export").json()
    assert data["patient"]["name"] == "Exporta" and len(data["records"]) == 1


# ---------- salas, reservas e agenda ----------

def test_room_conflict_and_appointment_needs_room():
    adm, ana = login("admin@t.local"), login("ana@t.local")
    pid = pid_of(ana)
    rooms = adm.get("/api/rooms").json()
    day = next_monday()
    r = adm.post("/api/reservations", json={"room_id": rooms[0]["id"], "professional_id": pid, "date": day,
                                            "start": "08:00", "end": "12:00", "repeat_weeks": 3})
    assert r.status_code == 200 and len(r.json()) == 3
    beto_id = pid_of(login("beto@t.local"))
    r = adm.post("/api/reservations", json={"room_id": rooms[0]["id"], "professional_id": beto_id, "date": day,
                                            "start": "11:00", "end": "13:00"})
    assert r.status_code == 409
    pat = ana.post("/api/patients", json={"name": "P1"}).json()
    ok = ana.post("/api/appointments", json={"patient_id": pat["id"], "date": day, "start": "09:00", "end": "09:50", "price": 150})
    assert ok.status_code == 200
    clash = ana.post("/api/appointments", json={"patient_id": pat["id"], "date": day, "start": "09:30", "end": "10:20"})
    assert clash.status_code == 409
    no_room = ana.post("/api/appointments", json={"patient_id": pat["id"], "date": day, "start": "14:00", "end": "14:50"})
    assert no_room.status_code == 409
    online = ana.post("/api/appointments", json={"patient_id": pat["id"], "date": day, "start": "14:00", "end": "14:50",
                                                 "online": True})
    assert online.status_code == 200
    # Não deixa apagar a reserva com consulta presencial dentro
    res_id = r = adm.get(f"/api/reservations?date_from={day}&date_to={day}").json()[0]["id"]
    assert adm.delete(f"/api/reservations/{res_id}").status_code == 409


def test_outside_opening_hours_rejected():
    adm = login("admin@t.local")
    pid = pid_of(login("ana@t.local"))
    room = adm.get("/api/rooms").json()[0]["id"]
    r = adm.post("/api/reservations", json={"room_id": room, "professional_id": pid, "date": next_monday(),
                                            "start": "05:00", "end": "06:00"})
    assert r.status_code == 422


def test_set_room_count_and_settings():
    adm = login("admin@t.local")
    assert len(adm.post("/api/rooms/set-count", json={"count": 5}).json()) == 5
    assert len(adm.post("/api/rooms/set-count", json={"count": 3}).json()) == 3
    s = adm.put("/api/settings", json={"open_time": "08:00", "slot_minutes": "15", "clinic_name": "Teste"}).json()
    assert s["slot_minutes"] == 15 and s["clinic_name"] == "Teste"
    assert client().get("/api/public/branding").json()["clinic_name"] == "Teste"
    assert adm.put("/api/settings", json={"slot_minutes": 0}).status_code == 422
    assert adm.put("/api/settings", json={"open_time": "22:00", "close_time": "08:00"}).status_code == 422
    assert adm.put("/api/settings", json={"slot_minutes": "abc"}).status_code == 422
    ana = login("ana@t.local")
    assert ana.put("/api/settings", json={"clinic_name": "x"}).status_code == 403
    assert ana.post("/api/rooms/set-count", json={"count": 9}).status_code == 403


def test_photo_upload_and_logo():
    adm = login("admin@t.local")
    ana = login("ana@t.local")
    pid = pid_of(ana)
    r = ana.post(f"/api/professionals/{pid}/photo", files={"file": ("f.png", png_bytes(), "image/png")})
    assert r.status_code == 200 and r.json()["photo_url"].endswith(".webp")
    assert ana.get(r.json()["photo_url"]).status_code == 200
    assert client().get(r.json()["photo_url"]).status_code == 401  # foto exige login
    other = pid_of(login("beto@t.local"))
    assert ana.post(f"/api/professionals/{other}/photo", files={"file": ("f.png", png_bytes(), "image/png")}).status_code == 403
    bad = ana.post(f"/api/professionals/{pid}/photo", files={"file": ("f.png", b"not an image", "image/png")})
    assert bad.status_code == 415
    logo = adm.post("/api/settings/logo", files={"file": ("l.png", png_bytes(), "image/png")}).json()["logo_url"]
    assert client().get(logo).status_code == 200


def test_finance_invoice_and_statement():
    adm, ana = login("admin@t.local"), login("ana@t.local")
    pid = pid_of(ana)
    room = adm.get("/api/rooms").json()[0]
    day = next_monday()
    adm.post("/api/reservations", json={"room_id": room["id"], "professional_id": pid, "date": day, "start": "08:00", "end": "12:00"})
    pat = ana.post("/api/patients", json={"name": "P"}).json()
    a = ana.post("/api/appointments", json={"patient_id": pat["id"], "date": day, "start": "08:00", "end": "08:50",
                                            "price": 200}).json()[0]
    ana.patch(f"/api/appointments/{a['id']}", json={"paid": True, "payment_method": "pix"})
    month = day[:7]
    inv = [i for i in adm.get(f"/api/finance/invoices?month={month}").json() if i["professional_id"] == pid][0]
    assert inv["amount"] == 160 and inv["hours"] == 4
    assert adm.post(f"/api/finance/invoices/{pid}/{month}/pay").status_code == 200
    st = ana.get(f"/api/finance/statement?month={month}").json()
    assert st["received"] == 200 and st["room_cost"] == 160 and st["room_cost_paid"] is True
    assert ana.get(f"/api/finance/invoices?month={month}").status_code == 403


def test_dashboard_and_audit():
    adm, ana = login("admin@t.local"), login("ana@t.local")
    assert "rooms" in adm.get("/api/dashboard").json()
    assert "my_month" in ana.get("/api/dashboard").json()
    actions = {x["action"] for x in adm.get("/api/audit").json()}
    assert {"login", "mfa_enabled"} <= actions
    assert ana.get("/api/audit").status_code == 403
