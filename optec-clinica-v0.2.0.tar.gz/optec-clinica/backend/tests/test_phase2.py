"""Fase 2: equipe de cuidado, modelos, anexos, PDFs, confirmação pública, pacotes, despesas, lista de espera."""
import datetime as dt

from sqlalchemy import text

from app import config
from app.db import SessionLocal

from .conftest import client, login, pid_of
from .test_api import next_monday


def setup_patient(ana, **extra):
    return ana.post("/api/patients", json={"name": "Paciente Equipe", "consent_care": True, **extra}).json()


def book_room(adm, pid, day, start="08:00", end="12:00"):
    room = adm.get("/api/rooms").json()[0]["id"]
    r = adm.post("/api/reservations", json={"room_id": room, "professional_id": pid, "date": day, "start": start, "end": end})
    assert r.status_code == 200, r.text


def test_team_sharing_respects_consent_and_private_entries():
    ana, beto, rec = login("ana@t.local"), login("beto@t.local"), login("rec@t.local")
    p = setup_patient(ana)
    ana.post(f"/api/patients/{p['id']}/records", json={"content": "Registro de equipe", "visibility": "team"})
    ana.post(f"/api/patients/{p['id']}/records", json={"content": "Anotação privada", "visibility": "private"})
    assert beto.get(f"/api/patients/{p['id']}/records").status_code == 403  # ainda fora da equipe
    r = ana.post(f"/api/patients/{p['id']}/team", json={"professional_id": pid_of(beto)})
    assert pid_of(beto) in r.json()["team"]
    assert beto.get(f"/api/patients/{p['id']}/records").json()["entries"] == []  # sem consentimento compartilhado
    ana.put(f"/api/patients/{p['id']}", json={**p, "consent_shared": True})
    seen = [e["content"] for e in beto.get(f"/api/patients/{p['id']}/records").json()["entries"]]
    assert seen == ["Registro de equipe"]
    assert beto.post(f"/api/patients/{p['id']}/records", json={"content": "Evolução do Beto"}).status_code == 200
    assert len(ana.get(f"/api/patients/{p['id']}/records").json()["entries"]) == 3
    assert any(x["id"] == p["id"] for x in beto.get("/api/patients").json())
    assert rec.get(f"/api/patients/{p['id']}/records").status_code == 403
    assert beto.post(f"/api/patients/{p['id']}/team", json={"professional_id": pid_of(rec)}).status_code == 403


def test_structured_template_with_alerts():
    ana = login("ana@t.local")
    p = setup_patient(ana)
    tpls = ana.get("/api/patients/templates").json()
    assert {"anamnese_geral", "aval_psicologica", "aval_fisio", "pti", "evolucao_soap", "sessao_psico", "alta"} <= {t["key"] for t in tpls}
    r = ana.post(f"/api/patients/{p['id']}/records", json={"kind": "form", "template": "aval_psicologica",
                                                          "data": {"motivo": "Ansiedade", "phq9": 12, "ideacao": "yes"}}).json()
    assert r["title"] == "Avaliação psicológica" and "PHQ-9: 12" in r["content"]
    assert r["alerts"] == ["Ideação suicida?"]
    s = ana.post(f"/api/patients/{p['id']}/records", json={"kind": "form", "template": "sessao_psico", "data": {"demanda": "x"}}).json()
    assert s["visibility"] == "private"
    pti = ana.post(f"/api/patients/{p['id']}/records", json={"kind": "form", "template": "pti",
                   "data": {"plano": {"Psicologia": {"Objetivo principal": "Reduzir ansiedade", "Frequência": "semanal"}}}}).json()
    assert "Psicologia" in pti["content"]


def test_attachments_encrypted_and_restricted():
    ana, beto = login("ana@t.local"), login("beto@t.local")
    p = setup_patient(ana)
    pdf = b"%PDF-1.4\n% exame de teste\n%%EOF"
    r = ana.post(f"/api/patients/{p['id']}/attachments", files={"file": ("exame.pdf", pdf, "application/pdf")}, data={"visibility": "team"})
    assert r.status_code == 200, r.text
    aid = r.json()["id"]
    stored = list((config.UPLOAD_DIR / "attachments").glob("*.bin"))
    assert stored and all(b"exame de teste" not in f.read_bytes() for f in stored)
    assert ana.get(f"/api/patients/{p['id']}/attachments/{aid}").content == pdf
    assert beto.get(f"/api/patients/{p['id']}/attachments/{aid}").status_code == 403
    bad = ana.post(f"/api/patients/{p['id']}/attachments", files={"file": ("x.exe", b"MZ....", "application/pdf")})
    assert bad.status_code == 415


def test_pdfs():
    adm, ana = login("admin@t.local"), login("ana@t.local")
    pid = pid_of(ana)
    p = setup_patient(ana, cpf="000.000.000-00")
    ana.post(f"/api/patients/{p['id']}/records", json={"kind": "form", "template": "evolucao_soap", "data": {"s": "Bem", "eva": 3}})
    r = ana.get(f"/api/patients/{p['id']}/record.pdf")
    assert r.status_code == 200 and r.content.startswith(b"%PDF")
    day = next_monday()
    book_room(adm, pid, day)
    a = ana.post("/api/appointments", json={"patient_id": p["id"], "date": day, "start": "08:00", "end": "08:50", "price": 180,
                                            "paid": True, "payment_method": "pix"}).json()[0]
    assert ana.get(f"/api/finance/receipt/appointment/{a['id']}.pdf").content.startswith(b"%PDF")
    assert ana.get(f"/api/appointments/{a['id']}/attendance.pdf").content.startswith(b"%PDF")
    assert login("beto@t.local").get(f"/api/appointments/{a['id']}/attendance.pdf").status_code == 404


def test_public_confirmation_link():
    adm, ana = login("admin@t.local"), login("ana@t.local")
    pid = pid_of(ana)
    p = setup_patient(ana)
    day = next_monday()
    book_room(adm, pid, day)
    a = ana.post("/api/appointments", json={"patient_id": p["id"], "date": day, "start": "09:00", "end": "09:50"}).json()[0]
    token = ana.get(f"/api/appointments/{a['id']}/confirm-link").json()["token"]
    anon = client()
    v = anon.get(f"/api/public/appointment/{token}").json()
    assert v["patient_first_name"] == "Paciente" and v["start"] == "09:00" and "notes" not in v
    assert anon.post(f"/api/public/appointment/{token}/confirm").json()["status"] == "confirmed"
    assert anon.get("/api/public/appointment/token-invalido-123456789").status_code == 404
    anon.post(f"/api/public/appointment/{token}/reschedule")
    dash = ana.get("/api/dashboard").json()
    assert any(x["id"] == a["id"] for x in dash["reschedule_requests"]) or dash["date"] != day
    assert ana.post(f"/api/appointments/{a['id']}/reminder-sent").json()["reminder_sent_at"]


def test_packages_consume_sessions_and_count_as_revenue():
    adm, ana = login("admin@t.local"), login("ana@t.local")
    pid = pid_of(ana)
    p = setup_patient(ana)
    k = ana.post("/api/packages", json={"patient_id": p["id"], "name": "Pacote 2", "sessions_total": 2, "price": 300,
                                        "paid": True, "payment_method": "pix"}).json()
    day = next_monday()
    book_room(adm, pid, day)
    for h in ("08:00", "09:00"):
        r = ana.post("/api/appointments", json={"patient_id": p["id"], "date": day, "start": h, "end": h[:3] + "50",
                                                "price": 150, "package_id": k["id"]})
        assert r.status_code == 200, r.text
    third = ana.post("/api/appointments", json={"patient_id": p["id"], "date": day, "start": "10:00", "end": "10:50", "package_id": k["id"]})
    assert third.status_code == 409
    assert ana.get(f"/api/packages?patient_id={p['id']}").json()[0]["left"] == 0
    st = ana.get(f"/api/finance/statement?month={dt.date.today():%Y-%m}").json()
    assert st["received"] >= 300 and st["packages_sold"][0]["price"] == 300
    assert ana.get(f"/api/finance/receipt/package/{k['id']}.pdf").content.startswith(b"%PDF")


def test_expenses_adjustments_overview_and_csv():
    adm, ana = login("admin@t.local"), login("ana@t.local")
    month = dt.date.today().strftime("%Y-%m")
    r = adm.post("/api/finance/expenses", json={"scope": "clinic", "date": f"{month}-05", "description": "Aluguel do prédio",
                                                "category": "Aluguel do imóvel", "amount": 2500, "repeat_months": 3})
    assert len(r.json()) == 3
    assert ana.post("/api/finance/expenses", json={"scope": "clinic", "date": f"{month}-05", "description": "x", "category": "Outros",
                                                   "amount": 1}).status_code == 403
    assert ana.post("/api/finance/expenses", json={"scope": "mine", "date": f"{month}-05", "description": "Supervisão",
                                                   "category": "Supervisão", "amount": 200}).status_code == 200
    pid = pid_of(ana)
    book_room(adm, pid, next_monday() if next_monday()[:7] == month else f"{month}-{min(28, dt.date.today().day):02d}")
    inv = [i for i in adm.get(f"/api/finance/invoices?month={month}").json() if i["professional_id"] == pid]
    if inv:
        before = inv[0]["amount"]
        adm.post(f"/api/finance/invoices/{pid}/{month}/adjustments", json={"description": "Desconto parceria", "amount": -10})
        after = adm.get(f"/api/finance/invoices/{pid}/{month}").json()
        assert after["amount"] == before - 10 and after["adjustments"][0]["description"] == "Desconto parceria"
    ov = adm.get(f"/api/finance/overview?month={month}").json()
    assert ov["expenses"] == 2500 and len(ov["series"]) == 6
    csv_r = adm.get(f"/api/finance/export.csv?month={month}")
    assert csv_r.status_code == 200 and "Aluguel do prédio" in csv_r.text
    st = ana.get(f"/api/finance/statement?month={month}").json()
    assert st["expenses"] == 200
    assert ana.get(f"/api/finance/statement.csv?month={month}").status_code == 200


def test_staff_scheduling_adds_professional_to_team_and_waitlist():
    adm, ana, beto = login("admin@t.local"), login("ana@t.local"), login("beto@t.local")
    p = setup_patient(ana)
    day = next_monday()
    book_room(adm, pid_of(beto), day)
    r = adm.post("/api/appointments", json={"patient_id": p["id"], "professional_id": pid_of(beto), "date": day,
                                            "start": "08:00", "end": "08:50"})
    assert r.status_code == 200, r.text
    assert pid_of(beto) in ana.get(f"/api/patients/{p['id']}").json()["team"]
    w = beto.post("/api/waitlist", json={"name": "Interessado", "phone": "11999999999", "preference": "terças à tarde"}).json()
    assert w["professional_id"] == pid_of(beto)
    assert any(x["id"] == w["id"] for x in adm.get("/api/waitlist").json())
    assert not any(x["id"] == w["id"] for x in ana.get("/api/waitlist").json())


def test_old_entries_migrated_private():
    with SessionLocal() as db:
        assert db.execute(text("select 1")).scalar() == 1
