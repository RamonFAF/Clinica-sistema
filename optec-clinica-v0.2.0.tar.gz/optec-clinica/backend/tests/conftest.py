import io
import os

import pyotp
import pytest
from cryptography.fernet import Fernet

# Segurança: os testes APAGAM o banco. Usam só TEST_DATABASE_URL (ou o padrão local) e exigem nome terminado em _test,
# para nunca rodar contra o banco de produção mesmo que DATABASE_URL esteja definido no ambiente.
os.environ["DATABASE_URL"] = os.environ.get("TEST_DATABASE_URL", "postgresql+psycopg://clinica:clinica@localhost:5432/clinica_test")
if not os.environ["DATABASE_URL"].rsplit("/", 1)[-1].endswith("_test"):
    raise SystemExit("Recusado: o banco de testes precisa ter nome terminado em _test (TEST_DATABASE_URL).")
os.environ.setdefault("ENCRYPTION_KEY", Fernet.generate_key().decode())
os.environ["UPLOAD_DIR"] = "/tmp/clinica-test-uploads"

from fastapi.testclient import TestClient  # noqa: E402

from app import models  # noqa: E402,F401
from app.db import Base, SessionLocal, engine  # noqa: E402
from app.main import app  # noqa: E402
from app.models import Professional, Room, User  # noqa: E402
from app.security import hash_password  # noqa: E402

PWD = "Senha-forte-123"
H = {"X-Requested-With": "fetch"}


@pytest.fixture(autouse=True)
def fresh_db():
    Base.metadata.drop_all(engine)
    Base.metadata.create_all(engine)
    with SessionLocal() as db:
        for email, role, attends in (("admin@t.local", "admin", False), ("ana@t.local", "professional", True),
                                     ("beto@t.local", "professional", True), ("rec@t.local", "reception", False)):
            u = User(email=email, name=email.split("@")[0].title(), role=role, password_hash=hash_password(PWD),
                     must_change_password=False)
            db.add_all([u, Professional(user=u, attends=attends, specialty="Psicologia")])
        db.add_all([Room(name="Sala 1", hourly_rate=40, sort_order=1), Room(name="Sala 2", hourly_rate=50, sort_order=2)])
        db.commit()
    yield


def client() -> TestClient:
    return TestClient(app, base_url="https://testserver", headers=H)


def login(email: str, mfa: bool = True) -> TestClient:
    """Faz login completo, configurando o 2FA na primeira vez."""
    c = client()
    r = c.post("/api/auth/login", json={"email": email, "password": PWD})
    assert r.status_code == 200, r.text
    if mfa and r.json()["mfa_setup_required"]:
        secret = c.post("/api/auth/mfa/setup").json()["secret"]
        r = c.post("/api/auth/mfa/enable", json={"code": pyotp.TOTP(secret).now()})
        assert r.status_code == 200, r.text
        c.secret = secret
    return c


def pid_of(c: TestClient) -> int:
    return c.get("/api/auth/me").json()["user"]["professional_id"]


def png_bytes() -> io.BytesIO:
    from PIL import Image
    buf = io.BytesIO()
    Image.new("RGB", (900, 600), (20, 120, 110)).save(buf, "PNG")
    buf.seek(0)
    return buf
