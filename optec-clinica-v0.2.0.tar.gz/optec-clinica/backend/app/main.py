from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from starlette.exceptions import HTTPException as StarletteHTTPException

from . import config
from .api import (admin, appointments, auth, dashboard, finance, packages, patients, professionals, public,
                  reservations, rooms, waitlist)

app = FastAPI(title="Clínica", version=config.VERSION, docs_url=None, redoc_url=None, openapi_url=None)

for r in (auth, professionals, rooms, reservations, patients, appointments, finance, dashboard, admin, packages,
          waitlist, public):
    app.include_router(r.router, prefix="/api")


@app.middleware("http")
async def security_headers(request: Request, call_next):
    response = await call_next(request)
    h = response.headers
    h.setdefault("X-Content-Type-Options", "nosniff")
    h.setdefault("X-Frame-Options", "DENY")
    h.setdefault("Referrer-Policy", "same-origin")
    h.setdefault("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
    h.setdefault("Content-Security-Policy",
                 "default-src 'self'; img-src 'self' data: blob:; style-src 'self' 'unsafe-inline'; "
                 "font-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'")
    if request.url.path.startswith("/api/"):
        h.setdefault("Cache-Control", "no-store")
    return response


@app.exception_handler(StarletteHTTPException)
async def http_error(request: Request, exc: StarletteHTTPException):
    detail = exc.detail
    if isinstance(detail, dict):
        body = {"detail": detail.get("message"), "code": detail.get("code")}
    else:
        body = {"detail": detail, "code": None}
    return JSONResponse(body, status_code=exc.status_code, headers=getattr(exc, "headers", None))


FIELD_NAMES = {"email": "E-mail", "name": "Nome", "date": "Data", "start": "Início", "end": "Fim", "price": "Valor"}


@app.exception_handler(RequestValidationError)
async def validation_error(request: Request, exc: RequestValidationError):
    first = exc.errors()[0] if exc.errors() else {}
    field = str(first.get("loc", ["", ""])[-1])
    label = FIELD_NAMES.get(field, field)
    msg = "E-mail inválido." if field == "email" else f"Campo inválido: {label}."
    return JSONResponse({"detail": msg, "code": "validation_error"}, status_code=422)


@app.get("/api/health")
def health():
    return {"ok": True, "version": config.VERSION}


# Front-end (build do React) servido pelo mesmo processo; rotas desconhecidas caem no index.html (SPA).
if (config.STATIC_DIR / "index.html").exists():
    app.mount("/assets", StaticFiles(directory=config.STATIC_DIR / "assets"), name="assets")

    @app.api_route("/{path:path}", methods=["GET", "HEAD"], include_in_schema=False)
    def spa(path: str):
        if path.startswith("api/"):
            return JSONResponse({"detail": "Não encontrado"}, status_code=404)
        candidate = (config.STATIC_DIR / path).resolve()
        if path and candidate.is_file() and config.STATIC_DIR.resolve() in candidate.parents:
            return FileResponse(candidate)
        return FileResponse(config.STATIC_DIR / "index.html", headers={"Cache-Control": "no-cache"})
