"""Senhas (Argon2id), tokens de sessão e 2FA (TOTP)."""
import base64
import hashlib
import io
import secrets

import pyotp
import segno
from argon2 import PasswordHasher
from argon2.exceptions import InvalidHashError, VerificationError

_ph = PasswordHasher()
# Hash fixo usado quando o e-mail não existe, para o tempo de resposta não revelar contas.
_DUMMY_HASH = _ph.hash("dummy-password-for-timing")


def hash_password(password: str) -> str:
    return _ph.hash(password)


def verify_password(password: str, hashed: str | None) -> bool:
    try:
        return _ph.verify(hashed or _DUMMY_HASH, password) and hashed is not None
    except (VerificationError, InvalidHashError):
        return False


def password_problem(password: str, min_length: int) -> str | None:
    if len(password) < min_length:
        return f"A senha precisa ter pelo menos {min_length} caracteres."
    if password.isdigit() or password.isalpha():
        return "Use letras e números (ou símbolos) na senha."
    return None


def new_token() -> str:
    return secrets.token_urlsafe(32)


def token_hash(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


def temp_password() -> str:
    return secrets.token_urlsafe(9) + "7a"


def new_totp_secret() -> str:
    return pyotp.random_base32()


def totp_uri(secret: str, email: str, issuer: str) -> str:
    return pyotp.TOTP(secret).provisioning_uri(name=email, issuer_name=issuer)


def totp_qr_data_uri(uri: str) -> str:
    buf = io.BytesIO()
    segno.make(uri, error="m").save(buf, kind="png", scale=6, border=2, dark="#1e1b4b", light="#ffffff")
    return "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode()


def verify_totp(secret: str | None, code: str) -> bool:
    if not secret:
        return False
    code = "".join(ch for ch in code if ch.isdigit())
    return len(code) == 6 and pyotp.TOTP(secret).verify(code, valid_window=1)
