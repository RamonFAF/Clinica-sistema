import datetime as dt

from sqlalchemy import (Boolean, Date, DateTime, Float, ForeignKey, Integer, String, Text, Time,
                        UniqueConstraint, func)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .crypto import EncryptedText
from .db import Base


def now() -> dt.datetime:
    return dt.datetime.now(dt.timezone.utc)


class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(primary_key=True)
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True)
    name: Mapped[str] = mapped_column(String(200))
    password_hash: Mapped[str] = mapped_column(String(255))
    role: Mapped[str] = mapped_column(String(20), default="professional")  # admin | reception | professional
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    must_change_password: Mapped[bool] = mapped_column(Boolean, default=True)
    totp_secret: Mapped[str | None] = mapped_column(EncryptedText, nullable=True)
    totp_enabled: Mapped[bool] = mapped_column(Boolean, default=False)
    failed_logins: Mapped[int] = mapped_column(Integer, default=0)
    locked_until: Mapped[dt.datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    last_login_at: Mapped[dt.datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    created_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=now, server_default=func.now())
    professional: Mapped["Professional | None"] = relationship(back_populates="user", uselist=False)


class UserSession(Base):
    __tablename__ = "user_sessions"
    id: Mapped[int] = mapped_column(primary_key=True)
    token_hash: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    mfa_passed: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=now)
    last_seen_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=now)
    expires_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True))
    ip: Mapped[str | None] = mapped_column(String(64), nullable=True)
    user_agent: Mapped[str | None] = mapped_column(String(300), nullable=True)
    user: Mapped[User] = relationship()


class Professional(Base):
    __tablename__ = "professionals"
    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), unique=True)
    council: Mapped[str | None] = mapped_column(String(80), nullable=True)  # ex.: CRP 06/123456
    document: Mapped[str | None] = mapped_column(String(30), nullable=True)  # CPF/CNPJ para recibos
    specialty: Mapped[str | None] = mapped_column(String(120), nullable=True)
    phone: Mapped[str | None] = mapped_column(String(30), nullable=True)
    photo: Mapped[str | None] = mapped_column(String(120), nullable=True)
    color: Mapped[str] = mapped_column(String(9), default="#0f766e")
    billing_model: Mapped[str] = mapped_column(String(20), default="hourly")  # hourly | monthly | percent
    monthly_fee: Mapped[float] = mapped_column(Float, default=0)
    percent: Mapped[float] = mapped_column(Float, default=0)
    bio: Mapped[str | None] = mapped_column(Text, nullable=True)
    attends: Mapped[bool] = mapped_column(Boolean, default=True)  # atende pacientes (aparece na agenda)
    user: Mapped[User] = relationship(back_populates="professional")


class Room(Base):
    __tablename__ = "rooms"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(80))
    resources: Mapped[str | None] = mapped_column(String(300), nullable=True)
    area_m2: Mapped[float] = mapped_column(Float, default=0)
    hourly_rate: Mapped[float] = mapped_column(Float, default=0)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    sort_order: Mapped[int] = mapped_column(Integer, default=0)


class Reservation(Base):
    __tablename__ = "reservations"
    id: Mapped[int] = mapped_column(primary_key=True)
    room_id: Mapped[int] = mapped_column(ForeignKey("rooms.id", ondelete="CASCADE"), index=True)
    professional_id: Mapped[int] = mapped_column(ForeignKey("professionals.id", ondelete="CASCADE"), index=True)
    date: Mapped[dt.date] = mapped_column(Date, index=True)
    start: Mapped[dt.time] = mapped_column(Time)
    end: Mapped[dt.time] = mapped_column(Time)
    series_id: Mapped[str | None] = mapped_column(String(36), nullable=True, index=True)
    notes: Mapped[str | None] = mapped_column(String(300), nullable=True)


class Patient(Base):
    __tablename__ = "patients"
    id: Mapped[int] = mapped_column(primary_key=True)
    professional_id: Mapped[int] = mapped_column(ForeignKey("professionals.id", ondelete="RESTRICT"), index=True)
    name: Mapped[str] = mapped_column(String(200))
    phone: Mapped[str | None] = mapped_column(String(30), nullable=True)
    email: Mapped[str | None] = mapped_column(String(255), nullable=True)
    birth_date: Mapped[dt.date | None] = mapped_column(Date, nullable=True)
    cpf: Mapped[str | None] = mapped_column(EncryptedText, nullable=True)
    rg: Mapped[str | None] = mapped_column(EncryptedText, nullable=True)
    sex: Mapped[str | None] = mapped_column(String(30), nullable=True)
    marital_status: Mapped[str | None] = mapped_column(String(30), nullable=True)
    occupation: Mapped[str | None] = mapped_column(String(120), nullable=True)
    address: Mapped[str | None] = mapped_column(EncryptedText, nullable=True)
    insurance: Mapped[str | None] = mapped_column(String(120), nullable=True)  # convênio
    guardian: Mapped[str | None] = mapped_column(String(200), nullable=True)  # responsável (menor)
    notes: Mapped[str | None] = mapped_column(EncryptedText, nullable=True)  # alergias, alertas
    consent_care: Mapped[bool] = mapped_column(Boolean, default=False)  # termo de consentimento
    consent_ehr: Mapped[bool] = mapped_column(Boolean, default=False)  # prontuário eletrônico
    consent_shared: Mapped[bool] = mapped_column(Boolean, default=False)  # evolução compartilhada na equipe
    consent_whatsapp: Mapped[bool] = mapped_column(Boolean, default=False)
    consent_at: Mapped[dt.datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    archived: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=now)


class Appointment(Base):
    __tablename__ = "appointments"
    id: Mapped[int] = mapped_column(primary_key=True)
    patient_id: Mapped[int] = mapped_column(ForeignKey("patients.id", ondelete="CASCADE"), index=True)
    professional_id: Mapped[int] = mapped_column(ForeignKey("professionals.id", ondelete="CASCADE"), index=True)
    date: Mapped[dt.date] = mapped_column(Date, index=True)
    start: Mapped[dt.time] = mapped_column(Time)
    end: Mapped[dt.time] = mapped_column(Time)
    price: Mapped[float] = mapped_column(Float, default=0)
    status: Mapped[str] = mapped_column(String(20), default="scheduled")  # scheduled|confirmed|done|no_show|canceled
    online: Mapped[bool] = mapped_column(Boolean, default=False)
    paid: Mapped[bool] = mapped_column(Boolean, default=False)
    payment_method: Mapped[str | None] = mapped_column(String(30), nullable=True)
    paid_at: Mapped[dt.datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    notes: Mapped[str | None] = mapped_column(String(300), nullable=True)
    package_id: Mapped[int | None] = mapped_column(ForeignKey("session_packages.id", ondelete="SET NULL"), nullable=True)
    confirm_token: Mapped[str | None] = mapped_column(String(64), nullable=True, unique=True, index=True)
    reminder_sent_at: Mapped[dt.datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    patient_response: Mapped[str | None] = mapped_column(String(20), nullable=True)  # confirmed | reschedule
    patient_response_at: Mapped[dt.datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    patient: Mapped[Patient] = relationship()


class RecordEntry(Base):
    """Registro de prontuário. Imutável: correções viram adendos (parent_id)."""

    __tablename__ = "record_entries"
    id: Mapped[int] = mapped_column(primary_key=True)
    patient_id: Mapped[int] = mapped_column(ForeignKey("patients.id", ondelete="CASCADE"), index=True)
    professional_id: Mapped[int] = mapped_column(ForeignKey("professionals.id", ondelete="RESTRICT"), index=True)
    kind: Mapped[str] = mapped_column(String(20), default="note")  # note | soap | addendum | form
    template: Mapped[str | None] = mapped_column(String(40), nullable=True)  # chave do modelo (record_templates)
    visibility: Mapped[str] = mapped_column(String(10), default="team")  # team | private (só o autor)
    title: Mapped[str | None] = mapped_column(String(200), nullable=True)
    content: Mapped[str] = mapped_column(EncryptedText)  # texto (livre ou resumo do formulário)
    data: Mapped[str | None] = mapped_column(EncryptedText, nullable=True)  # JSON do formulário
    parent_id: Mapped[int | None] = mapped_column(ForeignKey("record_entries.id"), nullable=True)
    created_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=now)


class PatientTeam(Base):
    """Profissionais da equipe de cuidado do paciente (além do responsável)."""

    __tablename__ = "patient_team"
    __table_args__ = (UniqueConstraint("patient_id", "professional_id"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    patient_id: Mapped[int] = mapped_column(ForeignKey("patients.id", ondelete="CASCADE"), index=True)
    professional_id: Mapped[int] = mapped_column(ForeignKey("professionals.id", ondelete="CASCADE"), index=True)
    added_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=now)


class Attachment(Base):
    """Arquivo do prontuário (exame, laudo, imagem). Guardado cifrado no disco."""

    __tablename__ = "attachments"
    id: Mapped[int] = mapped_column(primary_key=True)
    patient_id: Mapped[int] = mapped_column(ForeignKey("patients.id", ondelete="CASCADE"), index=True)
    professional_id: Mapped[int] = mapped_column(ForeignKey("professionals.id", ondelete="RESTRICT"))
    entry_id: Mapped[int | None] = mapped_column(ForeignKey("record_entries.id", ondelete="SET NULL"), nullable=True)
    filename: Mapped[str] = mapped_column(EncryptedText)
    mime: Mapped[str] = mapped_column(String(80))
    size: Mapped[int] = mapped_column(Integer)
    stored_name: Mapped[str] = mapped_column(String(80))
    visibility: Mapped[str] = mapped_column(String(10), default="team")
    created_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=now)


class SessionPackage(Base):
    """Pacote de sessões pago de uma vez (ex.: 10 sessões)."""

    __tablename__ = "session_packages"
    id: Mapped[int] = mapped_column(primary_key=True)
    patient_id: Mapped[int] = mapped_column(ForeignKey("patients.id", ondelete="CASCADE"), index=True)
    professional_id: Mapped[int] = mapped_column(ForeignKey("professionals.id", ondelete="CASCADE"), index=True)
    name: Mapped[str] = mapped_column(String(120))
    sessions_total: Mapped[int] = mapped_column(Integer)
    price: Mapped[float] = mapped_column(Float)
    paid: Mapped[bool] = mapped_column(Boolean, default=False)
    paid_at: Mapped[dt.datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    payment_method: Mapped[str | None] = mapped_column(String(30), nullable=True)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=now)


class Expense(Base):
    """Despesa da clínica (professional_id nulo) ou do próprio profissional."""

    __tablename__ = "expenses"
    id: Mapped[int] = mapped_column(primary_key=True)
    professional_id: Mapped[int | None] = mapped_column(ForeignKey("professionals.id", ondelete="CASCADE"), nullable=True, index=True)
    date: Mapped[dt.date] = mapped_column(Date, index=True)
    description: Mapped[str] = mapped_column(String(200))
    category: Mapped[str] = mapped_column(String(40))
    amount: Mapped[float] = mapped_column(Float)
    paid: Mapped[bool] = mapped_column(Boolean, default=True)
    series_id: Mapped[str | None] = mapped_column(String(36), nullable=True)
    created_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=now)


class WaitlistEntry(Base):
    __tablename__ = "waitlist"
    id: Mapped[int] = mapped_column(primary_key=True)
    professional_id: Mapped[int | None] = mapped_column(ForeignKey("professionals.id", ondelete="SET NULL"), nullable=True, index=True)
    patient_id: Mapped[int | None] = mapped_column(ForeignKey("patients.id", ondelete="SET NULL"), nullable=True)
    name: Mapped[str] = mapped_column(String(200))
    phone: Mapped[str | None] = mapped_column(String(30), nullable=True)
    specialty: Mapped[str | None] = mapped_column(String(120), nullable=True)
    preference: Mapped[str | None] = mapped_column(String(200), nullable=True)  # dias/horários
    notes: Mapped[str | None] = mapped_column(String(300), nullable=True)
    status: Mapped[str] = mapped_column(String(20), default="waiting")  # waiting | contacted | scheduled | gave_up
    created_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=now)


class InvoicePayment(Base):
    __tablename__ = "invoice_payments"
    __table_args__ = (UniqueConstraint("professional_id", "month"),)
    id: Mapped[int] = mapped_column(primary_key=True)
    professional_id: Mapped[int] = mapped_column(ForeignKey("professionals.id", ondelete="CASCADE"))
    month: Mapped[str] = mapped_column(String(7))  # AAAA-MM
    amount: Mapped[float] = mapped_column(Float, default=0)
    payment_method: Mapped[str | None] = mapped_column(String(30), nullable=True)
    paid_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=now)


class InvoiceAdjustment(Base):
    """Desconto (valor negativo) ou acréscimo na fatura de aluguel do mês."""

    __tablename__ = "invoice_adjustments"
    id: Mapped[int] = mapped_column(primary_key=True)
    professional_id: Mapped[int] = mapped_column(ForeignKey("professionals.id", ondelete="CASCADE"), index=True)
    month: Mapped[str] = mapped_column(String(7), index=True)
    description: Mapped[str] = mapped_column(String(200))
    amount: Mapped[float] = mapped_column(Float)


class Setting(Base):
    __tablename__ = "settings"
    key: Mapped[str] = mapped_column(String(80), primary_key=True)
    value: Mapped[str] = mapped_column(Text)  # JSON


class AuditLog(Base):
    __tablename__ = "audit_logs"
    id: Mapped[int] = mapped_column(primary_key=True)
    at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=now, index=True)
    user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id", ondelete="SET NULL"), nullable=True, index=True)
    action: Mapped[str] = mapped_column(String(60))
    entity: Mapped[str | None] = mapped_column(String(40), nullable=True)
    entity_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    ip: Mapped[str | None] = mapped_column(String(64), nullable=True)
    detail: Mapped[str | None] = mapped_column(String(500), nullable=True)
