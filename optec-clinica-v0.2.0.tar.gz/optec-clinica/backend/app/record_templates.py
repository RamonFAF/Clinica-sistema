"""Modelos de prontuário.

Baseados no prontuário multiprofissional da NeuroInsight (seções 3 a 9), na Resolução COFFITO 414/2012
(fisioterapia: história clínica, exame físico-funcional, exames complementares, diagnóstico e prognóstico,
plano e evolução) e na Resolução CFP 01/2009 (psicologia: registro documental; em equipe multiprofissional,
compartilhar só o necessário — por isso a sessão de psicoterapia nasce como "privada").

Tipos de campo: text, textarea, number, scale (0–10), select, multi (várias opções), yesno, date, table.
"""

AREAS = ["Psicologia", "Nutrição", "Terapias Corporais", "Fisioterapia", "Outros"]


def t(key, label, type_="textarea", **kw):
    return {"key": key, "label": label, "type": type_, **kw}


TEMPLATES: list[dict] = [
    {
        "key": "anamnese_geral", "name": "Anamnese geral multiprofissional", "area": "Geral", "visibility": "team",
        "fields": [
            t("queixa", "Queixa principal (com as palavras do paciente)"),
            t("historia_queixa", "História da queixa atual — início, frequência, fatores de piora/melhora"),
            t("historia_medica", "História médica pregressa — doenças, cirurgias, internações"),
            t("medicacoes", "Medicações em uso contínuo e alergias"),
            t("historia_familiar", "História familiar relevante (saúde mental, doenças crônicas)"),
            t("sono", "Sono — horas, qualidade, insônia, ronco, higiene do sono"),
            t("alimentacao", "Alimentação — rotina, apetite, compulsão, relação com comida"),
            t("atividade_fisica", "Atividade física — tipo, frequência"),
            t("substancias", "Uso de álcool, tabaco, cafeína, outras substâncias"),
            t("rede_apoio", "Rede de apoio — família, amigos, trabalho, lazer, religiosidade"),
        ],
    },
    {
        "key": "aval_psicologica", "name": "Avaliação psicológica", "area": "Psicologia", "visibility": "team",
        "fields": [
            t("motivo", "Motivo da busca por terapia"),
            t("sintomas", "Sintomas emocionais atuais (humor, ansiedade, irritabilidade, choro, anedonia, fadiga)"),
            t("phq9", "PHQ-9", "number", min=0, max=27, half=True),
            t("gad7", "GAD-7", "number", min=0, max=21, half=True),
            t("pss", "Escala de Estresse Percebido", "number", min=0, max=56, half=True),
            t("escalas_outras", "Outras escalas", "text", half=True),
            t("historico_saude_mental", "Histórico de saúde mental — tratamentos anteriores, internações, medicação psiquiátrica"),
            t("historia_vida", "História de vida e desenvolvimento — infância, traumas, vínculos, eventos marcantes"),
            t("rotina", "Rotina e funcionamento atual — trabalho, estudos, relacionamentos, autocuidado"),
            t("ideacao", "Ideação suicida?", "yesno", half=True, alert="yes"),
            t("plano_suicida", "Plano?", "yesno", half=True, alert="yes"),
            t("risco_protecao", "Fatores de risco e proteção — detalhes"),
            t("recursos", "Recursos internos, crenças centrais, padrão de apego observado"),
            t("hipotese", "Hipótese diagnóstica (CID-11/DSM-5-TR) — impressão clínica"),
            t("objetivos", "Objetivos terapêuticos acordados com o paciente"),
        ],
    },
    {
        "key": "aval_nutricional", "name": "Avaliação nutricional e comportamento alimentar", "area": "Nutrição", "visibility": "team",
        "fields": [
            t("queixa", "Queixa nutricional principal"),
            t("peso_atual", "Peso atual (kg)", "number", half=True),
            t("altura", "Altura (m)", "number", half=True),
            t("historico_peso", "Histórico de peso — peso habitual, oscilações"),
            t("recordatorio", "Recordatório 24h e padrão alimentar semanal"),
            t("comportamento", "Comportamento alimentar — beliscar, comer escondido, restrição, culpa, fome emocional vs. física"),
            t("ecap", "Escala de Compulsão Alimentar (ECAP)", "number", min=0, max=46, half=True),
            t("eat26", "EAT-26", "number", min=0, max=78, half=True),
            t("alergias", "Alergias, intolerâncias, aversões, dietas anteriores"),
            t("imagem_corporal", "Relação com corpo e imagem corporal"),
            t("objetivo", "Objetivo nutricional — sem dieta punitiva, foco em paz com a comida"),
        ],
    },
    {
        "key": "aval_corporal", "name": "Avaliação de terapias corporais integrativas", "area": "Terapias Corporais", "visibility": "team",
        "fields": [
            t("indicacao", "Indicação", "multi", options=["Ventosaterapia", "Liberação miofascial", "Massagem relaxante", "Outra"]),
            t("indicacao_outra", "Outra indicação", "text"),
            t("queixa", "Queixa corporal principal — dor, tensão, rigidez, fadiga muscular"),
            t("localizacao", "Localização da dor/tensão"),
            t("eva", "Escala de dor EVA (0–10)", "scale", half=True),
            t("tempo_dor", "Tempo de dor", "text", half=True),
            t("fatores", "Fatores de piora/melhora"),
            t("historico", "Histórico de lesões, cirurgias ortopédicas, hérnias, problemas circulatórios"),
            t("contraindicacoes", "Contraindicações verificadas", "multi",
              options=["Gestação", "Febre", "Trombose", "Feridas", "Câncer ativo", "Uso de anticoagulante", "Nenhuma"], alert_any=True),
            t("palpacao", "Palpação e avaliação — pontos de tensão, trigger points, amplitude de movimento"),
            t("objetivo", "Objetivo corporal e frequência recomendada"),
        ],
    },
    {
        "key": "aval_fisio", "name": "Avaliação fisioterapêutica", "area": "Fisioterapia", "visibility": "team",
        "fields": [
            t("queixa", "Queixa principal"),
            t("hda", "História da doença atual"),
            t("historia_pregressa", "História pregressa, cirurgias, comorbidades e medicações"),
            t("eva", "Dor — EVA (0–10)", "scale", half=True),
            t("local_dor", "Localização e característica da dor", "text", half=True),
            t("inspecao", "Inspeção e postura"),
            t("palpacao", "Palpação"),
            t("adm", "Amplitude de movimento (goniometria)"),
            t("forca", "Força muscular (escala de Oxford 0–5)"),
            t("testes", "Testes especiais e funcionais"),
            t("exames", "Exames complementares"),
            t("diagnostico", "Diagnóstico cinesiológico funcional"),
            t("prognostico", "Prognóstico"),
            t("objetivos", "Objetivos terapêuticos (curto e longo prazo)"),
            t("plano", "Plano de tratamento — condutas, frequência e número de sessões previstas"),
        ],
    },
    {
        "key": "pti", "name": "Plano terapêutico integrado (PTI)", "area": "Geral", "visibility": "team",
        "hint": "Construído em equipe, centrado no paciente, revisado a cada 90 dias.",
        "fields": [
            t("plano", "Plano por área", "table", rows=AREAS, cols=["Objetivo principal", "Intervenção", "Frequência", "Responsável"]),
            t("interconsulta", "Interconsulta necessária?", "yesno"),
            t("interconsulta_detalhe", "Detalhar interconsulta", "text"),
            t("metas", "Metas SMART para os próximos 90 dias"),
            t("revisao", "Próxima revisão do plano", "date", half=True),
        ],
    },
    {
        "key": "evolucao_soap", "name": "Evolução SOAP", "area": "Geral", "visibility": "team", "frequent": True,
        "fields": [
            t("s", "S — Subjetivo (relato do paciente)", rows=3),
            t("o", "O — Objetivo (observações, testes, medidas)", rows=3),
            t("a", "A — Avaliação (análise, resposta ao tratamento)", rows=3),
            t("p", "P — Plano (conduta e próximos passos)", rows=3),
            t("eva", "Dor — EVA (0–10), se aplicável", "scale", half=True, optional=True),
        ],
    },
    {
        "key": "sessao_psico", "name": "Sessão de psicoterapia", "area": "Psicologia", "visibility": "private", "frequent": True,
        "hint": "Nasce privada (só você vê). Resolução CFP 01/2009: na equipe, compartilhe só o necessário.",
        "fields": [
            t("numero", "Sessão nº", "number", half=True),
            t("modalidade", "Modalidade", "select", options=["Presencial", "Online"], half=True),
            t("demanda", "Demanda trazida / temas da sessão", rows=3),
            t("intervencoes", "Intervenções e técnicas utilizadas", rows=3),
            t("observacoes", "Observações clínicas (afeto, comportamento, insight)", rows=3),
            t("risco", "Sinais de risco nesta sessão?", "yesno", alert="yes"),
            t("tarefas", "Tarefas / combinados para a próxima sessão", rows=2),
        ],
    },
    {
        "key": "evolucao_fisio", "name": "Evolução de fisioterapia", "area": "Fisioterapia", "visibility": "team", "frequent": True,
        "fields": [
            t("eva_inicio", "EVA antes", "scale", half=True),
            t("eva_fim", "EVA depois", "scale", half=True),
            t("quadro", "Quadro apresentado / relato", rows=3),
            t("condutas", "Condutas realizadas (técnicas, exercícios, parâmetros)", rows=3),
            t("resposta", "Resposta ao tratamento e orientações", rows=2),
        ],
    },
    {
        "key": "alta", "name": "Alta / encaminhamento / desfecho", "area": "Geral", "visibility": "team",
        "fields": [
            t("criterios", "Critérios de alta alcançados"),
            t("encaminhamentos", "Encaminhamentos externos — médico, psiquiatra, outros profissionais"),
            t("orientacoes", "Orientações finais e plano de manutenção / prevenção de recaída"),
            t("data_alta", "Data da alta", "date", half=True),
            t("tipo", "Tipo", "select", options=["Alta por objetivos", "Alta a pedido", "Abandono", "Encaminhamento"], half=True),
        ],
    },
]

BY_KEY = {tpl["key"]: tpl for tpl in TEMPLATES}


def render_text(template_key: str, data: dict) -> str:
    """Resumo em texto do formulário (usado na lista, na busca e no PDF)."""
    tpl = BY_KEY.get(template_key)
    if not tpl:
        return ""
    lines = []
    for f in tpl["fields"]:
        v = data.get(f["key"])
        if v in (None, "", [], {}):
            continue
        if f["type"] == "yesno":
            v = "Sim" if v in (True, "yes", "sim") else "Não"
        elif f["type"] == "multi":
            v = ", ".join(v) if isinstance(v, list) else str(v)
        elif f["type"] == "table":
            rows = []
            for row, cols in (v or {}).items():
                vals = [f"{c}: {cols.get(c)}" for c in f["cols"] if isinstance(cols, dict) and cols.get(c)]
                if vals:
                    rows.append(f"  • {row} — " + "; ".join(vals))
            if not rows:
                continue
            v = "\n" + "\n".join(rows)
        elif f["type"] == "date" and isinstance(v, str) and len(v) == 10:
            v = "/".join(reversed(v.split("-")))
        lines.append(f"{f['label']}: {v}")
    return "\n".join(lines)


def alerts(template_key: str, data: dict) -> list[str]:
    tpl = BY_KEY.get(template_key)
    out = []
    for f in (tpl or {}).get("fields", []):
        v = data.get(f["key"])
        if f.get("alert") == "yes" and v in (True, "yes"):
            out.append(f["label"])
        if f.get("alert_any") and isinstance(v, list) and [x for x in v if x != "Nenhuma"]:
            out.append(f"{f['label']}: {', '.join(x for x in v if x != 'Nenhuma')}")
    return out
