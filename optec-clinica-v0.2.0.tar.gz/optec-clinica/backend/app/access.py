"""Regras de acesso a pacientes e prontuário (prontuário único multiprofissional).

- Responsável e equipe de cuidado acessam o paciente; administração e recepção veem os dados cadastrais.
- Registro "team": visível ao responsável e à equipe SE o paciente autorizou evolução compartilhada.
- Registro "private": só o autor. Administração/recepção nunca leem prontuário (a menos que sejam da equipe).
"""
from fastapi import HTTPException

from .deps import Auth
from .models import Patient, PatientTeam


def my_pid(auth: Auth) -> int | None:
    return auth.professional.id if auth.professional else None


def team_ids(auth: Auth, patient_id: int) -> set[int]:
    return {r.professional_id for r in auth.db.query(PatientTeam).filter_by(patient_id=patient_id)}


def is_owner(auth: Auth, p: Patient) -> bool:
    return my_pid(auth) is not None and my_pid(auth) == p.professional_id


def in_care(auth: Auth, p: Patient) -> bool:
    """Responsável ou membro da equipe de cuidado."""
    pid = my_pid(auth)
    return pid is not None and (pid == p.professional_id or pid in team_ids(auth, p.id))


def get_patient(auth: Auth, patient_id: int) -> Patient:
    p = auth.db.get(Patient, patient_id)
    if not p or not (in_care(auth, p) or auth.is_staff):
        raise HTTPException(404, "Paciente não encontrado.")
    return p


def care_patient(auth: Auth, patient_id: int) -> Patient:
    p = auth.db.get(Patient, patient_id)
    if not p or not in_care(auth, p):
        raise HTTPException(403, "O prontuário é visível apenas para os profissionais que atendem o paciente.")
    return p


def can_see_entry(auth: Auth, p: Patient, author_id: int, visibility: str) -> bool:
    pid = my_pid(auth)
    if pid is None:
        return False
    if author_id == pid:
        return True
    return visibility == "team" and p.consent_shared and in_care(auth, p)


def accessible_patient_ids_query(auth: Auth, query):
    """Filtra uma query de Patient para o que o profissional atende."""
    pid = my_pid(auth)
    if pid is None:
        return query.filter(Patient.id == -1)
    sub = auth.db.query(PatientTeam.patient_id).filter(PatientTeam.professional_id == pid)
    return query.filter((Patient.professional_id == pid) | (Patient.id.in_(sub)))
