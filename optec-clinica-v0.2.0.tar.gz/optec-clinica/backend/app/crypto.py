"""Cifragem simétrica (Fernet/AES-128-CBC + HMAC) para campos sensíveis."""
from cryptography.fernet import Fernet, InvalidToken
from sqlalchemy import Text
from sqlalchemy.types import TypeDecorator

from . import config

_fernet: Fernet | None = None


def fernet() -> Fernet:
    global _fernet
    if _fernet is None:
        if not config.ENCRYPTION_KEY:
            raise RuntimeError("ENCRYPTION_KEY não configurada. Rode scripts/install.sh ou defina no .env.")
        _fernet = Fernet(config.ENCRYPTION_KEY.encode())
    return _fernet


def encrypt(value: str | None) -> str | None:
    if value is None or value == "":
        return value
    return fernet().encrypt(value.encode()).decode()


def decrypt(value: str | None) -> str | None:
    if value is None or value == "":
        return value
    try:
        return fernet().decrypt(value.encode()).decode()
    except InvalidToken:
        return "[não foi possível decifrar: chave diferente]"


class EncryptedText(TypeDecorator):
    """Coluna de texto cifrada de forma transparente no banco."""

    impl = Text
    cache_ok = True

    def process_bind_param(self, value, dialect):
        return encrypt(value)

    def process_result_value(self, value, dialect):
        return decrypt(value)
