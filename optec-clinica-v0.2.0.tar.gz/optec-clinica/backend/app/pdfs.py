"""Documentos em PDF: prontuário, recibos e declaração de comparecimento (layout NeuroInsight)."""
import datetime as dt
import io
from html import escape
from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.platypus import (Image, KeepTogether, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle)
from sqlalchemy.orm import Session

from . import config, record_templates, settings_store
from .models import Appointment, Patient, Professional

BRAND = colors.HexColor("#22a094")
BRAND2 = colors.HexColor("#3d64b3")
INDIGO = colors.HexColor("#3b3a7a")
MUTED = colors.HexColor("#646c8c")
LINE = colors.HexColor("#dde3ef")
SOFT = colors.HexColor("#eef7f6")
ASSETS = Path(__file__).parent / "assets"

ST = {
    "body": ParagraphStyle("body", fontName="Helvetica", fontSize=9.5, leading=13, textColor=colors.HexColor("#1e1f48")),
    "small": ParagraphStyle("small", fontName="Helvetica", fontSize=8, leading=10, textColor=MUTED),
    "label": ParagraphStyle("label", fontName="Helvetica-Bold", fontSize=8.5, leading=11, textColor=INDIGO),
    "h1": ParagraphStyle("h1", fontName="Helvetica-Bold", fontSize=15, leading=19, textColor=INDIGO, alignment=TA_CENTER),
    "h2": ParagraphStyle("h2", fontName="Helvetica-Bold", fontSize=10.5, leading=14, textColor=colors.white),
    "entry": ParagraphStyle("entry", fontName="Helvetica-Bold", fontSize=9.5, leading=12, textColor=INDIGO),
    "center": ParagraphStyle("center", fontName="Helvetica", fontSize=9.5, leading=13, alignment=TA_CENTER),
}


def P(text, style="body"):
    return Paragraph(escape(str(text or "")).replace("\n", "<br/>"), ST[style])


def money(v: float) -> str:
    return f"R$ {v:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")


def fdate(d) -> str:
    if not d:
        return "—"
    if isinstance(d, str):
        d = dt.date.fromisoformat(d[:10])
    return d.strftime("%d/%m/%Y")


def logo_path(db: Session) -> Path:
    name = settings_store.get(db, "logo")
    if name:
        p = config.UPLOAD_DIR / "branding" / Path(name).name
        if p.is_file():
            return p
    return ASSETS / "logo-mark.png"


def _doc(buf, title: str):
    return SimpleDocTemplate(buf, pagesize=A4, leftMargin=16 * mm, rightMargin=16 * mm, topMargin=30 * mm,
                             bottomMargin=18 * mm, title=title, author="NeuroInsight")


def _page(db: Session, subtitle: str):
    s = settings_store.get_all(db)
    logo = logo_path(db)

    def draw(canvas, doc):
        canvas.saveState()
        w, h = A4
        try:
            from PIL import Image as PILImage
            with PILImage.open(logo) as im:
                ratio = im.width / im.height
            lh = 15 * mm
            canvas.drawImage(str(logo), 16 * mm, h - 24 * mm, width=lh * ratio, height=lh, mask="auto")
            x = 16 * mm + lh * ratio + 4 * mm
        except Exception:  # noqa: BLE001 - logo é opcional
            x = 16 * mm
        canvas.setFillColor(INDIGO)
        canvas.setFont("Helvetica-Bold", 13)
        canvas.drawString(x, h - 15 * mm, s["clinic_name"])
        canvas.setFont("Helvetica", 8)
        canvas.setFillColor(MUTED)
        canvas.drawString(x, h - 19.5 * mm, s["clinic_tagline"])
        contact = " | ".join(v for v in (s["clinic_address"], s["clinic_phone"], s.get("clinic_document")) if v)
        canvas.drawString(x, h - 23.5 * mm, contact)
        canvas.setFillColor(BRAND)
        canvas.setFont("Helvetica-Bold", 8)
        canvas.drawRightString(w - 16 * mm, h - 15 * mm, subtitle)
        canvas.setStrokeColor(BRAND)
        canvas.setLineWidth(1.2)
        canvas.line(16 * mm, h - 27 * mm, w - 16 * mm, h - 27 * mm)
        canvas.setStrokeColor(LINE)
        canvas.setLineWidth(0.6)
        canvas.line(16 * mm, 13 * mm, w - 16 * mm, 13 * mm)
        canvas.setFont("Helvetica", 7)
        canvas.setFillColor(MUTED)
        canvas.drawString(16 * mm, 9 * mm, s.get("record_footer", "")[:150])
        canvas.drawRightString(w - 16 * mm, 9 * mm, f"Página {doc.page}")
        canvas.restoreState()
    return draw


def section(title: str):
    t = Table([[P(title, "h2")]], colWidths=[178 * mm])
    t.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, -1), INDIGO), ("LEFTPADDING", (0, 0), (-1, -1), 6),
                           ("TOPPADDING", (0, 0), (-1, -1), 3), ("BOTTOMPADDING", (0, 0), (-1, -1), 4)]))
    return [Spacer(1, 6 * mm), t, Spacer(1, 2 * mm)]


def kv_table(pairs: list[tuple[str, str]], cols: int = 2):
    rows, row = [], []
    for k, v in pairs:
        row += [P(k, "label"), P(v or "—")]
        if len(row) == cols * 2:
            rows.append(row)
            row = []
    if row:
        rows.append(row + [""] * (cols * 2 - len(row)))
    widths = [28 * mm, 61 * mm] * cols if cols == 2 else [40 * mm, 138 * mm]
    t = Table(rows, colWidths=widths)
    t.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"), ("LINEBELOW", (0, 0), (-1, -1), 0.4, LINE),
                           ("TOPPADDING", (0, 0), (-1, -1), 3), ("BOTTOMPADDING", (0, 0), (-1, -1), 3)]))
    return t


def age(birth) -> str:
    if not birth:
        return "—"
    t = dt.date.today()
    return str(t.year - birth.year - ((t.month, t.day) < (birth.month, birth.day)))


def form_flowables(entry: dict) -> list:
    tpl = record_templates.BY_KEY.get(entry.get("template") or "")
    data = entry.get("data") or {}
    if not tpl or not data:
        return [P(entry["content"])]
    out = []
    for f in tpl["fields"]:
        v = data.get(f["key"])
        if v in (None, "", [], {}):
            continue
        if f["type"] == "table":
            rows = [[P("Área", "label")] + [P(c, "label") for c in f["cols"]]]
            for r in f["rows"]:
                cells = (v or {}).get(r) or {}
                if any(cells.get(c) for c in f["cols"]):
                    rows.append([P(r, "label")] + [P(cells.get(c, "")) for c in f["cols"]])
            if len(rows) > 1:
                out.append(P(f["label"], "label"))
                t = Table(rows, colWidths=[30 * mm] + [37 * mm] * len(f["cols"]))
                t.setStyle(TableStyle([("GRID", (0, 0), (-1, -1), 0.4, LINE), ("BACKGROUND", (0, 0), (-1, 0), SOFT),
                                       ("VALIGN", (0, 0), (-1, -1), "TOP")]))
                out += [t, Spacer(1, 2 * mm)]
            continue
        if f["type"] == "yesno":
            v = "Sim" if v in (True, "yes") else "Não"
        elif f["type"] == "multi":
            v = ", ".join(v) if isinstance(v, list) else v
        elif f["type"] == "date":
            v = fdate(v)
        out.append(P(f["label"], "label"))
        out.append(P(v))
        out.append(Spacer(1, 1.5 * mm))
    return out


def record_pdf(db: Session, p: Patient, entries: list[dict], team: list[Professional]) -> bytes:
    buf = io.BytesIO()
    doc = _doc(buf, f"Prontuário {p.id:06d}")
    owner = db.get(Professional, p.professional_id)
    story = [P("PRONTUÁRIO MULTIPROFISSIONAL", "h1"), Spacer(1, 1 * mm),
             P(f"Prontuário nº {p.id:06d} · emitido em {dt.datetime.now().strftime('%d/%m/%Y %H:%M')}", "center")]
    story += section("1. Identificação do paciente")
    story.append(kv_table([
        ("Nome completo", p.name), ("Prontuário nº", f"{p.id:06d}"),
        ("Data nasc.", fdate(p.birth_date)), ("Idade", age(p.birth_date)),
        ("Sexo", p.sex), ("Estado civil", p.marital_status), ("CPF", p.cpf), ("RG", p.rg),
        ("Profissão", p.occupation), ("Convênio", p.insurance), ("Telefone/WhatsApp", p.phone), ("E-mail", p.email),
        ("Responsável", p.guardian), ("Data abertura", fdate(p.created_at.date() if p.created_at else None)),
    ]))
    story.append(kv_table([("Endereço", p.address), ("Profissional responsável", owner.user.name if owner else "—"),
                           ("Equipe de cuidado", ", ".join(f"{t.user.name} ({t.specialty or ''})" for t in team))], cols=1))
    story += section("2. Consentimento livre e esclarecido e LGPD")
    box = lambda b: "[X]" if b else "[  ]"  # noqa: E731
    story.append(kv_table([
        (box(p.consent_ehr), "Autoriza uso de dados para prontuário eletrônico seguro"),
        (box(p.consent_whatsapp), "Autoriza contato por WhatsApp para agendamentos"),
        (box(p.consent_shared), "Autoriza registro de evolução em prontuário compartilhado"),
        (box(p.consent_care), "Leu e concorda com o Termo de Consentimento"),
    ], cols=1))
    story.append(P(f"Consentimentos registrados em: {p.consent_at.strftime('%d/%m/%Y %H:%M') if p.consent_at else '—'}", "small"))
    if p.notes:
        story += section("Alertas")
        story.append(P(p.notes))
    story += section("3. Registros do prontuário (ordem cronológica)")
    if not entries:
        story.append(P("Nenhum registro visível para quem emitiu este documento.", "small"))
    for e in entries:
        when = dt.datetime.fromisoformat(str(e["created_at"])).strftime("%d/%m/%Y %H:%M")
        label = e.get("template_name") or {"soap": "Evolução SOAP", "addendum": "Adendo"}.get(e["kind"], "Evolução")
        head = f"{when} · {label}{' — ' + e['title'] if e.get('title') and e['title'] != label else ''}"
        who = f"{e['author']}{' · ' + e['author_specialty'] if e.get('author_specialty') else ''}"
        if e["visibility"] == "private":
            who += " · registro privado"
        block = [Table([[P(head, "entry"), P(who, "small")]], colWidths=[110 * mm, 68 * mm],
                       style=TableStyle([("BACKGROUND", (0, 0), (-1, -1), SOFT), ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                                         ("TOPPADDING", (0, 0), (-1, -1), 4), ("BOTTOMPADDING", (0, 0), (-1, -1), 4)]))]
        if e.get("alerts"):
            block.append(P("ATENÇÃO: " + "; ".join(e["alerts"]), "label"))
        block += form_flowables(e)
        block.append(Spacer(1, 4 * mm))
        story.append(KeepTogether(block[:3]))
        story += block[3:]
    story += section("Declaração e assinaturas")
    story.append(P("Declaro que as informações registradas são verdadeiras e correspondem aos atendimentos realizados. "
                   "Este documento é sigiloso e protegido pela LGPD e pelos Códigos de Ética profissionais."))
    story.append(Spacer(1, 14 * mm))
    sigs = [[P("_" * 38, "center") for _ in team[:3]], [P(f"{t.user.name}<br/>{t.council or t.specialty or ''}", "center") for t in team[:3]]]
    if team:
        story.append(Table(sigs, colWidths=[178 * mm / len(team[:3])] * len(team[:3])))
    doc.build(story, onFirstPage=_page(db, "Prontuário · Documento sigiloso · LGPD"),
              onLaterPages=_page(db, "Prontuário · Documento sigiloso · LGPD"))
    return buf.getvalue()


# ---------- valor por extenso (recibos) ----------
_U = ["zero", "um", "dois", "três", "quatro", "cinco", "seis", "sete", "oito", "nove", "dez", "onze", "doze", "treze",
      "catorze", "quinze", "dezesseis", "dezessete", "dezoito", "dezenove"]
_D = ["", "", "vinte", "trinta", "quarenta", "cinquenta", "sessenta", "setenta", "oitenta", "noventa"]
_C = ["", "cento", "duzentos", "trezentos", "quatrocentos", "quinhentos", "seiscentos", "setecentos", "oitocentos", "novecentos"]


def _ate_mil(n: int) -> str:
    if n == 100:
        return "cem"
    parts = []
    c, r = divmod(n, 100)
    if c:
        parts.append(_C[c])
    if r:
        if r < 20:
            parts.append(_U[r])
        else:
            d, u = divmod(r, 10)
            parts.append(_D[d] + (f" e {_U[u]}" if u else ""))
    return " e ".join(parts)


def extenso(v: float) -> str:
    reais, cent = int(v), int(round((v - int(v)) * 100))
    parts = []
    mil, resto = divmod(reais, 1000)
    if mil:
        parts.append("mil" if mil == 1 else f"{_ate_mil(mil)} mil")
    if resto:
        parts.append(_ate_mil(resto))
    txt = (" e " if mil and resto and (resto < 100 or resto % 100 == 0) else " ").join(parts) if parts else "zero"
    txt += " real" if reais == 1 else " reais"
    if cent:
        txt += f" e {_ate_mil(cent)} centavo{'s' if cent > 1 else ''}"
    return txt


def _signature(story, name: str, line2: str, city: str):
    story.append(Spacer(1, 8 * mm))
    story.append(P(f"{city}, {dt.date.today().strftime('%d/%m/%Y')}.", "body"))
    story.append(Spacer(1, 18 * mm))
    story.append(P("_" * 50, "center"))
    story.append(P(name, "center"))
    story.append(P(line2, "center"))


def receipt_pdf(db: Session, prof: Professional, patient: Patient, amount: float, items: list[str],
                method: str | None, paid_at) -> bytes:
    s = settings_store.get_all(db)
    buf = io.BytesIO()
    doc = _doc(buf, "Recibo")
    story = [P("RECIBO", "h1"), Spacer(1, 2 * mm), P(money(amount), "h1"), Spacer(1, 6 * mm)]
    who = f"{patient.name}" + (f", CPF {patient.cpf}" if patient.cpf else "")
    story.append(P(f"Recebi de {who} a importância de {money(amount)} ({extenso(amount)}), referente aos serviços "
                   f"profissionais de {prof.specialty or 'saúde'} descritos abaixo."))
    story.append(Spacer(1, 3 * mm))
    for it in items:
        story.append(P(f"• {it}"))
    story.append(Spacer(1, 3 * mm))
    extra = []
    if method:
        extra.append(f"Forma de pagamento: {method}")
    if paid_at:
        extra.append(f"Pago em {paid_at.strftime('%d/%m/%Y')}")
    if extra:
        story.append(P(" · ".join(extra), "small"))
    _signature(story, prof.user.name, " · ".join(v for v in (prof.council, f"CPF/CNPJ {prof.document}" if prof.document else None) if v),
               s["clinic_city"] or "")
    story.append(Spacer(1, 6 * mm))
    story.append(P("Profissional pessoa física: emita também o recibo no app Receita Saúde quando exigido.", "small"))
    doc.build(story, onFirstPage=_page(db, "Recibo"), onLaterPages=_page(db, "Recibo"))
    return buf.getvalue()


def invoice_receipt_pdf(db: Session, prof: Professional, inv: dict) -> bytes:
    s = settings_store.get_all(db)
    buf = io.BytesIO()
    doc = _doc(buf, "Recibo de aluguel")
    story = [P("RECIBO DE LOCAÇÃO DE SALA", "h1"), Spacer(1, 2 * mm), P(money(inv["amount"]), "h1"), Spacer(1, 6 * mm),
             P(f"Recebemos de {prof.user.name}{', CPF/CNPJ ' + prof.document if prof.document else ''} a importância de "
               f"{money(inv['amount'])} ({extenso(inv['amount'])}), referente à utilização de salas no mês {inv['month'][5:]}/{inv['month'][:4]}."),
             Spacer(1, 3 * mm)]
    rows = [[P(h, "label") for h in ("Data", "Horário", "Sala", "Horas")]]
    for r in inv.get("reservations", [])[:60]:
        rows.append([P(fdate(r["date"])), P(f"{r['start']}–{r['end']}"), P(r["room"]), P(f"{r['hours']:g}")])
    if len(rows) > 1:
        t = Table(rows, colWidths=[35 * mm, 40 * mm, 70 * mm, 33 * mm])
        t.setStyle(TableStyle([("LINEBELOW", (0, 0), (-1, -1), 0.4, LINE), ("BACKGROUND", (0, 0), (-1, 0), SOFT)]))
        story.append(t)
    for a in inv.get("adjustments", []):
        story.append(P(f"{'Desconto' if a['amount'] < 0 else 'Acréscimo'}: {a['description']} ({money(a['amount'])})", "small"))
    _signature(story, s["clinic_name"], s.get("clinic_document") or "", s["clinic_city"] or "")
    doc.build(story, onFirstPage=_page(db, "Recibo de locação"), onLaterPages=_page(db, "Recibo de locação"))
    return buf.getvalue()


def attendance_pdf(db: Session, a: Appointment) -> bytes:
    s = settings_store.get_all(db)
    prof = db.get(Professional, a.professional_id)
    buf = io.BytesIO()
    doc = _doc(buf, "Declaração de comparecimento")
    story = [Spacer(1, 10 * mm), P("DECLARAÇÃO DE COMPARECIMENTO", "h1"), Spacer(1, 12 * mm),
             P(f"Declaro, para os devidos fins, que {a.patient.name}"
               f"{', CPF ' + a.patient.cpf if a.patient.cpf else ''} compareceu a atendimento de "
               f"{(prof.specialty or 'saúde').lower()} {'on-line' if a.online else 'nesta clínica'} no dia "
               f"{a.date.strftime('%d/%m/%Y')}, das {a.start.strftime('%H:%M')} às {a.end.strftime('%H:%M')}.")]
    _signature(story, prof.user.name, prof.council or prof.specialty or "", s["clinic_city"] or "")
    doc.build(story, onFirstPage=_page(db, "Declaração"), onLaterPages=_page(db, "Declaração"))
    return buf.getvalue()
