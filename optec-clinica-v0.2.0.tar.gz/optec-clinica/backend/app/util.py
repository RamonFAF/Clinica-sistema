import datetime as dt

from fastapi import HTTPException


def parse_time(value: str) -> dt.time:
    try:
        return dt.time.fromisoformat(value[:5])
    except (ValueError, TypeError):
        raise HTTPException(422, f"Horário inválido: {value}") from None


def parse_date(value: str) -> dt.date:
    try:
        return dt.date.fromisoformat(value)
    except (ValueError, TypeError):
        raise HTTPException(422, f"Data inválida: {value}") from None


def hhmm(t: dt.time) -> str:
    return t.strftime("%H:%M")


def minutes(t: dt.time) -> int:
    return t.hour * 60 + t.minute


def hours_between(a: dt.time, b: dt.time) -> float:
    return (minutes(b) - minutes(a)) / 60


def month_range(month: str) -> tuple[dt.date, dt.date]:
    try:
        first = dt.date.fromisoformat(month + "-01")
    except ValueError:
        raise HTTPException(422, "Mês inválido (use AAAA-MM).") from None
    nxt = (first.replace(day=28) + dt.timedelta(days=4)).replace(day=1)
    return first, nxt - dt.timedelta(days=1)


def not_found(what: str = "Registro") -> HTTPException:
    return HTTPException(404, f"{what} não encontrado.")
