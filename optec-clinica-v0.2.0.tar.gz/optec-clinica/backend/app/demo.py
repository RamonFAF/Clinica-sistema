"""Dados FICTÍCIOS para demonstração (nomes e telefones inventados)."""
import datetime as dt
import uuid

from .db import SessionLocal
import json
import secrets

from .models import (Appointment, Expense, Patient, PatientTeam, Professional, RecordEntry, Reservation, Room,
                     SessionPackage, User, WaitlistEntry)
from .record_templates import render_text
from .security import hash_password, temp_password

PROS = [
    ("Renata Alves", "renata@clinica-demo.com.br", "CRP 06/000001", "Psicologia", "#7c3aed", "monthly", 2200, 0),
    ("Marcos Teixeira", "marcos@clinica-demo.com.br", "CREFITO-3 000001-F", "Fisioterapia", "#2563eb", "hourly", 0, 0),
    ("Carla Nunes", "carla@clinica-demo.com.br", "CRN-3 00001", "Nutrição", "#d97706", "percent", 0, 20),
    ("Paulo Reis", "paulo@clinica-demo.com.br", "CRP 06/000002", "Neuropsicologia", "#0d9488", "hourly", 0, 0),
]
PATIENTS = ["Lucas Pereira", "Fernanda Lima", "Marina Costa", "Diego Santos", "Bianca Rocha", "Sílvia Mendes",
            "Carlos Dias", "Rafael Torres", "Juliana Prado", "André Melo", "Patrícia Gomes", "Tiago Nogueira"]


def seed() -> None:
    with SessionLocal() as db:
        if db.query(User).filter_by(email=PROS[0][1]).first():
            print("Dados de demonstração já existem.")
            return
        rooms = db.query(Room).filter(Room.active.is_(True)).order_by(Room.sort_order).all()
        if len(rooms) < 4:
            for i in range(len(rooms) + 1, 5):
                db.add(Room(name=f"Sala {i}", hourly_rate=40 + i * 5, sort_order=i))
            db.flush()
            rooms = db.query(Room).filter(Room.active.is_(True)).order_by(Room.sort_order).all()
        pwd = temp_password()
        profs = []
        for name, email, council, spec, color, model, fee, pct in PROS:
            u = User(email=email, name=name, role="professional", password_hash=hash_password(pwd), must_change_password=True)
            p = Professional(user=u, council=council, specialty=spec, color=color, billing_model=model,
                             monthly_fee=fee, percent=pct, phone="11900000000")
            db.add_all([u, p])
            profs.append(p)
        db.flush()
        today = dt.date.today()
        monday = today - dt.timedelta(days=today.weekday())
        plan = [(0, 0, "08:00", "12:00", range(6)), (1, 1, "08:00", "12:00", (0, 2, 4)), (1, 1, "14:00", "18:00", (1, 3)),
                (2, 2, "09:00", "13:00", (0, 1, 2, 3)), (3, 3, "14:00", "19:00", (0, 1, 2, 3, 4))]
        for w in range(-2, 4):
            series = {i: str(uuid.uuid4()) for i in range(len(plan))}
            for i, (ri, pi, a, b, days) in enumerate(plan):
                for d in days:
                    db.add(Reservation(room_id=rooms[ri].id, professional_id=profs[pi].id,
                                       date=monday + dt.timedelta(weeks=w, days=d), start=dt.time.fromisoformat(a),
                                       end=dt.time.fromisoformat(b), series_id=series[i]))
        pats = []
        for i, n in enumerate(PATIENTS):
            p = Patient(professional_id=profs[i % 4].id, name=n, phone=f"119{88880000 + i}",
                        birth_date=dt.date(1980 + i, (i % 12) + 1, 10), consent_care=True, consent_ehr=True, consent_shared=i % 4 != 3, consent_whatsapp=i % 3 != 0,
                        sex="Feminino" if n.split()[0][-1] == "a" else "Masculino", insurance="Particular",
                        consent_at=dt.datetime.now(dt.timezone.utc), notes="Paciente fictício de demonstração.")
            db.add(p)
            pats.append(p)
        db.flush()
        hours = {0: ["08:00", "09:00", "10:00", "11:00"], 1: ["08:00", "09:00", "10:00"], 2: ["09:00", "10:00", "11:00"],
                 3: ["14:00", "15:00", "16:00", "17:00"]}
        for w in (-1, 0, 1):
            for d in range(5):
                day = monday + dt.timedelta(weeks=w, days=d)
                for pi, prof in enumerate(profs):
                    mine = [p for p in pats if p.professional_id == prof.id]
                    for k, h in enumerate(hours[pi]):
                        if (d + k + pi) % 3 == 0 or (pi == 1 and d in (1, 3)) or (pi == 2 and d == 4):
                            continue
                        start = dt.time.fromisoformat(h)
                        past = day < today
                        status = ("done" if (d + k) % 5 else "no_show") if past else ("confirmed" if k % 2 == 0 else "scheduled")
                        db.add(Appointment(patient_id=mine[(d + k) % len(mine)].id, professional_id=prof.id, date=day,
                                           start=start, end=dt.time(start.hour, 50), price=[180, 150, 220, 200][pi],
                                           status=status, paid=past and status == "done" and (d + k) % 4 != 0,
                                           payment_method="pix" if past else None, confirm_token=secrets.token_urlsafe(24)))
        def form(pat, prof, key, data, vis="team", title=None):
            from .record_templates import BY_KEY
            db.add(RecordEntry(patient_id=pat.id, professional_id=prof.id, kind="form", template=key, visibility=vis,
                               title=title or BY_KEY[key]["name"], content=render_text(key, data), data=json.dumps(data, ensure_ascii=False)))
        lucas = pats[0]
        lucas.occupation, lucas.address, lucas.notes = "Professor", "Rua Fictícia, 100 - Centro, Arcoverde - PE", "Alergia a dipirona (fictício)."
        for pr in (profs[1], profs[2]):
            db.add(PatientTeam(patient_id=lucas.id, professional_id=pr.id))
        form(lucas, profs[0], "anamnese_geral", {"queixa": "\"Não consigo dormir e ando muito ansioso.\"", "historia_queixa": "Início há 6 meses.",
             "sono": "5 h por noite, acorda várias vezes.", "rede_apoio": "Família próxima."})
        form(lucas, profs[0], "aval_psicologica", {"motivo": "Ansiedade e insônia", "phq9": 11, "gad7": 14, "ideacao": "no",
             "plano_suicida": "no", "objetivos": "Reduzir ansiedade; regular o sono."})
        form(lucas, profs[0], "pti", {"plano": {"Psicologia": {"Objetivo principal": "Reduzir ansiedade", "Intervenção": "TCC", "Frequência": "Semanal", "Responsável": "Renata"},
             "Nutrição": {"Objetivo principal": "Rotina alimentar", "Intervenção": "Nutrição comportamental", "Frequência": "Quinzenal", "Responsável": "Carla"},
             "Fisioterapia": {"Objetivo principal": "Tensão cervical", "Intervenção": "Liberação miofascial", "Frequência": "Semanal", "Responsável": "Marcos"}},
             "interconsulta": "no", "metas": "Dormir 7 h em 90 dias; GAD-7 abaixo de 8."})
        form(lucas, profs[1], "evolucao_fisio", {"eva_inicio": 6, "eva_fim": 3, "quadro": "Tensão em trapézio.", "condutas": "Liberação miofascial; alongamento.",
             "resposta": "Boa resposta."})
        form(lucas, profs[0], "sessao_psico", {"numero": 12, "modalidade": "Presencial", "demanda": "Rotina de sono", "intervencoes": "Psicoeducação",
             "risco": "no"}, vis="private")
        form(pats[1], profs[1], "aval_fisio", {"queixa": "Dor lombar", "eva": 4, "diagnostico": "Disfunção lombar mecânica (fictício)",
             "plano": "10 sessões, 2x por semana."})
        db.add(SessionPackage(patient_id=pats[1].id, professional_id=profs[1].id, name="Pacote 10 sessões", sessions_total=10,
                              price=1300, paid=True, payment_method="pix", paid_at=dt.datetime.now(dt.timezone.utc)))
        month0 = today.replace(day=1)
        for desc, cat, val, day_ in (("Aluguel do imóvel", "Aluguel do imóvel", 4500, 5), ("Energia", "Energia", 620, 10),
                                     ("Internet", "Internet e telefone", 150, 12), ("Limpeza", "Limpeza", 1200, 15)):
            db.add(Expense(date=month0.replace(day=day_), description=desc, category=cat, amount=val, paid=day_ < today.day))
        db.add(Expense(professional_id=profs[0].id, date=month0.replace(day=8), description="Supervisão clínica", category="Supervisão", amount=350))
        db.add(WaitlistEntry(name="Interessado Fictício", phone="11900000001", specialty="Psicologia", preference="Terças à tarde",
                             professional_id=profs[0].id))
        db.add(WaitlistEntry(name="Outra Pessoa Fictícia", phone="11900000002", specialty="Nutrição", preference="Manhãs"))
        pats[5].birth_date = today.replace(year=1960)
        db.commit()
    print("Demonstração criada. Profissionais (senha provisória para todos):", pwd)
    for _, email, *_ in PROS:
        print("  ", email)
