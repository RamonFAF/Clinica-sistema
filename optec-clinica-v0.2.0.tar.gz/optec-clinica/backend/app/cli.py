"""Comandos de manutenção.

  python -m app.cli create-admin --email voce@exemplo.com --name "Seu Nome"
  python -m app.cli reset-mfa --email voce@exemplo.com
  python -m app.cli seed-demo        (dados fictícios para demonstração)
"""
import argparse
import sys

from .db import SessionLocal
from .models import Professional, Room, User, UserSession
from .security import hash_password, temp_password


def create_admin(email: str, name: str) -> None:
    with SessionLocal() as db:
        if db.query(User).filter_by(email=email.lower()).first():
            sys.exit("Já existe usuário com este e-mail.")
        pwd = temp_password()
        u = User(email=email.lower(), name=name, role="admin", password_hash=hash_password(pwd), must_change_password=True)
        db.add_all([u, Professional(user=u, attends=False, color="#3b3a7a")])
        if not db.query(Room).count():
            db.add_all([Room(name=f"Sala {i}", hourly_rate=40, sort_order=i) for i in range(1, 5)])
        db.commit()
    print(f"Administrador criado: {email}\nSenha provisória: {pwd}\n(troque no primeiro acesso e ative o 2FA)")


def reset_mfa(email: str) -> None:
    with SessionLocal() as db:
        u = db.query(User).filter_by(email=email.lower()).first()
        if not u:
            sys.exit("Usuário não encontrado.")
        u.totp_enabled, u.totp_secret, u.failed_logins, u.locked_until = False, None, 0, None
        db.query(UserSession).filter_by(user_id=u.id).delete()
        db.commit()
    print("2FA removido. O usuário vai configurar de novo no próximo login.")


def main() -> None:
    ap = argparse.ArgumentParser(prog="app.cli")
    sub = ap.add_subparsers(dest="cmd", required=True)
    a = sub.add_parser("create-admin")
    a.add_argument("--email", required=True)
    a.add_argument("--name", required=True)
    r = sub.add_parser("reset-mfa")
    r.add_argument("--email", required=True)
    sub.add_parser("seed-demo")
    args = ap.parse_args()
    if args.cmd == "create-admin":
        create_admin(args.email, args.name)
    elif args.cmd == "reset-mfa":
        reset_mfa(args.email)
    elif args.cmd == "seed-demo":
        from .demo import seed
        seed()


if __name__ == "__main__":
    main()
