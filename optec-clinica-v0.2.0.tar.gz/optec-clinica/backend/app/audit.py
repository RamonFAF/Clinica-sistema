from fastapi import Request
from sqlalchemy.orm import Session

from .models import AuditLog


def client_ip(request: Request | None) -> str | None:
    if request is None:
        return None
    fwd = request.headers.get("x-forwarded-for")
    if fwd:
        return fwd.split(",")[0].strip()[:64]
    return request.client.host if request.client else None


def log(db: Session, request: Request | None, user_id: int | None, action: str,
        entity: str | None = None, entity_id: int | None = None, detail: str | None = None,
        commit: bool = True) -> None:
    db.add(AuditLog(user_id=user_id, action=action, entity=entity, entity_id=entity_id,
                    ip=client_ip(request), detail=(detail or "")[:500] or None))
    if commit:
        db.commit()
