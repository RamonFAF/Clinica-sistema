"""Configuração lida de variáveis de ambiente (arquivo .env no servidor)."""
import os
from pathlib import Path

VERSION = "0.2.0"

DATABASE_URL = os.environ.get("DATABASE_URL", "postgresql+psycopg://clinica:clinica@localhost:5432/clinica")
# Chave Fernet (base64 de 32 bytes) que cifra prontuário, observações, CPF e segredos de 2FA.
# Gerada pelo scripts/install.sh. Perder esta chave = perder os dados cifrados.
ENCRYPTION_KEY = os.environ.get("ENCRYPTION_KEY", "")
UPLOAD_DIR = Path(os.environ.get("UPLOAD_DIR", "/data/uploads"))
COOKIE_SECURE = os.environ.get("COOKIE_SECURE", "true").lower() == "true"
COOKIE_NAME = "clinica_session"
SESSION_MAX_HOURS = int(os.environ.get("SESSION_MAX_HOURS", "12"))
STATIC_DIR = Path(os.environ.get("STATIC_DIR", Path(__file__).resolve().parent.parent / "static"))
MAX_PHOTO_BYTES = 5 * 1024 * 1024
