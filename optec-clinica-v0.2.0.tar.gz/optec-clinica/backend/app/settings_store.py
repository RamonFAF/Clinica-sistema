"""Configurações editáveis pelo painel (tabela settings, valores em JSON)."""
import json

from sqlalchemy.orm import Session

from .models import Setting

DEFAULTS: dict = {
    "clinic_name": "NeuroInsight",
    "clinic_tagline": "Clínica Integrada de Saúde Mental e Bem-Estar",
    "clinic_phone": "(87) 9174-3069",
    "clinic_address": "Arcoverde - PE",
    "clinic_city": "Arcoverde",
    "clinic_document": "",
    "logo": None,
    "open_time": "07:00",
    "close_time": "21:00",
    "slot_minutes": 30,
    "open_weekdays": [0, 1, 2, 3, 4, 5],
    "default_session_minutes": 50,
    "default_price": 150.0,
    "default_room_rate": 40.0,
    "cancel_hours": 24,
    "invoice_due_day": 10,
    "professionals_can_book_rooms": True,
    "require_room_for_in_person": True,
    "mfa_required": True,
    "session_idle_minutes": 30,
    "min_password_length": 10,
    "max_failed_logins": 5,
    "lockout_minutes": 15,
    "whatsapp_template": "Olá, {paciente}! Lembrete da sua consulta com {profissional} em {data} às {hora}"
                         " na {clinica}. Para confirmar ou pedir para remarcar, toque no link: {link}",
    "whatsapp_charge_template": "Olá, {paciente}! Tudo bem? Consta em aberto o valor de {valor} referente a {itens}."
                                " Se já pagou, desconsidere. Qualquer dúvida, estou à disposição. {profissional}",
    "whatsapp_birthday_template": "Feliz aniversário, {paciente}! A equipe da {clinica} deseja um novo ano cheio de saúde"
                                  " e bem-estar.",
    "record_footer": "Documento sigiloso, protegido pela LGPD e pelos Códigos de Ética profissionais. Acesso restrito à equipe autorizada.",
}

# Chaves que qualquer pessoa vê (tela de login, antes de entrar).
PUBLIC_KEYS = ("clinic_name", "clinic_tagline", "logo")

TYPES = {k: type(v) for k, v in DEFAULTS.items() if v is not None}


def get_all(db: Session) -> dict:
    out = dict(DEFAULTS)
    for row in db.query(Setting).all():
        if row.key in DEFAULTS:
            out[row.key] = json.loads(row.value)
    return out


def get(db: Session, key: str):
    row = db.get(Setting, key)
    return json.loads(row.value) if row else DEFAULTS.get(key)


def coerce(key: str, value):
    t = TYPES.get(key)
    if t is None or value is None:
        return value
    if t is bool:
        return bool(value)
    if t is int:
        return int(value)
    if t is float:
        return float(value)
    if t is list:
        return [int(x) for x in value]
    return str(value)


def validate(merged: dict) -> str | None:
    import re
    for k in ("open_time", "close_time"):
        if not re.fullmatch(r"([01]\d|2[0-3]):[0-5]\d", str(merged[k])):
            return "Horário de funcionamento inválido (use HH:MM)."
    if merged["open_time"] >= merged["close_time"]:
        return "O horário de abertura precisa ser antes do fechamento."
    if not 5 <= merged["slot_minutes"] <= 120:
        return "O intervalo da grade deve ficar entre 5 e 120 minutos."
    if not 10 <= merged["default_session_minutes"] <= 480:
        return "A duração padrão da consulta deve ficar entre 10 e 480 minutos."
    if not merged["open_weekdays"] or any(d not in range(7) for d in merged["open_weekdays"]):
        return "Escolha pelo menos um dia de funcionamento."
    if not 5 <= merged["session_idle_minutes"] <= 720:
        return "O tempo de inatividade deve ficar entre 5 e 720 minutos."
    if not 8 <= merged["min_password_length"] <= 64:
        return "O tamanho mínimo da senha deve ficar entre 8 e 64."
    if not 3 <= merged["max_failed_logins"] <= 20 or not 1 <= merged["lockout_minutes"] <= 1440:
        return "Regras de bloqueio inválidas."
    if not 1 <= merged["invoice_due_day"] <= 28:
        return "O vencimento deve ficar entre os dias 1 e 28."
    if not str(merged["clinic_name"]).strip():
        return "Informe o nome da clínica."
    return None


def update(db: Session, data: dict) -> dict:
    current = get_all(db)
    clean = {}
    for key, value in data.items():
        if key not in DEFAULTS or key == "logo":
            continue
        try:
            clean[key] = coerce(key, value)
        except (TypeError, ValueError):
            raise ValueError(f"Valor inválido em {key}.") from None
    problem = validate({**current, **clean})
    if problem:
        raise ValueError(problem)
    for key, value in clean.items():
        row = db.get(Setting, key)
        if row:
            row.value = json.dumps(value)
        else:
            db.add(Setting(key=key, value=json.dumps(value)))
    db.commit()
    return get_all(db)


def set_value(db: Session, key: str, value) -> None:
    row = db.get(Setting, key)
    if row:
        row.value = json.dumps(value)
    else:
        db.add(Setting(key=key, value=json.dumps(value)))
    db.commit()
