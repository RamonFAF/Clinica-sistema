"""Dependências do FastAPI: usuário logado, papéis e proteção CSRF."""
import datetime as dt
from dataclasses import dataclass

from fastapi import Depends, HTTPException, Request
from sqlalchemy.orm import Session

from . import config, settings_store
from .db import get_db
from .models import Professional, User, UserSession
from .security import token_hash


def utcnow() -> dt.datetime:
    return dt.datetime.now(dt.timezone.utc)


def aware(value: dt.datetime) -> dt.datetime:
    return value if value.tzinfo else value.replace(tzinfo=dt.timezone.utc)


@dataclass
class Auth:
    user: User
    session: UserSession
    db: Session

    @property
    def professional(self) -> Professional | None:
        return self.user.professional

    @property
    def is_admin(self) -> bool:
        return self.user.role == "admin"

    @property
    def is_staff(self) -> bool:
        """Administração ou recepção (gestão da clínica)."""
        return self.user.role in ("admin", "reception")


def csrf_guard(request: Request) -> None:
    # Cookie SameSite=Strict + cabeçalho obrigatório em requisições que alteram dados.
    if request.method not in ("GET", "HEAD", "OPTIONS") and request.headers.get("x-requested-with") != "fetch":
        raise HTTPException(403, "Requisição recusada (CSRF).")


def _load_session(request: Request, db: Session) -> UserSession:
    token = request.cookies.get(config.COOKIE_NAME)
    if not token:
        raise HTTPException(401, {"code": "not_authenticated", "message": "Faça login para continuar."})
    sess = db.query(UserSession).filter_by(token_hash=token_hash(token)).first()
    now = utcnow()
    if not sess or aware(sess.expires_at) < now:
        raise HTTPException(401, {"code": "session_expired", "message": "Sua sessão expirou. Entre novamente."})
    idle = settings_store.get(db, "session_idle_minutes")
    if aware(sess.last_seen_at) < now - dt.timedelta(minutes=idle):
        db.delete(sess)
        db.commit()
        raise HTTPException(401, {"code": "session_idle", "message": "Sessão encerrada por inatividade. Entre novamente."})
    if not sess.user.is_active:
        raise HTTPException(401, {"code": "inactive", "message": "Usuário desativado."})
    if (now - aware(sess.last_seen_at)).total_seconds() > 30:
        sess.last_seen_at = now
        db.commit()
    return sess


def session_auth(request: Request, db: Session = Depends(get_db), _=Depends(csrf_guard)) -> Auth:
    """Sessão válida, mas pode estar pendente de 2FA / troca de senha (usada nas rotas de /auth)."""
    sess = _load_session(request, db)
    return Auth(user=sess.user, session=sess, db=db)


def current(request: Request, db: Session = Depends(get_db), _=Depends(csrf_guard)) -> Auth:
    """Usuário totalmente autenticado: senha + 2FA concluídos."""
    sess = _load_session(request, db)
    user = sess.user
    if user.totp_enabled and not sess.mfa_passed:
        raise HTTPException(401, {"code": "mfa_required", "message": "Informe o código de verificação."})
    if user.must_change_password:
        raise HTTPException(403, {"code": "password_change_required", "message": "Troque sua senha provisória."})
    if settings_store.get(db, "mfa_required") and not user.totp_enabled:
        raise HTTPException(403, {"code": "mfa_setup_required", "message": "Ative a verificação em duas etapas."})
    return Auth(user=user, session=sess, db=db)


def staff(auth: Auth = Depends(current)) -> Auth:
    if not auth.is_staff:
        raise HTTPException(403, "Acesso restrito à administração da clínica.")
    return auth


def admin(auth: Auth = Depends(current)) -> Auth:
    if not auth.is_admin:
        raise HTTPException(403, "Acesso restrito ao administrador.")
    return auth
