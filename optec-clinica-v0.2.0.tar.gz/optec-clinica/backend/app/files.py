"""Upload de imagens: valida com Pillow, reduz e regrava em WebP (remove metadados/EXIF)."""
import io
import uuid
from pathlib import Path

from fastapi import HTTPException, UploadFile
from PIL import Image, ImageOps, UnidentifiedImageError

from . import config

ALLOWED_FORMATS = {"JPEG", "PNG", "WEBP", "GIF"}


def save_image(upload: UploadFile, folder: str, max_size: int, keep_alpha: bool = False) -> str:
    raw = upload.file.read(config.MAX_PHOTO_BYTES + 1)
    if len(raw) > config.MAX_PHOTO_BYTES:
        raise HTTPException(413, "Imagem maior que 5 MB.")
    try:
        img = Image.open(io.BytesIO(raw))
        if img.format not in ALLOWED_FORMATS:
            raise HTTPException(415, "Formato não aceito. Envie JPG, PNG ou WebP.")
        img.load()
    except (UnidentifiedImageError, OSError):
        raise HTTPException(415, "Arquivo não é uma imagem válida.") from None
    img = ImageOps.exif_transpose(img)
    img = img.convert("RGBA" if keep_alpha else "RGB")
    img.thumbnail((max_size, max_size))
    dest = config.UPLOAD_DIR / folder
    dest.mkdir(parents=True, exist_ok=True)
    name = f"{uuid.uuid4().hex}.webp"
    img.save(dest / name, "WEBP", quality=86)
    return name


def delete_file(folder: str, name: str | None) -> None:
    if not name:
        return
    path = (config.UPLOAD_DIR / folder / Path(name).name)
    path.unlink(missing_ok=True)


def file_path(folder: str, name: str) -> Path:
    path = config.UPLOAD_DIR / folder / Path(name).name
    if not path.is_file():
        raise HTTPException(404, "Arquivo não encontrado.")
    return path


# ---------- anexos do prontuário: cifrados com a ENCRYPTION_KEY ----------
MAX_ATTACHMENT_BYTES = 15 * 1024 * 1024
ATTACHMENT_TYPES = {
    b"%PDF": "application/pdf", b"\x89PNG": "image/png", b"\xff\xd8\xff": "image/jpeg", b"RIFF": "image/webp",
}


def _sniff(raw: bytes) -> str | None:
    for magic, mime in ATTACHMENT_TYPES.items():
        if raw.startswith(magic):
            if mime == "image/webp" and raw[8:12] != b"WEBP":
                continue
            return mime
    return None


def save_encrypted(upload: UploadFile) -> tuple[str, str, int]:
    from .crypto import fernet
    raw = upload.file.read(MAX_ATTACHMENT_BYTES + 1)
    if len(raw) > MAX_ATTACHMENT_BYTES:
        raise HTTPException(413, "Arquivo maior que 15 MB.")
    if not raw:
        raise HTTPException(422, "Arquivo vazio.")
    mime = _sniff(raw)
    if not mime:
        raise HTTPException(415, "Formato não aceito. Envie PDF, JPG, PNG ou WebP.")
    dest = config.UPLOAD_DIR / "attachments"
    dest.mkdir(parents=True, exist_ok=True)
    name = f"{uuid.uuid4().hex}.bin"
    (dest / name).write_bytes(fernet().encrypt(raw))
    return name, mime, len(raw)


def read_encrypted(name: str) -> bytes:
    from .crypto import fernet
    return fernet().decrypt(file_path("attachments", name).read_bytes())
