import datetime as dt

from fastapi import APIRouter, Depends, HTTPException, Request, Response
from pydantic import BaseModel
from sqlalchemy.orm import Session

from .. import audit, config, settings_store
from ..db import get_db
from ..deps import Auth, aware, csrf_guard, session_auth, utcnow
from ..models import User, UserSession
from ..security import (hash_password, new_token, new_totp_secret, password_problem, token_hash, totp_qr_data_uri,
                        totp_uri, verify_password, verify_totp)
from .serializers import user_out

router = APIRouter(prefix="/auth", tags=["auth"])


class LoginIn(BaseModel):
    email: str
    password: str


class CodeIn(BaseModel):
    code: str


class PasswordIn(BaseModel):
    current_password: str
    new_password: str


def state(auth_user: User, sess: UserSession, db: Session) -> dict:
    mfa_required = settings_store.get(db, "mfa_required")
    return {
        "user": user_out(auth_user),
        "mfa_pending": auth_user.totp_enabled and not sess.mfa_passed,
        "password_change_required": auth_user.must_change_password,
        "mfa_setup_required": bool(mfa_required and not auth_user.totp_enabled),
    }


@router.post("/login", dependencies=[Depends(csrf_guard)])
def login(body: LoginIn, request: Request, response: Response, db: Session = Depends(get_db)):
    email = body.email.strip().lower()
    user = db.query(User).filter_by(email=email).first()
    now = utcnow()
    if user and user.locked_until and aware(user.locked_until) > now:
        mins = int((aware(user.locked_until) - now).total_seconds() // 60) + 1
        audit.log(db, request, user.id, "login_blocked")
        raise HTTPException(429, f"Muitas tentativas. Tente de novo em {mins} min.")
    ok = verify_password(body.password, user.password_hash if user else None)
    if not ok or not user or not user.is_active:
        if user:
            user.failed_logins += 1
            if user.failed_logins >= settings_store.get(db, "max_failed_logins"):
                user.locked_until = now + dt.timedelta(minutes=settings_store.get(db, "lockout_minutes"))
                user.failed_logins = 0
        audit.log(db, request, user.id if user else None, "login_failed", detail=email)
        raise HTTPException(401, "E-mail ou senha inválidos.")
    user.failed_logins = 0
    user.locked_until = None
    user.last_login_at = now
    token = new_token()
    sess = UserSession(token_hash=token_hash(token), user_id=user.id, mfa_passed=not user.totp_enabled,
                       created_at=now, last_seen_at=now, expires_at=now + dt.timedelta(hours=config.SESSION_MAX_HOURS),
                       ip=audit.client_ip(request), user_agent=(request.headers.get("user-agent") or "")[:300])
    db.add(sess)
    audit.log(db, request, user.id, "login", commit=False)
    db.commit()
    response.set_cookie(config.COOKIE_NAME, token, httponly=True, secure=config.COOKIE_SECURE, samesite="strict",
                        max_age=config.SESSION_MAX_HOURS * 3600, path="/")
    return state(user, sess, db)


@router.get("/me")
def me(auth: Auth = Depends(session_auth)):
    return state(auth.user, auth.session, auth.db)


@router.post("/mfa")
def mfa(body: CodeIn, request: Request, auth: Auth = Depends(session_auth)):
    if not auth.user.totp_enabled:
        raise HTTPException(400, "A verificação em duas etapas não está ativa.")
    if not verify_totp(auth.user.totp_secret, body.code):
        audit.log(auth.db, request, auth.user.id, "mfa_failed")
        raise HTTPException(401, "Código inválido. Confira o horário do celular e tente de novo.")
    auth.session.mfa_passed = True
    audit.log(auth.db, request, auth.user.id, "mfa_ok")
    return state(auth.user, auth.session, auth.db)


@router.post("/logout")
def logout(request: Request, response: Response, auth: Auth = Depends(session_auth)):
    audit.log(auth.db, request, auth.user.id, "logout", commit=False)
    auth.db.delete(auth.session)
    auth.db.commit()
    response.delete_cookie(config.COOKIE_NAME, path="/")
    return {"ok": True}


@router.post("/password")
def change_password(body: PasswordIn, request: Request, auth: Auth = Depends(session_auth)):
    if auth.user.totp_enabled and not auth.session.mfa_passed:
        raise HTTPException(401, {"code": "mfa_required", "message": "Informe o código de verificação."})
    if not verify_password(body.current_password, auth.user.password_hash):
        raise HTTPException(400, "Senha atual incorreta.")
    problem = password_problem(body.new_password, settings_store.get(auth.db, "min_password_length"))
    if problem:
        raise HTTPException(400, problem)
    if body.new_password == body.current_password:
        raise HTTPException(400, "A nova senha precisa ser diferente da atual.")
    auth.user.password_hash = hash_password(body.new_password)
    auth.user.must_change_password = False
    # Encerra as outras sessões do usuário.
    auth.db.query(UserSession).filter(UserSession.user_id == auth.user.id, UserSession.id != auth.session.id).delete()
    audit.log(auth.db, request, auth.user.id, "password_changed", commit=False)
    auth.db.commit()
    return state(auth.user, auth.session, auth.db)


@router.post("/mfa/setup")
def mfa_setup(auth: Auth = Depends(session_auth)):
    if auth.user.totp_enabled:
        raise HTTPException(400, "A verificação em duas etapas já está ativa.")
    secret = new_totp_secret()
    auth.user.totp_secret = secret
    auth.db.commit()
    issuer = settings_store.get(auth.db, "clinic_name") or "Clinica"
    uri = totp_uri(secret, auth.user.email, issuer)
    return {"secret": secret, "uri": uri, "qr": totp_qr_data_uri(uri)}


@router.post("/mfa/enable")
def mfa_enable(body: CodeIn, request: Request, auth: Auth = Depends(session_auth)):
    if auth.user.totp_enabled:
        raise HTTPException(400, "A verificação em duas etapas já está ativa.")
    if not verify_totp(auth.user.totp_secret, body.code):
        raise HTTPException(400, "Código inválido. Escaneie o QR de novo e digite o código atual.")
    auth.user.totp_enabled = True
    auth.session.mfa_passed = True
    audit.log(auth.db, request, auth.user.id, "mfa_enabled", commit=False)
    auth.db.commit()
    return state(auth.user, auth.session, auth.db)


@router.get("/sessions")
def my_sessions(auth: Auth = Depends(session_auth)):
    rows = auth.db.query(UserSession).filter_by(user_id=auth.user.id).order_by(UserSession.last_seen_at.desc()).all()
    return [{"id": s.id, "current": s.id == auth.session.id, "ip": s.ip, "user_agent": s.user_agent,
             "created_at": s.created_at, "last_seen_at": s.last_seen_at} for s in rows]


@router.delete("/sessions/{sid}")
def end_session(sid: int, request: Request, auth: Auth = Depends(session_auth)):
    s = auth.db.get(UserSession, sid)
    if not s or s.user_id != auth.user.id:
        raise HTTPException(404, "Sessão não encontrada.")
    auth.db.delete(s)
    audit.log(auth.db, request, auth.user.id, "session_revoked", "session", sid, commit=False)
    auth.db.commit()
    return {"ok": True}
