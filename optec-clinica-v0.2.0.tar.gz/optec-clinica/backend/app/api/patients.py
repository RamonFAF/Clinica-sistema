import datetime as dt
import json

from fastapi import APIRouter, Depends, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import Response
from pydantic import BaseModel
from sqlalchemy import or_

from .. import audit, files, record_templates
from ..access import (accessible_patient_ids_query, can_see_entry, care_patient, get_patient, in_care, is_owner,
                      my_pid, team_ids)
from ..deps import Auth, current, utcnow
from ..models import Appointment, Attachment, Patient, PatientTeam, Professional, RecordEntry
from ..util import parse_date
from .serializers import appointment_out, patient_out

router = APIRouter(prefix="/patients", tags=["patients"])

PATIENT_FIELDS = ("name", "phone", "email", "cpf", "rg", "sex", "marital_status", "occupation", "address", "insurance",
                  "guardian", "consent_care", "consent_ehr", "consent_shared", "consent_whatsapp", "archived")
CONSENTS = ("consent_care", "consent_ehr", "consent_shared", "consent_whatsapp")


class PatientIn(BaseModel):
    professional_id: int | None = None
    name: str
    phone: str | None = None
    email: str | None = None
    birth_date: str | None = None
    cpf: str | None = None
    rg: str | None = None
    sex: str | None = None
    marital_status: str | None = None
    occupation: str | None = None
    address: str | None = None
    insurance: str | None = None
    guardian: str | None = None
    notes: str | None = None
    consent_care: bool = False
    consent_ehr: bool = False
    consent_shared: bool = False
    consent_whatsapp: bool = False
    archived: bool = False


class RecordIn(BaseModel):
    kind: str = "note"
    template: str | None = None
    visibility: str | None = None
    title: str | None = None
    content: str | None = None
    data: dict | None = None
    parent_id: int | None = None


class TeamIn(BaseModel):
    professional_id: int


def out(auth: Auth, p: Patient) -> dict:
    o = patient_out(p, full=True)
    if not in_care(auth, p):
        o.pop("notes")  # alertas clínicos só para quem atende
    o["team"] = sorted(team_ids(auth, p.id))
    o["record_number"] = f"{p.id:06d}"
    return o


@router.get("")
def list_patients(q: str | None = None, professional_id: int | None = None, archived: bool = False,
                  auth: Auth = Depends(current)):
    query = auth.db.query(Patient).filter(Patient.archived.is_(archived))
    if not auth.is_staff:
        query = accessible_patient_ids_query(auth, query)
    if professional_id:
        sub = auth.db.query(PatientTeam.patient_id).filter(PatientTeam.professional_id == professional_id)
        query = query.filter((Patient.professional_id == professional_id) | (Patient.id.in_(sub)))
    if q:
        like = f"%{q.strip()}%"
        query = query.filter(or_(Patient.name.ilike(like), Patient.phone.ilike(like)))
    return [patient_out(p, full=False) for p in query.order_by(Patient.name).limit(500).all()]


@router.post("")
def create_patient(body: PatientIn, request: Request, auth: Auth = Depends(current)):
    pid = body.professional_id if auth.is_staff and body.professional_id else my_pid(auth)
    if not pid or not auth.db.get(Professional, pid):
        raise HTTPException(422, "Informe o profissional responsável.")
    data = body.model_dump(exclude={"professional_id", "birth_date"})
    p = Patient(professional_id=pid, birth_date=parse_date(body.birth_date) if body.birth_date else None, **data)
    if any(getattr(body, c) for c in CONSENTS):
        p.consent_at = utcnow()
    auth.db.add(p)
    auth.db.flush()
    audit.log(auth.db, request, auth.user.id, "patient_created", "patient", p.id, commit=False)
    auth.db.commit()
    return out(auth, p)


@router.get("/birthdays")
def birthdays(month: int | None = None, auth: Auth = Depends(current)):
    m = month or dt.date.today().month
    query = auth.db.query(Patient).filter(Patient.archived.is_(False), Patient.birth_date.isnot(None))
    if not auth.is_staff:
        query = accessible_patient_ids_query(auth, query)
    rows = [p for p in query.all() if p.birth_date.month == m]
    rows.sort(key=lambda p: p.birth_date.day)
    return [{"id": p.id, "name": p.name, "phone": p.phone, "birth_date": p.birth_date.isoformat(),
             "consent_whatsapp": p.consent_whatsapp, "turns": dt.date.today().year - p.birth_date.year} for p in rows]


@router.get("/templates")
def templates(auth: Auth = Depends(current)):
    return record_templates.TEMPLATES


@router.get("/{pid}")
def read_patient(pid: int, request: Request, auth: Auth = Depends(current)):
    p = get_patient(auth, pid)
    audit.log(auth.db, request, auth.user.id, "patient_viewed", "patient", p.id)
    return out(auth, p)


@router.put("/{pid}")
def update_patient(pid: int, body: PatientIn, request: Request, auth: Auth = Depends(current)):
    p = get_patient(auth, pid)
    consent_changed = any(getattr(body, c) != getattr(p, c) for c in CONSENTS)
    for k in PATIENT_FIELDS:
        setattr(p, k, getattr(body, k))
    p.birth_date = parse_date(body.birth_date) if body.birth_date else None
    if in_care(auth, p):
        p.notes = body.notes
    if auth.is_staff and body.professional_id and body.professional_id != p.professional_id:
        if not auth.db.get(Professional, body.professional_id):
            raise HTTPException(422, "Profissional não encontrado.")
        p.professional_id = body.professional_id
    if consent_changed:
        p.consent_at = utcnow()
    audit.log(auth.db, request, auth.user.id, "patient_updated", "patient", p.id,
              "consentimento alterado" if consent_changed else None, commit=False)
    auth.db.commit()
    return out(auth, p)


@router.get("/{pid}/appointments")
def patient_appointments(pid: int, auth: Auth = Depends(current)):
    p = get_patient(auth, pid)
    rows = auth.db.query(Appointment).filter_by(patient_id=p.id).order_by(Appointment.date.desc(), Appointment.start.desc()).all()
    return [appointment_out(a) for a in rows]


# ---------- equipe de cuidado ----------

@router.post("/{pid}/team")
def add_team(pid: int, body: TeamIn, request: Request, auth: Auth = Depends(current)):
    p = get_patient(auth, pid)
    if not (is_owner(auth, p) or auth.is_staff):
        raise HTTPException(403, "Só o profissional responsável ou a administração alteram a equipe.")
    prof = auth.db.get(Professional, body.professional_id)
    if not prof or not prof.attends:
        raise HTTPException(404, "Profissional não encontrado.")
    if body.professional_id != p.professional_id and not auth.db.query(PatientTeam).filter_by(patient_id=pid, professional_id=body.professional_id).first():
        auth.db.add(PatientTeam(patient_id=pid, professional_id=body.professional_id))
        audit.log(auth.db, request, auth.user.id, "team_added", "patient", pid, prof.user.name, commit=False)
        auth.db.commit()
    return out(auth, p)


@router.delete("/{pid}/team/{prof_id}")
def remove_team(pid: int, prof_id: int, request: Request, auth: Auth = Depends(current)):
    p = get_patient(auth, pid)
    if not (is_owner(auth, p) or auth.is_staff):
        raise HTTPException(403, "Só o profissional responsável ou a administração alteram a equipe.")
    auth.db.query(PatientTeam).filter_by(patient_id=pid, professional_id=prof_id).delete()
    audit.log(auth.db, request, auth.user.id, "team_removed", "patient", pid, str(prof_id), commit=False)
    auth.db.commit()
    return out(auth, p)


# ---------- prontuário ----------

def record_out(e: RecordEntry, names: dict[int, tuple[str, str | None]]) -> dict:
    tpl = record_templates.BY_KEY.get(e.template or "")
    data = json.loads(e.data) if e.data else None
    name, specialty = names.get(e.professional_id, ("", None))
    return {"id": e.id, "kind": e.kind, "template": e.template, "template_name": tpl["name"] if tpl else None,
            "visibility": e.visibility, "title": e.title, "content": e.content, "data": data, "parent_id": e.parent_id,
            "created_at": e.created_at, "professional_id": e.professional_id, "author": name, "author_specialty": specialty,
            "alerts": record_templates.alerts(e.template, data) if (tpl and data) else []}


def prof_names(auth: Auth) -> dict[int, tuple[str, str | None]]:
    return {p.id: (p.user.name, p.specialty) for p in auth.db.query(Professional).all()}


def visible_entries(auth: Auth, p: Patient) -> list[RecordEntry]:
    rows = auth.db.query(RecordEntry).filter_by(patient_id=p.id).order_by(RecordEntry.created_at.desc()).all()
    return [e for e in rows if can_see_entry(auth, p, e.professional_id, e.visibility)]


@router.get("/{pid}/records")
def list_records(pid: int, request: Request, auth: Auth = Depends(current)):
    p = care_patient(auth, pid)
    names = prof_names(auth)
    rows = visible_entries(auth, p)
    hidden = auth.db.query(RecordEntry).filter_by(patient_id=p.id).count() - len(rows)
    audit.log(auth.db, request, auth.user.id, "record_viewed", "patient", p.id)
    return {"entries": [record_out(e, names) for e in rows], "hidden": hidden, "shared_consent": p.consent_shared}


@router.post("/{pid}/records")
def add_record(pid: int, body: RecordIn, request: Request, auth: Auth = Depends(current)):
    p = care_patient(auth, pid)
    if body.kind not in ("note", "soap", "addendum", "form"):
        raise HTTPException(422, "Tipo de registro inválido.")
    content, data_json, title = (body.content or "").strip(), None, body.title
    visibility = body.visibility
    if body.kind == "form":
        tpl = record_templates.BY_KEY.get(body.template or "")
        if not tpl:
            raise HTTPException(422, "Modelo de prontuário não encontrado.")
        data = {f["key"]: (body.data or {}).get(f["key"]) for f in tpl["fields"]}
        content = record_templates.render_text(tpl["key"], data)
        data_json = json.dumps(data, ensure_ascii=False)
        title = title or tpl["name"]
        visibility = visibility or tpl["visibility"]
    if not content:
        raise HTTPException(422, "O registro está vazio.")
    visibility = visibility or "team"
    if visibility not in ("team", "private"):
        raise HTTPException(422, "Visibilidade inválida.")
    if body.parent_id:
        parent = auth.db.get(RecordEntry, body.parent_id)
        if not parent or parent.patient_id != p.id or not can_see_entry(auth, p, parent.professional_id, parent.visibility):
            raise HTTPException(422, "Registro original não encontrado.")
        visibility = parent.visibility
    e = RecordEntry(patient_id=p.id, professional_id=my_pid(auth), kind=body.kind, template=body.template if body.kind == "form" else None,
                    visibility=visibility, title=title, content=content, data=data_json, parent_id=body.parent_id)
    auth.db.add(e)
    auth.db.flush()
    audit.log(auth.db, request, auth.user.id, "record_created", "patient", p.id, f"registro {e.id} ({visibility})", commit=False)
    auth.db.commit()
    return record_out(e, prof_names(auth))


# ---------- anexos (cifrados no disco) ----------

def attachment_out(a: Attachment, names) -> dict:
    return {"id": a.id, "filename": a.filename, "mime": a.mime, "size": a.size, "visibility": a.visibility,
            "entry_id": a.entry_id, "created_at": a.created_at, "author": names.get(a.professional_id, ("",))[0],
            "professional_id": a.professional_id}


@router.get("/{pid}/attachments")
def list_attachments(pid: int, auth: Auth = Depends(current)):
    p = care_patient(auth, pid)
    names = prof_names(auth)
    rows = auth.db.query(Attachment).filter_by(patient_id=p.id).order_by(Attachment.created_at.desc()).all()
    return [attachment_out(a, names) for a in rows if can_see_entry(auth, p, a.professional_id, a.visibility)]


@router.post("/{pid}/attachments")
def upload_attachment(pid: int, request: Request, file: UploadFile = File(...), visibility: str = Form("team"),
                      entry_id: int | None = Form(None), auth: Auth = Depends(current)):
    p = care_patient(auth, pid)
    if visibility not in ("team", "private"):
        raise HTTPException(422, "Visibilidade inválida.")
    stored, mime, size = files.save_encrypted(file)
    a = Attachment(patient_id=p.id, professional_id=my_pid(auth), entry_id=entry_id, filename=(file.filename or "arquivo")[:200],
                   mime=mime, size=size, stored_name=stored, visibility=visibility)
    auth.db.add(a)
    auth.db.flush()
    audit.log(auth.db, request, auth.user.id, "attachment_uploaded", "patient", p.id, f"anexo {a.id}", commit=False)
    auth.db.commit()
    return attachment_out(a, prof_names(auth))


@router.get("/{pid}/attachments/{aid}")
def download_attachment(pid: int, aid: int, request: Request, auth: Auth = Depends(current)):
    p = care_patient(auth, pid)
    a = auth.db.get(Attachment, aid)
    if not a or a.patient_id != p.id or not can_see_entry(auth, p, a.professional_id, a.visibility):
        raise HTTPException(404, "Anexo não encontrado.")
    audit.log(auth.db, request, auth.user.id, "attachment_viewed", "patient", p.id, f"anexo {a.id}")
    safe = "".join(ch for ch in a.filename if ch.isalnum() or ch in "._- ")[:100] or "arquivo"
    return Response(files.read_encrypted(a.stored_name), media_type=a.mime,
                    headers={"Content-Disposition": f'inline; filename="{safe}"', "Cache-Control": "no-store"})


# ---------- exportações ----------

@router.get("/{pid}/export")
def export_patient(pid: int, request: Request, auth: Auth = Depends(current)):
    """Portabilidade (LGPD art. 18): dados do paciente e registros visíveis para quem exporta, em JSON."""
    p = care_patient(auth, pid)
    names = prof_names(auth)
    appts = auth.db.query(Appointment).filter_by(patient_id=p.id).order_by(Appointment.date).all()
    audit.log(auth.db, request, auth.user.id, "patient_exported", "patient", p.id)
    return {"exported_at": dt.datetime.now(dt.timezone.utc).isoformat(), "patient": patient_out(p, full=True),
            "appointments": [appointment_out(a) for a in appts],
            "records": [record_out(e, names) for e in reversed(visible_entries(auth, p))]}


@router.get("/{pid}/record.pdf")
def record_pdf(pid: int, request: Request, auth: Auth = Depends(current)):
    from .. import pdfs
    p = care_patient(auth, pid)
    names = prof_names(auth)
    entries = [record_out(e, names) for e in reversed(visible_entries(auth, p))]
    team = [auth.db.get(Professional, i) for i in sorted(team_ids(auth, p.id) | {p.professional_id})]
    pdf = pdfs.record_pdf(auth.db, p, entries, [t for t in team if t])
    audit.log(auth.db, request, auth.user.id, "record_pdf", "patient", p.id)
    return Response(pdf, media_type="application/pdf",
                    headers={"Content-Disposition": f'inline; filename="prontuario-{p.id:06d}.pdf"', "Cache-Control": "no-store"})
