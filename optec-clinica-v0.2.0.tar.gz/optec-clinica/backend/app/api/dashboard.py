import datetime as dt

from fastapi import APIRouter, Depends

from .. import settings_store
from ..deps import Auth, current
from ..access import accessible_patient_ids_query
from ..models import Appointment, Patient, Professional, Reservation, Room, WaitlistEntry
from ..util import hours_between, month_range, parse_date, parse_time
from .finance import invoice_for, rooms_map
from .serializers import appointment_out

router = APIRouter(prefix="/dashboard", tags=["dashboard"])


@router.get("")
def dashboard(date: str | None = None, auth: Auth = Depends(current)):
    day = parse_date(date) if date else dt.date.today()
    month = day.strftime("%Y-%m")
    first, last = month_range(month)
    s = settings_store.get_all(auth.db)
    window = hours_between(parse_time(s["open_time"]), parse_time(s["close_time"]))
    rooms = auth.db.query(Room).filter(Room.active.is_(True)).order_by(Room.sort_order, Room.id).all()
    open_days = sum(1 for i in range((last - first).days + 1) if (first + dt.timedelta(i)).weekday() in s["open_weekdays"])
    out: dict = {"date": day.isoformat(), "role": auth.user.role}

    q = auth.db.query(Appointment).filter(Appointment.date == day, Appointment.status != "canceled")
    mine = auth.professional
    if not auth.is_staff:
        q = q.filter(Appointment.professional_id == (mine.id if mine else -1))
    today = q.order_by(Appointment.start).all()
    out["today"] = [appointment_out(a) for a in today]
    out["today_confirmed"] = sum(1 for a in today if a.status in ("confirmed", "done"))

    if auth.is_staff:
        day_res = auth.db.query(Reservation).filter(Reservation.date == day).all()
        out["occupancy_today"] = sum(hours_between(r.start, r.end) for r in day_res) / (window * max(len(rooms), 1))
        per_room = []
        for r in rooms:
            res = auth.db.query(Reservation).filter(Reservation.room_id == r.id, Reservation.date >= first,
                                                    Reservation.date <= last).all()
            used = sum(hours_between(x.start, x.end) for x in res)
            per_room.append({"room_id": r.id, "name": r.name, "occupancy": used / max(window * open_days, 1),
                             "revenue": used * r.hourly_rate})
        out["rooms"] = per_room
        out["professionals"] = auth.db.query(Professional).filter(Professional.attends.is_(True)).count()
        out["patients"] = auth.db.query(Patient).filter(Patient.archived.is_(False)).count()
        if auth.is_admin:
            rmap = rooms_map(auth.db)
            invs = [invoice_for(auth.db, p, month, rmap) for p in auth.db.query(Professional).filter(Professional.attends.is_(True))]
            out["invoiced_month"] = sum(i["amount"] for i in invs)
            out["open_month"] = sum(i["amount"] for i in invs if not i["paid"])
            out["open_count"] = sum(1 for i in invs if not i["paid"] and i["amount"] > 0)
    if mine:
        appts = auth.db.query(Appointment).filter(Appointment.professional_id == mine.id, Appointment.date >= first,
                                                  Appointment.date <= last, Appointment.status.in_(("scheduled", "confirmed", "done"))).all()
        out["my_month"] = {"appointments": len(appts), "received": sum(a.price for a in appts if a.paid),
                           "pending": sum(a.price for a in appts if not a.paid),
                           "patients": auth.db.query(Patient).filter_by(professional_id=mine.id, archived=False).count()}
        week_end = day + dt.timedelta(days=7)
        nxt = auth.db.query(Reservation).filter(Reservation.professional_id == mine.id, Reservation.date >= day,
                                                Reservation.date <= week_end).order_by(Reservation.date, Reservation.start).limit(8).all()
        names = {r.id: r.name for r in rooms}
        out["my_rooms"] = [{"date": r.date.isoformat(), "start": r.start.strftime("%H:%M"), "end": r.end.strftime("%H:%M"),
                            "room": names.get(r.room_id, "Sala")} for r in nxt]
    # Pendências de comunicação (WhatsApp sem API: a equipe envia pelo link)
    tomorrow = day + dt.timedelta(days=1)
    q2 = auth.db.query(Appointment).filter(Appointment.date == tomorrow, Appointment.status.in_(("scheduled", "confirmed")))
    q3 = auth.db.query(Appointment).filter(Appointment.patient_response == "reschedule", Appointment.date >= day,
                                           Appointment.status.in_(("scheduled", "confirmed")))
    if not auth.is_staff:
        q2 = q2.filter(Appointment.professional_id == (mine.id if mine else -1))
        q3 = q3.filter(Appointment.professional_id == (mine.id if mine else -1))
    out["reminders_pending"] = sum(1 for a in q2.all() if not a.reminder_sent_at)
    out["reschedule_requests"] = [appointment_out(a) for a in q3.order_by(Appointment.date, Appointment.start).limit(10)]
    pq = auth.db.query(Patient).filter(Patient.archived.is_(False), Patient.birth_date.isnot(None))
    if not auth.is_staff:
        pq = accessible_patient_ids_query(auth, pq)
    out["birthdays_today"] = [{"id": p.id, "name": p.name} for p in pq.all()
                              if (p.birth_date.month, p.birth_date.day) == (day.month, day.day)]
    wq = auth.db.query(WaitlistEntry).filter(WaitlistEntry.status == "waiting")
    out["waitlist"] = sum(1 for w in wq.all() if auth.is_staff or w.professional_id in (None, mine.id if mine else -1))
    return out
