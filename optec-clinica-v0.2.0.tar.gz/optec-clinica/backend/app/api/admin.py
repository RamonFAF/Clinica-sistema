from fastapi import APIRouter, Depends, File, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse

from .. import audit, files, settings_store
from ..db import get_db
from ..deps import Auth, admin, current
from ..models import AuditLog, User

router = APIRouter(tags=["admin"])


@router.get("/public/branding")
def branding(db=Depends(get_db)):
    s = settings_store.get_all(db)
    return {k: s[k] for k in settings_store.PUBLIC_KEYS} | {"logo_url": f"/api/public/logo/{s['logo']}" if s["logo"] else None}


@router.get("/public/logo/{name}")
def logo(name: str):
    return FileResponse(files.file_path("branding", name), headers={"Cache-Control": "public, max-age=86400"})


@router.get("/settings")
def get_settings(auth: Auth = Depends(current)):
    s = settings_store.get_all(auth.db)
    s["logo_url"] = f"/api/public/logo/{s['logo']}" if s["logo"] else None
    return s


@router.put("/settings")
def put_settings(body: dict, request: Request, auth: Auth = Depends(admin)):
    try:
        s = settings_store.update(auth.db, body)
    except ValueError as e:
        raise HTTPException(422, str(e)) from None
    audit.log(auth.db, request, auth.user.id, "settings_updated", detail=", ".join(sorted(body.keys()))[:500])
    s["logo_url"] = f"/api/public/logo/{s['logo']}" if s["logo"] else None
    return s


@router.post("/settings/logo")
def upload_logo(request: Request, file: UploadFile = File(...), auth: Auth = Depends(admin)):
    name = files.save_image(file, "branding", 800, keep_alpha=True)
    files.delete_file("branding", settings_store.get(auth.db, "logo"))
    settings_store.set_value(auth.db, "logo", name)
    audit.log(auth.db, request, auth.user.id, "logo_updated")
    return {"logo_url": f"/api/public/logo/{name}"}


@router.delete("/settings/logo")
def delete_logo(auth: Auth = Depends(admin)):
    files.delete_file("branding", settings_store.get(auth.db, "logo"))
    settings_store.set_value(auth.db, "logo", None)
    return {"logo_url": None}


@router.get("/files/photos/{name}")
def photo(name: str, auth: Auth = Depends(current)):
    return FileResponse(files.file_path("photos", name), headers={"Cache-Control": "private, max-age=3600"})


@router.get("/audit")
def audit_list(limit: int = 200, action: str | None = None, user_id: int | None = None, auth: Auth = Depends(admin)):
    q = auth.db.query(AuditLog, User.name).outerjoin(User, User.id == AuditLog.user_id)
    if action:
        q = q.filter(AuditLog.action == action)
    if user_id:
        q = q.filter(AuditLog.user_id == user_id)
    rows = q.order_by(AuditLog.at.desc()).limit(min(limit, 1000)).all()
    return [{"id": a.id, "at": a.at, "user": name, "action": a.action, "entity": a.entity, "entity_id": a.entity_id,
             "ip": a.ip, "detail": a.detail} for a, name in rows]
