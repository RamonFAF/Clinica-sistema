from fastapi import APIRouter, Depends, File, HTTPException, Request, UploadFile
from pydantic import BaseModel, EmailStr

from .. import audit, files
from ..deps import Auth, admin, current
from ..models import Professional, User, UserSession
from ..security import hash_password, temp_password
from .serializers import professional_out

router = APIRouter(prefix="/professionals", tags=["professionals"])


class ProfessionalIn(BaseModel):
    name: str
    email: EmailStr
    role: str = "professional"
    council: str | None = None
    document: str | None = None
    specialty: str | None = None
    phone: str | None = None
    color: str = "#0f766e"
    billing_model: str = "hourly"
    monthly_fee: float = 0
    percent: float = 0
    bio: str | None = None
    attends: bool = True
    is_active: bool = True


class SelfIn(BaseModel):
    phone: str | None = None
    document: str | None = None
    color: str | None = None
    bio: str | None = None
    specialty: str | None = None


def _validate(body: ProfessionalIn) -> None:
    if body.role not in ("admin", "reception", "professional"):
        raise HTTPException(422, "Perfil inválido.")
    if body.billing_model not in ("hourly", "monthly", "percent"):
        raise HTTPException(422, "Modelo de cobrança inválido.")


def _get(auth: Auth, pid: int) -> Professional:
    p = auth.db.get(Professional, pid)
    if not p:
        raise HTTPException(404, "Profissional não encontrado.")
    return p


@router.get("")
def list_professionals(auth: Auth = Depends(current)):
    rows = auth.db.query(Professional).join(User).order_by(User.name).all()
    out = [professional_out(p) for p in rows]
    if not auth.is_admin:
        mine = auth.professional.id if auth.professional else None
        for o in (x for x in out if x["id"] != mine):  # dados de cobrança e conta só para o administrador (ou o próprio)
            for k in ("billing_model", "monthly_fee", "percent", "email", "totp_enabled", "last_login_at", "document"):
                o.pop(k, None)
    return out


@router.post("")
def create_professional(body: ProfessionalIn, request: Request, auth: Auth = Depends(admin)):
    _validate(body)
    email = body.email.lower()
    if auth.db.query(User).filter_by(email=email).first():
        raise HTTPException(409, "Já existe um usuário com este e-mail.")
    pwd = temp_password()
    user = User(email=email, name=body.name.strip(), role=body.role, password_hash=hash_password(pwd),
                must_change_password=True, is_active=body.is_active)
    prof = Professional(user=user, **body.model_dump(exclude={"name", "email", "role", "is_active"}))
    auth.db.add_all([user, prof])
    auth.db.flush()
    audit.log(auth.db, request, auth.user.id, "professional_created", "professional", prof.id, body.name, commit=False)
    auth.db.commit()
    return {**professional_out(prof), "temp_password": pwd}


@router.put("/{pid}")
def update_professional(pid: int, body: ProfessionalIn, request: Request, auth: Auth = Depends(admin)):
    _validate(body)
    p = _get(auth, pid)
    email = body.email.lower()
    other = auth.db.query(User).filter_by(email=email).first()
    if other and other.id != p.user_id:
        raise HTTPException(409, "Já existe um usuário com este e-mail.")
    if p.user_id == auth.user.id and (body.role != "admin" or not body.is_active):
        raise HTTPException(400, "Você não pode remover o seu próprio acesso de administrador.")
    p.user.name, p.user.email, p.user.role, p.user.is_active = body.name.strip(), email, body.role, body.is_active
    for k, v in body.model_dump(exclude={"name", "email", "role", "is_active"}).items():
        setattr(p, k, v)
    if not body.is_active:
        auth.db.query(UserSession).filter_by(user_id=p.user_id).delete()
    audit.log(auth.db, request, auth.user.id, "professional_updated", "professional", p.id, commit=False)
    auth.db.commit()
    return professional_out(p)


@router.post("/{pid}/reset-password")
def reset_password(pid: int, request: Request, auth: Auth = Depends(admin)):
    p = _get(auth, pid)
    pwd = temp_password()
    p.user.password_hash = hash_password(pwd)
    p.user.must_change_password = True
    p.user.failed_logins, p.user.locked_until = 0, None
    auth.db.query(UserSession).filter_by(user_id=p.user_id).delete()
    audit.log(auth.db, request, auth.user.id, "password_reset", "professional", p.id, commit=False)
    auth.db.commit()
    return {"temp_password": pwd}


@router.post("/{pid}/reset-mfa")
def reset_mfa(pid: int, request: Request, auth: Auth = Depends(admin)):
    p = _get(auth, pid)
    p.user.totp_enabled, p.user.totp_secret = False, None
    auth.db.query(UserSession).filter_by(user_id=p.user_id).delete()
    audit.log(auth.db, request, auth.user.id, "mfa_reset", "professional", p.id, commit=False)
    auth.db.commit()
    return {"ok": True}


@router.put("/me/profile")
def update_self(body: SelfIn, request: Request, auth: Auth = Depends(current)):
    p = auth.professional
    if not p:
        raise HTTPException(404, "Seu usuário não tem perfil profissional.")
    for k, v in body.model_dump(exclude_none=True).items():
        setattr(p, k, v)
    audit.log(auth.db, request, auth.user.id, "profile_updated", "professional", p.id, commit=False)
    auth.db.commit()
    return professional_out(p)


@router.post("/{pid}/photo")
def upload_photo(pid: int, request: Request, file: UploadFile = File(...), auth: Auth = Depends(current)):
    p = _get(auth, pid)
    if not auth.is_admin and (not auth.professional or auth.professional.id != pid):
        raise HTTPException(403, "Você só pode trocar a sua própria foto.")
    name = files.save_image(file, "photos", 512)
    files.delete_file("photos", p.photo)
    p.photo = name
    audit.log(auth.db, request, auth.user.id, "photo_updated", "professional", p.id, commit=False)
    auth.db.commit()
    return professional_out(p)


@router.delete("/{pid}/photo")
def delete_photo(pid: int, auth: Auth = Depends(current)):
    p = _get(auth, pid)
    if not auth.is_admin and (not auth.professional or auth.professional.id != pid):
        raise HTTPException(403, "Você só pode remover a sua própria foto.")
    files.delete_file("photos", p.photo)
    p.photo = None
    auth.db.commit()
    return professional_out(p)
