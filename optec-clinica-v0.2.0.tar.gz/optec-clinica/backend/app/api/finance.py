import csv
import datetime as dt
import io
import uuid

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import Response
from pydantic import BaseModel
from sqlalchemy.orm import Session

from .. import audit, settings_store
from ..access import my_pid
from ..deps import Auth, admin, current
from ..models import (Appointment, Expense, InvoiceAdjustment, InvoicePayment, Patient, Professional, Reservation, Room,
                      SessionPackage)
from ..util import hours_between, month_range, parse_date

router = APIRouter(prefix="/finance", tags=["finance"])
BILLABLE = ("scheduled", "confirmed", "done")
CLINIC_CATEGORIES = ["Aluguel do imóvel", "Condomínio e IPTU", "Energia", "Água", "Internet e telefone", "Limpeza",
                     "Material de consumo", "Manutenção", "Salários e encargos", "Impostos e taxas", "Contabilidade",
                     "Marketing", "Software", "Outros"]
PRO_CATEGORIES = ["Aluguel de sala (fora da clínica)", "Conselho profissional", "Supervisão", "Cursos e formação",
                  "Material", "Impostos (carnê-leão/DAS)", "Transporte", "Software", "Marketing", "Outros"]


def shift_month(month: str, n: int) -> str:
    y, m = int(month[:4]), int(month[5:7]) + n
    y += (m - 1) // 12
    m = (m - 1) % 12 + 1
    return f"{y:04d}-{m:02d}"


def rooms_map(db: Session) -> dict[int, Room]:
    return {r.id: r for r in db.query(Room).all()}


def due_date(db: Session, month: str) -> dt.date:
    """Vencimento: dia configurado do mês seguinte ao uso."""
    nxt = shift_month(month, 1)
    return dt.date(int(nxt[:4]), int(nxt[5:7]), settings_store.get(db, "invoice_due_day"))


def invoice_for(db: Session, p: Professional, month: str, rooms: dict[int, Room], detail: bool = False) -> dict:
    first, last = month_range(month)
    joined = p.user.created_at.date() if p.user.created_at else first
    active_month = last >= joined.replace(day=1)  # não cobra meses anteriores ao cadastro
    res = db.query(Reservation).filter(Reservation.professional_id == p.id, Reservation.date >= first,
                                       Reservation.date <= last).order_by(Reservation.date, Reservation.start).all()
    hours = sum(hours_between(r.start, r.end) for r in res)
    by_hour = sum(hours_between(r.start, r.end) * (rooms[r.room_id].hourly_rate if r.room_id in rooms else 0) for r in res)
    revenue = sum(a.price for a in db.query(Appointment).filter(
        Appointment.professional_id == p.id, Appointment.date >= first, Appointment.date <= last,
        Appointment.status.in_(BILLABLE)).all())
    if p.billing_model == "monthly":
        base = p.monthly_fee if active_month else 0
    elif p.billing_model == "percent":
        base = revenue * p.percent / 100
    else:
        base = by_hour
    adjs = db.query(InvoiceAdjustment).filter_by(professional_id=p.id, month=month).all()
    amount = base + sum(a.amount for a in adjs)
    paid = db.query(InvoicePayment).filter_by(professional_id=p.id, month=month).first()
    due = due_date(db, month)
    out = {"professional_id": p.id, "name": p.user.name, "specialty": p.specialty, "billing_model": p.billing_model,
           "hours": round(hours, 2), "revenue": round(revenue, 2), "base": round(base, 2),
           "adjustments_total": round(sum(a.amount for a in adjs), 2), "amount": round(max(amount, 0), 2),
           "paid": bool(paid), "paid_at": paid.paid_at if paid else None, "payment_method": paid.payment_method if paid else None,
           "due_date": due.isoformat(), "overdue": (not paid) and amount > 0 and dt.date.today() > due, "month": month}
    if detail:
        out["reservations"] = [{"date": r.date.isoformat(), "start": r.start.strftime("%H:%M"), "end": r.end.strftime("%H:%M"),
                                "room": rooms[r.room_id].name if r.room_id in rooms else "Sala",
                                "hours": hours_between(r.start, r.end),
                                "value": hours_between(r.start, r.end) * (rooms[r.room_id].hourly_rate if r.room_id in rooms else 0)}
                               for r in res]
        out["adjustments"] = [{"id": a.id, "description": a.description, "amount": a.amount} for a in adjs]
    return out


def attending(db: Session):
    return db.query(Professional).filter(Professional.attends.is_(True)).all()


# ---------- clínica ----------

@router.get("/invoices")
def invoices(month: str, auth: Auth = Depends(admin)):
    rooms = rooms_map(auth.db)
    rows = [invoice_for(auth.db, p, month, rooms) for p in attending(auth.db)]
    return sorted([r for r in rows if r["amount"] or r["hours"] or r["adjustments_total"]], key=lambda r: r["name"])


@router.get("/invoices/{pid}/{month}")
def invoice_detail(pid: int, month: str, auth: Auth = Depends(current)):
    if not (auth.is_admin or my_pid(auth) == pid):
        raise HTTPException(403, "Acesso restrito.")
    p = auth.db.get(Professional, pid)
    if not p:
        raise HTTPException(404, "Profissional não encontrado.")
    return invoice_for(auth.db, p, month, rooms_map(auth.db), detail=True)


class PayIn(BaseModel):
    payment_method: str | None = None


@router.post("/invoices/{pid}/{month}/pay")
def pay_invoice(pid: int, month: str, request: Request, body: PayIn | None = None, auth: Auth = Depends(admin)):
    p = auth.db.get(Professional, pid)
    if not p:
        raise HTTPException(404, "Profissional não encontrado.")
    inv = invoice_for(auth.db, p, month, rooms_map(auth.db))
    if not auth.db.query(InvoicePayment).filter_by(professional_id=pid, month=month).first():
        auth.db.add(InvoicePayment(professional_id=pid, month=month, amount=inv["amount"],
                                   payment_method=(body.payment_method if body else None)))
    audit.log(auth.db, request, auth.user.id, "invoice_paid", "professional", pid, month, commit=False)
    auth.db.commit()
    return {"ok": True}


@router.delete("/invoices/{pid}/{month}/pay")
def unpay_invoice(pid: int, month: str, request: Request, auth: Auth = Depends(admin)):
    auth.db.query(InvoicePayment).filter_by(professional_id=pid, month=month).delete()
    audit.log(auth.db, request, auth.user.id, "invoice_unpaid", "professional", pid, month, commit=False)
    auth.db.commit()
    return {"ok": True}


class AdjustmentIn(BaseModel):
    description: str
    amount: float


@router.post("/invoices/{pid}/{month}/adjustments")
def add_adjustment(pid: int, month: str, body: AdjustmentIn, request: Request, auth: Auth = Depends(admin)):
    month_range(month)
    if not body.description.strip() or body.amount == 0:
        raise HTTPException(422, "Informe descrição e valor (negativo para desconto).")
    adj = InvoiceAdjustment(professional_id=pid, month=month, description=body.description.strip(), amount=body.amount)
    auth.db.add(adj)
    audit.log(auth.db, request, auth.user.id, "invoice_adjusted", "professional", pid, f"{month} {body.amount}", commit=False)
    auth.db.commit()
    return {"id": adj.id}


@router.delete("/adjustments/{aid}")
def delete_adjustment(aid: int, auth: Auth = Depends(admin)):
    auth.db.query(InvoiceAdjustment).filter_by(id=aid).delete()
    auth.db.commit()
    return {"ok": True}


def clinic_month(db: Session, month: str, rooms) -> dict:
    first, last = month_range(month)
    invs = [invoice_for(db, p, month, rooms) for p in attending(db)]
    exp = db.query(Expense).filter(Expense.professional_id.is_(None), Expense.date >= first, Expense.date <= last).all()
    billed = sum(i["amount"] for i in invs)
    received = sum(i["amount"] for i in invs if i["paid"])
    expenses = sum(e.amount for e in exp)
    return {"month": month, "billed": round(billed, 2), "received": round(received, 2), "expenses": round(expenses, 2),
            "result": round(received - expenses, 2), "projected": round(billed - expenses, 2)}


@router.get("/overview")
def overview(month: str, auth: Auth = Depends(admin)):
    rooms = rooms_map(auth.db)
    cur = clinic_month(auth.db, month, rooms)
    series = [clinic_month(auth.db, shift_month(month, -i), rooms) for i in range(5, -1, -1)]
    first, last = month_range(month)
    by_cat: dict[str, float] = {}
    for e in auth.db.query(Expense).filter(Expense.professional_id.is_(None), Expense.date >= first, Expense.date <= last):
        by_cat[e.category] = by_cat.get(e.category, 0) + e.amount
    overdue = []
    for i in range(1, 13):  # faturas em atraso dos últimos 12 meses
        m = shift_month(month, -i)
        for p in attending(auth.db):
            inv = invoice_for(auth.db, p, m, rooms)
            if inv["overdue"]:
                overdue.append(inv)
    per_room = []
    for r in rooms.values():
        res = auth.db.query(Reservation).filter(Reservation.room_id == r.id, Reservation.date >= first, Reservation.date <= last).all()
        h = sum(hours_between(x.start, x.end) for x in res)
        per_room.append({"room": r.name, "hours": h, "value": h * r.hourly_rate, "active": r.active})
    return {**cur, "series": series, "by_category": sorted(by_cat.items(), key=lambda x: -x[1]), "overdue": overdue,
            "overdue_total": round(sum(o["amount"] for o in overdue), 2), "rooms": per_room}


# ---------- despesas (clínica e profissional) ----------

class ExpenseIn(BaseModel):
    scope: str = "clinic"  # clinic | mine
    date: str
    description: str
    category: str
    amount: float
    paid: bool = True
    repeat_months: int = 1


def _expense_owner(auth: Auth, scope: str) -> int | None:
    if scope == "clinic":
        if not auth.is_admin:
            raise HTTPException(403, "Despesas da clínica são restritas ao administrador.")
        return None
    if not my_pid(auth):
        raise HTTPException(403, "Seu usuário não tem perfil profissional.")
    return my_pid(auth)


def expense_out(e: Expense) -> dict:
    return {"id": e.id, "date": e.date.isoformat(), "description": e.description, "category": e.category, "amount": e.amount,
            "paid": e.paid, "series_id": e.series_id, "scope": "clinic" if e.professional_id is None else "mine"}


@router.get("/categories")
def categories(auth: Auth = Depends(current)):
    return {"clinic": CLINIC_CATEGORIES, "mine": PRO_CATEGORIES}


@router.get("/expenses")
def list_expenses(month: str, scope: str = "clinic", auth: Auth = Depends(current)):
    owner = _expense_owner(auth, scope)
    first, last = month_range(month)
    q = auth.db.query(Expense).filter(Expense.date >= first, Expense.date <= last)
    q = q.filter(Expense.professional_id.is_(None)) if owner is None else q.filter(Expense.professional_id == owner)
    return [expense_out(e) for e in q.order_by(Expense.date).all()]


@router.post("/expenses")
def create_expense(body: ExpenseIn, request: Request, auth: Auth = Depends(current)):
    owner = _expense_owner(auth, body.scope)
    if not body.description.strip() or body.amount <= 0:
        raise HTTPException(422, "Informe descrição e valor maior que zero.")
    d0 = parse_date(body.date)
    n = max(1, min(body.repeat_months, 24))
    series = str(uuid.uuid4()) if n > 1 else None
    out = []
    for i in range(n):
        m = shift_month(d0.strftime("%Y-%m"), i)
        last = month_range(m)[1]
        d = dt.date(int(m[:4]), int(m[5:7]), min(d0.day, last.day))
        e = Expense(professional_id=owner, date=d, description=body.description.strip(), category=body.category,
                    amount=body.amount, paid=body.paid if i == 0 else False, series_id=series)
        auth.db.add(e)
        out.append(e)
    audit.log(auth.db, request, auth.user.id, "expense_created", detail=f"{body.scope} {body.amount} x{n}", commit=False)
    auth.db.commit()
    return [expense_out(e) for e in out]


def _get_expense(auth: Auth, eid: int) -> Expense:
    e = auth.db.get(Expense, eid)
    if not e:
        raise HTTPException(404, "Despesa não encontrada.")
    owner = _expense_owner(auth, "clinic" if e.professional_id is None else "mine")
    if owner != e.professional_id:
        raise HTTPException(404, "Despesa não encontrada.")
    return e


@router.put("/expenses/{eid}")
def update_expense(eid: int, body: ExpenseIn, auth: Auth = Depends(current)):
    e = _get_expense(auth, eid)
    if body.amount <= 0:
        raise HTTPException(422, "Valor deve ser maior que zero.")
    e.date, e.description, e.category, e.amount, e.paid = parse_date(body.date), body.description, body.category, body.amount, body.paid
    auth.db.commit()
    return expense_out(e)


@router.delete("/expenses/{eid}")
def delete_expense(eid: int, scope: str = "one", auth: Auth = Depends(current)):
    e = _get_expense(auth, eid)
    if scope == "future" and e.series_id:
        auth.db.query(Expense).filter(Expense.series_id == e.series_id, Expense.date >= e.date).delete()
    else:
        auth.db.delete(e)
    auth.db.commit()
    return {"ok": True}


# ---------- profissional ----------

def pro_month(db: Session, p: Professional, month: str, rooms) -> dict:
    first, last = month_range(month)
    start_dt = dt.datetime.combine(first, dt.time.min, tzinfo=dt.timezone.utc)
    end_dt = dt.datetime.combine(last, dt.time.max, tzinfo=dt.timezone.utc)
    appts = db.query(Appointment).filter(Appointment.professional_id == p.id, Appointment.date >= first,
                                         Appointment.date <= last, Appointment.status.in_(BILLABLE)).all()
    single = [a for a in appts if not a.package_id]
    pkgs = db.query(SessionPackage).filter(SessionPackage.professional_id == p.id, SessionPackage.paid.is_(True),
                                           SessionPackage.paid_at >= start_dt, SessionPackage.paid_at <= end_dt).all()
    received = sum(a.price for a in single if a.paid) + sum(k.price for k in pkgs)
    pending = sum(a.price for a in single if not a.paid)
    room = invoice_for(db, p, month, rooms)
    expenses = sum(e.amount for e in db.query(Expense).filter(Expense.professional_id == p.id, Expense.date >= first,
                                                              Expense.date <= last))
    return {"month": month, "received": round(received, 2), "pending": round(pending, 2), "room_cost": room["amount"],
            "expenses": round(expenses, 2), "net": round(received - room["amount"] - expenses, 2), "appointments": len(appts)}


@router.get("/statement")
def statement(month: str, professional_id: int | None = None, auth: Auth = Depends(current)):
    pid = professional_id if (auth.is_admin and professional_id) else my_pid(auth)
    p = auth.db.get(Professional, pid) if pid else None
    if not p:
        raise HTTPException(404, "Profissional não encontrado.")
    rooms = rooms_map(auth.db)
    first, last = month_range(month)
    appts = auth.db.query(Appointment).filter(Appointment.professional_id == p.id, Appointment.date >= first,
                                              Appointment.date <= last).order_by(Appointment.date, Appointment.start).all()
    cur = pro_month(auth.db, p, month, rooms)
    inv = invoice_for(auth.db, p, month, rooms)
    start_dt = dt.datetime.combine(first, dt.time.min, tzinfo=dt.timezone.utc)
    end_dt = dt.datetime.combine(last, dt.time.max, tzinfo=dt.timezone.utc)
    pkgs = auth.db.query(SessionPackage).filter(SessionPackage.professional_id == p.id, SessionPackage.paid.is_(True),
                                                SessionPackage.paid_at >= start_dt, SessionPackage.paid_at <= end_dt).all()
    by_method: dict[str, float] = {}
    for a in appts:
        if a.status in BILLABLE and a.paid and not a.package_id:
            k = a.payment_method or "não informado"
            by_method[k] = by_method.get(k, 0) + a.price
    for k in pkgs:
        m = (k.payment_method or "não informado") + " (pacote)"
        by_method[m] = by_method.get(m, 0) + k.price
    # A receber por paciente (todas as datas até hoje, sem pacote)
    open_rows = auth.db.query(Appointment).filter(Appointment.professional_id == p.id, Appointment.paid.is_(False),
                                                  Appointment.package_id.is_(None), Appointment.status.in_(("confirmed", "done")),
                                                  Appointment.date <= dt.date.today()).all()
    debtors: dict[int, dict] = {}
    for a in open_rows:
        d = debtors.setdefault(a.patient_id, {"patient_id": a.patient_id, "name": a.patient.name, "phone": a.patient.phone,
                                              "consent_whatsapp": a.patient.consent_whatsapp, "count": 0, "total": 0.0, "oldest": a.date.isoformat()})
        d["count"] += 1
        d["total"] += a.price
        d["oldest"] = min(d["oldest"], a.date.isoformat())
    series = [pro_month(auth.db, p, shift_month(month, -i), rooms) for i in range(5, -1, -1)]
    return {"professional_id": p.id, "name": p.user.name, "month": month, **cur,
            "no_shows": sum(1 for a in appts if a.status == "no_show"), "room_cost_paid": inv["paid"],
            "room_due_date": inv["due_date"], "room_overdue": inv["overdue"], "by_method": by_method,
            "packages_sold": [{"id": k.id, "name": k.name, "patient_name": auth.db.get(Patient, k.patient_id).name, "price": k.price,
                               "payment_method": k.payment_method} for k in pkgs],
            "debtors": sorted(debtors.values(), key=lambda d: -d["total"]), "series": series,
            "items": [{"id": a.id, "date": a.date.isoformat(), "start": a.start.strftime("%H:%M"), "patient_id": a.patient_id,
                       "patient_name": a.patient.name, "price": a.price, "status": a.status, "paid": a.paid,
                       "payment_method": a.payment_method, "package_id": a.package_id} for a in appts]}


# ---------- exportações ----------

def _csv(rows: list[list], name: str) -> Response:
    buf = io.StringIO()
    w = csv.writer(buf, delimiter=";")
    for r in rows:
        w.writerow([f"{x:.2f}".replace(".", ",") if isinstance(x, float) else x for x in r])
    return Response("﻿" + buf.getvalue(), media_type="text/csv; charset=utf-8",
                    headers={"Content-Disposition": f'attachment; filename="{name}"'})


@router.get("/export.csv")
def export_clinic(month: str, request: Request, auth: Auth = Depends(admin)):
    rooms = rooms_map(auth.db)
    rows = [["Tipo", "Data/Vencimento", "Descrição", "Categoria/Modelo", "Valor", "Situação"]]
    for i in invoices(month, auth):
        rows.append(["Receita (aluguel)", i["due_date"], i["name"], i["billing_model"], float(i["amount"]), "pago" if i["paid"] else ("atrasado" if i["overdue"] else "em aberto")])
    for e in list_expenses(month, "clinic", auth):
        rows.append(["Despesa", e["date"], e["description"], e["category"], float(-e["amount"]), "pago" if e["paid"] else "a pagar"])
    audit.log(auth.db, request, auth.user.id, "finance_exported", detail=month)
    _ = rooms
    return _csv(rows, f"financeiro-clinica-{month}.csv")


@router.get("/statement.csv")
def export_statement(month: str, request: Request, professional_id: int | None = None, auth: Auth = Depends(current)):
    st = statement(month, professional_id, auth)
    rows = [["Data", "Hora", "Paciente", "Situação", "Valor", "Pago", "Forma"]]
    for i in st["items"]:
        rows.append([i["date"], i["start"], i["patient_name"], i["status"], float(i["price"]), "sim" if i["paid"] else "não",
                     i["payment_method"] or ""])
    for k in st["packages_sold"]:
        rows.append(["", "", k["patient_name"], f"pacote: {k['name']}", float(k["price"]), "sim", k["payment_method"] or ""])
    rows.append([])
    rows.append(["Recebido", "", "", "", float(st["received"])])
    rows.append(["Aluguel de sala", "", "", "", float(-st["room_cost"])])
    rows.append(["Despesas", "", "", "", float(-st["expenses"])])
    rows.append(["Líquido", "", "", "", float(st["net"])])
    audit.log(auth.db, request, auth.user.id, "statement_exported", detail=month)
    return _csv(rows, f"extrato-{month}.csv")


# ---------- recibos em PDF ----------

def _pdf(data: bytes, name: str) -> Response:
    return Response(data, media_type="application/pdf", headers={"Content-Disposition": f'inline; filename="{name}"', "Cache-Control": "no-store"})


@router.get("/receipt/appointment/{aid}.pdf")
def receipt_appointment(aid: int, auth: Auth = Depends(current)):
    from .. import pdfs
    a = auth.db.get(Appointment, aid)
    if not a or not (auth.is_staff or my_pid(auth) == a.professional_id):
        raise HTTPException(404, "Consulta não encontrada.")
    if not a.paid or a.package_id:
        raise HTTPException(409, "Recibo disponível só para consulta paga avulsa.")
    prof = auth.db.get(Professional, a.professional_id)
    return _pdf(pdfs.receipt_pdf(auth.db, prof, a.patient, a.price, [f"Atendimento em {a.date.strftime('%d/%m/%Y')} às {a.start.strftime('%H:%M')}"],
                                 a.payment_method, a.paid_at), f"recibo-{aid}.pdf")


@router.get("/receipt/package/{kid}.pdf")
def receipt_package(kid: int, auth: Auth = Depends(current)):
    from .. import pdfs
    k = auth.db.get(SessionPackage, kid)
    if not k or not (auth.is_staff or my_pid(auth) == k.professional_id) or not k.paid:
        raise HTTPException(404, "Pacote pago não encontrado.")
    prof = auth.db.get(Professional, k.professional_id)
    return _pdf(pdfs.receipt_pdf(auth.db, prof, auth.db.get(Patient, k.patient_id), k.price,
                                 [f"{k.name} ({k.sessions_total} sessões)"], k.payment_method, k.paid_at), f"recibo-pacote-{kid}.pdf")


@router.get("/receipt/patient/{pid}.pdf")
def receipt_patient_month(pid: int, month: str, auth: Auth = Depends(current)):
    """Recibo mensal consolidado do paciente (útil para reembolso e imposto de renda)."""
    from .. import pdfs
    prof_id = my_pid(auth)
    if not prof_id:
        raise HTTPException(403, "Disponível para profissionais.")
    first, last = month_range(month)
    appts = auth.db.query(Appointment).filter(Appointment.patient_id == pid, Appointment.professional_id == prof_id,
                                              Appointment.paid.is_(True), Appointment.package_id.is_(None),
                                              Appointment.date >= first, Appointment.date <= last).order_by(Appointment.date).all()
    if not appts:
        raise HTTPException(404, "Nenhum atendimento pago neste mês.")
    prof = auth.db.get(Professional, prof_id)
    lines = [f"Atendimento em {a.date.strftime('%d/%m/%Y')} — R$ {a.price:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".") for a in appts]
    return _pdf(pdfs.receipt_pdf(auth.db, prof, appts[0].patient, sum(a.price for a in appts), lines, None, None),
                f"recibo-{pid}-{month}.pdf")


@router.get("/invoices/{pid}/{month}/receipt.pdf")
def invoice_receipt(pid: int, month: str, auth: Auth = Depends(current)):
    from .. import pdfs
    if not (auth.is_admin or my_pid(auth) == pid):
        raise HTTPException(403, "Acesso restrito.")
    p = auth.db.get(Professional, pid)
    inv = invoice_for(auth.db, p, month, rooms_map(auth.db), detail=True)
    if not inv["paid"]:
        raise HTTPException(409, "A fatura ainda não foi paga.")
    return _pdf(pdfs.invoice_receipt_pdf(auth.db, p, inv), f"recibo-aluguel-{month}.pdf")
