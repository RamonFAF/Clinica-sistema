from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel

from .. import audit
from ..access import get_patient, in_care, my_pid
from ..deps import Auth, current, utcnow
from ..models import Appointment, SessionPackage

router = APIRouter(prefix="/packages", tags=["packages"])


class PackageIn(BaseModel):
    patient_id: int
    professional_id: int | None = None
    name: str
    sessions_total: int
    price: float
    paid: bool = False
    payment_method: str | None = None
    active: bool = True


def package_out(auth: Auth, k: SessionPackage) -> dict:
    used = auth.db.query(Appointment).filter(Appointment.package_id == k.id, Appointment.status != "canceled").count()
    return {"id": k.id, "patient_id": k.patient_id, "patient_name": None, "professional_id": k.professional_id, "name": k.name,
            "sessions_total": k.sessions_total, "used": used, "left": k.sessions_total - used, "price": k.price,
            "paid": k.paid, "paid_at": k.paid_at, "payment_method": k.payment_method, "active": k.active, "created_at": k.created_at}


def _own(auth: Auth, k: SessionPackage) -> None:
    if not (auth.is_staff or my_pid(auth) == k.professional_id):
        raise HTTPException(404, "Pacote não encontrado.")


@router.get("")
def list_packages(patient_id: int | None = None, professional_id: int | None = None, active_only: bool = False,
                  auth: Auth = Depends(current)):
    q = auth.db.query(SessionPackage)
    if patient_id:
        get_patient(auth, patient_id)
        q = q.filter(SessionPackage.patient_id == patient_id)
    if not auth.is_staff:
        q = q.filter(SessionPackage.professional_id == my_pid(auth))
    elif professional_id:
        q = q.filter(SessionPackage.professional_id == professional_id)
    if active_only:
        q = q.filter(SessionPackage.active.is_(True))
    return [package_out(auth, k) for k in q.order_by(SessionPackage.created_at.desc()).all()]


@router.post("")
def create_package(body: PackageIn, request: Request, auth: Auth = Depends(current)):
    p = get_patient(auth, body.patient_id)
    prof_id = body.professional_id if auth.is_staff and body.professional_id else my_pid(auth)
    if not auth.is_staff and not in_care(auth, p):
        raise HTTPException(404, "Paciente não encontrado.")
    if not prof_id or not 1 <= body.sessions_total <= 200 or body.price < 0:
        raise HTTPException(422, "Confira profissional, número de sessões e valor.")
    k = SessionPackage(patient_id=p.id, professional_id=prof_id, name=body.name.strip() or f"Pacote {body.sessions_total} sessões",
                       sessions_total=body.sessions_total, price=body.price, paid=body.paid,
                       payment_method=body.payment_method, paid_at=utcnow() if body.paid else None)
    auth.db.add(k)
    auth.db.flush()
    audit.log(auth.db, request, auth.user.id, "package_created", "package", k.id, commit=False)
    auth.db.commit()
    return package_out(auth, k)


@router.put("/{kid}")
def update_package(kid: int, body: PackageIn, request: Request, auth: Auth = Depends(current)):
    k = auth.db.get(SessionPackage, kid)
    if not k:
        raise HTTPException(404, "Pacote não encontrado.")
    _own(auth, k)
    used = package_out(auth, k)["used"]
    if body.sessions_total < used:
        raise HTTPException(422, f"Já foram usadas {used} sessões deste pacote.")
    if body.paid and not k.paid:
        k.paid_at = utcnow()
    if not body.paid:
        k.paid_at = None
    k.name, k.sessions_total, k.price, k.paid, k.payment_method, k.active = (
        body.name, body.sessions_total, body.price, body.paid, body.payment_method, body.active)
    audit.log(auth.db, request, auth.user.id, "package_updated", "package", k.id, commit=False)
    auth.db.commit()
    return package_out(auth, k)
