from ..models import Appointment, Patient, Professional, Reservation, Room, User
from ..util import hhmm


def photo_url(p: Professional | None) -> str | None:
    return f"/api/files/photos/{p.photo}" if p and p.photo else None


def user_out(u: User) -> dict:
    p = u.professional
    return {"id": u.id, "email": u.email, "name": u.name, "role": u.role, "is_active": u.is_active,
            "totp_enabled": u.totp_enabled, "professional_id": p.id if p else None, "photo_url": photo_url(p),
            "color": p.color if p else None, "last_login_at": u.last_login_at}


def professional_out(p: Professional) -> dict:
    u = p.user
    return {"id": p.id, "user_id": u.id, "name": u.name, "email": u.email, "role": u.role, "is_active": u.is_active,
            "totp_enabled": u.totp_enabled, "council": p.council, "document": p.document, "specialty": p.specialty, "phone": p.phone,
            "color": p.color, "billing_model": p.billing_model, "monthly_fee": p.monthly_fee, "percent": p.percent,
            "bio": p.bio, "attends": p.attends, "photo_url": photo_url(p), "last_login_at": u.last_login_at}


def room_out(r: Room) -> dict:
    return {"id": r.id, "name": r.name, "resources": r.resources, "area_m2": r.area_m2, "hourly_rate": r.hourly_rate,
            "active": r.active, "sort_order": r.sort_order}


def reservation_out(r: Reservation) -> dict:
    return {"id": r.id, "room_id": r.room_id, "professional_id": r.professional_id, "date": r.date.isoformat(),
            "start": hhmm(r.start), "end": hhmm(r.end), "series_id": r.series_id, "notes": r.notes}


def patient_out(p: Patient, full: bool = True) -> dict:
    out = {"id": p.id, "professional_id": p.professional_id, "name": p.name, "phone": p.phone, "email": p.email,
           "birth_date": p.birth_date.isoformat() if p.birth_date else None, "archived": p.archived,
           "consent_care": p.consent_care, "consent_ehr": p.consent_ehr, "consent_shared": p.consent_shared,
           "consent_whatsapp": p.consent_whatsapp, "consent_at": p.consent_at, "created_at": p.created_at,
           "insurance": p.insurance}
    if full:
        out.update({"cpf": p.cpf, "rg": p.rg, "sex": p.sex, "marital_status": p.marital_status, "occupation": p.occupation,
                    "address": p.address, "guardian": p.guardian, "notes": p.notes})
    return out


def appointment_out(a: Appointment) -> dict:
    return {"id": a.id, "patient_id": a.patient_id, "patient_name": a.patient.name if a.patient else None,
            "patient_phone": a.patient.phone if a.patient else None, "professional_id": a.professional_id,
            "date": a.date.isoformat(), "start": hhmm(a.start), "end": hhmm(a.end), "price": a.price,
            "status": a.status, "online": a.online, "paid": a.paid, "payment_method": a.payment_method,
            "paid_at": a.paid_at, "notes": a.notes, "package_id": a.package_id, "reminder_sent_at": a.reminder_sent_at,
            "patient_response": a.patient_response, "confirm_token": a.confirm_token, "patient_response_at": a.patient_response_at,
            "consent_whatsapp": a.patient.consent_whatsapp if a.patient else False}
