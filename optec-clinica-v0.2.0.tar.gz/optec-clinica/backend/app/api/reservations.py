import datetime as dt
import uuid

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel
from sqlalchemy.orm import Session

from .. import audit, settings_store
from ..deps import Auth, current
from ..models import Appointment, Professional, Reservation, Room
from ..util import hhmm, parse_date, parse_time
from .serializers import reservation_out

router = APIRouter(prefix="/reservations", tags=["reservations"])


class ReservationIn(BaseModel):
    room_id: int
    professional_id: int
    date: str
    start: str
    end: str
    repeat_weeks: int = 1
    notes: str | None = None


def check_hours(db: Session, date: dt.date, start: dt.time, end: dt.time) -> None:
    s = settings_store.get_all(db)
    if start >= end:
        raise HTTPException(422, "O horário de fim precisa ser depois do início.")
    if start < parse_time(s["open_time"]) or end > parse_time(s["close_time"]):
        raise HTTPException(422, f"Fora do horário de funcionamento ({s['open_time']} às {s['close_time']}).")
    if date.weekday() not in s["open_weekdays"]:
        raise HTTPException(422, "A clínica não abre neste dia da semana.")


def room_conflict(db: Session, room_id: int, date: dt.date, start: dt.time, end: dt.time, exclude: int | None = None):
    q = db.query(Reservation).filter(Reservation.room_id == room_id, Reservation.date == date,
                                     Reservation.start < end, Reservation.end > start)
    if exclude:
        q = q.filter(Reservation.id != exclude)
    return q.first()


def can_manage(auth: Auth, professional_id: int) -> bool:
    if auth.is_staff:
        return True
    own = auth.professional and auth.professional.id == professional_id
    return bool(own and settings_store.get(auth.db, "professionals_can_book_rooms"))


@router.get("")
def list_reservations(date_from: str, date_to: str, room_id: int | None = None, professional_id: int | None = None,
                      auth: Auth = Depends(current)):
    q = auth.db.query(Reservation).filter(Reservation.date >= parse_date(date_from), Reservation.date <= parse_date(date_to))
    if room_id:
        q = q.filter(Reservation.room_id == room_id)
    if professional_id:
        q = q.filter(Reservation.professional_id == professional_id)
    return [reservation_out(r) for r in q.order_by(Reservation.date, Reservation.start).all()]


@router.post("")
def create_reservation(body: ReservationIn, request: Request, auth: Auth = Depends(current)):
    if not can_manage(auth, body.professional_id):
        raise HTTPException(403, "Você não pode reservar salas para este profissional.")
    room = auth.db.get(Room, body.room_id)
    if not room or not room.active:
        raise HTTPException(404, "Sala não encontrada.")
    if not auth.db.get(Professional, body.professional_id):
        raise HTTPException(404, "Profissional não encontrado.")
    start, end, first = parse_time(body.start), parse_time(body.end), parse_date(body.date)
    weeks = max(1, min(body.repeat_weeks, 52))
    series = str(uuid.uuid4()) if weeks > 1 else None
    created = []
    for w in range(weeks):
        d = first + dt.timedelta(weeks=w)
        check_hours(auth.db, d, start, end)
        c = room_conflict(auth.db, room.id, d, start, end)
        if c:
            auth.db.rollback()
            raise HTTPException(409, f"{room.name} já está reservada em {d.strftime('%d/%m')} das {hhmm(c.start)} às {hhmm(c.end)}.")
        r = Reservation(room_id=room.id, professional_id=body.professional_id, date=d, start=start, end=end,
                        series_id=series, notes=body.notes)
        auth.db.add(r)
        created.append(r)
    auth.db.flush()
    audit.log(auth.db, request, auth.user.id, "reservation_created", "reservation", created[0].id,
              f"{room.name} {first} {body.start}-{body.end} x{weeks}", commit=False)
    auth.db.commit()
    return [reservation_out(r) for r in created]


@router.put("/{rid}")
def update_reservation(rid: int, body: ReservationIn, request: Request, auth: Auth = Depends(current)):
    r = auth.db.get(Reservation, rid)
    if not r:
        raise HTTPException(404, "Reserva não encontrada.")
    if not can_manage(auth, r.professional_id) or not can_manage(auth, body.professional_id):
        raise HTTPException(403, "Você não pode alterar esta reserva.")
    start, end, d = parse_time(body.start), parse_time(body.end), parse_date(body.date)
    check_hours(auth.db, d, start, end)
    c = room_conflict(auth.db, body.room_id, d, start, end, exclude=rid)
    if c:
        raise HTTPException(409, f"Sala já reservada das {hhmm(c.start)} às {hhmm(c.end)}.")
    r.room_id, r.professional_id, r.date, r.start, r.end, r.notes = body.room_id, body.professional_id, d, start, end, body.notes
    audit.log(auth.db, request, auth.user.id, "reservation_updated", "reservation", rid, commit=False)
    auth.db.commit()
    return reservation_out(r)


@router.delete("/{rid}")
def delete_reservation(rid: int, request: Request, scope: str = "one", auth: Auth = Depends(current)):
    r = auth.db.get(Reservation, rid)
    if not r:
        raise HTTPException(404, "Reserva não encontrada.")
    if not can_manage(auth, r.professional_id):
        raise HTTPException(403, "Você não pode excluir esta reserva.")
    targets = [r]
    if scope == "future" and r.series_id:
        targets = auth.db.query(Reservation).filter(Reservation.series_id == r.series_id, Reservation.date >= r.date).all()
    for t in targets:
        busy = auth.db.query(Appointment).filter(
            Appointment.professional_id == t.professional_id, Appointment.date == t.date, Appointment.online.is_(False),
            Appointment.status.notin_(["canceled"]), Appointment.start < t.end, Appointment.end > t.start).first()
        if busy:
            raise HTTPException(409, f"Há consulta presencial marcada em {t.date.strftime('%d/%m')} às {hhmm(busy.start)} "
                                     "dentro desta reserva. Remarque a consulta antes.")
        auth.db.delete(t)
    audit.log(auth.db, request, auth.user.id, "reservation_deleted", "reservation", rid, f"{len(targets)} reserva(s)",
              commit=False)
    auth.db.commit()
    return {"ok": True, "deleted": len(targets)}
