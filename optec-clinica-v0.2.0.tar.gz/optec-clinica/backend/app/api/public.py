"""Página pública de confirmação de consulta (link enviado pelo WhatsApp).

Mostra só o mínimo: primeiro nome, data, horário, profissional e endereço. Nada clínico.
O token é aleatório (24 bytes) e só vale até o dia da consulta.
"""
import datetime as dt

from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy.orm import Session

from .. import audit, settings_store
from ..db import get_db
from ..deps import csrf_guard, utcnow
from ..models import Appointment, Professional

router = APIRouter(prefix="/public/appointment", tags=["public"])


def _get(db: Session, token: str) -> Appointment:
    if len(token) < 20:
        raise HTTPException(404, "Link inválido.")
    a = db.query(Appointment).filter_by(confirm_token=token).first()
    if not a or a.date < dt.date.today():
        raise HTTPException(404, "Este link não é mais válido.")
    return a


def _out(db: Session, a: Appointment) -> dict:
    s = settings_store.get_all(db)
    prof = db.get(Professional, a.professional_id)
    return {"clinic_name": s["clinic_name"], "clinic_phone": s["clinic_phone"], "clinic_address": s["clinic_address"],
            "logo_url": f"/api/public/logo/{s['logo']}" if s["logo"] else None,
            "patient_first_name": a.patient.name.split(" ")[0], "professional": prof.user.name if prof else "",
            "specialty": prof.specialty if prof else None, "date": a.date.isoformat(), "start": a.start.strftime("%H:%M"),
            "end": a.end.strftime("%H:%M"), "online": a.online, "status": a.status, "patient_response": a.patient_response,
            "can_answer": a.status in ("scheduled", "confirmed")}


@router.get("/{token}")
def view(token: str, db: Session = Depends(get_db)):
    return _out(db, _get(db, token))


@router.post("/{token}/{answer}", dependencies=[Depends(csrf_guard)])
def answer(token: str, answer: str, request: Request, db: Session = Depends(get_db)):
    if answer not in ("confirm", "reschedule"):
        raise HTTPException(404, "Ação inválida.")
    a = _get(db, token)
    if a.status not in ("scheduled", "confirmed"):
        raise HTTPException(409, "Esta consulta não pode mais ser alterada por aqui. Fale com a clínica.")
    a.patient_response = "confirmed" if answer == "confirm" else "reschedule"
    a.patient_response_at = utcnow()
    if answer == "confirm":
        a.status = "confirmed"
    audit.log(db, request, None, f"patient_{a.patient_response}", "appointment", a.id, commit=False)
    db.commit()
    return _out(db, a)
