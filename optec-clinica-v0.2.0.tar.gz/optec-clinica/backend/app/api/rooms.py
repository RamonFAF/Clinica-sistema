from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel

from .. import audit, settings_store
from ..deps import Auth, admin, current
from ..models import Reservation, Room
from .serializers import room_out

router = APIRouter(prefix="/rooms", tags=["rooms"])


class RoomIn(BaseModel):
    name: str
    resources: str | None = None
    area_m2: float = 0
    hourly_rate: float = 0
    active: bool = True
    sort_order: int = 0


class CountIn(BaseModel):
    count: int


@router.get("")
def list_rooms(include_inactive: bool = False, auth: Auth = Depends(current)):
    q = auth.db.query(Room)
    if not include_inactive:
        q = q.filter(Room.active.is_(True))
    return [room_out(r) for r in q.order_by(Room.sort_order, Room.id).all()]


@router.post("")
def create_room(body: RoomIn, request: Request, auth: Auth = Depends(admin)):
    r = Room(**body.model_dump())
    auth.db.add(r)
    auth.db.flush()
    audit.log(auth.db, request, auth.user.id, "room_created", "room", r.id, r.name, commit=False)
    auth.db.commit()
    return room_out(r)


@router.put("/{rid}")
def update_room(rid: int, body: RoomIn, request: Request, auth: Auth = Depends(admin)):
    r = auth.db.get(Room, rid)
    if not r:
        raise HTTPException(404, "Sala não encontrada.")
    for k, v in body.model_dump().items():
        setattr(r, k, v)
    audit.log(auth.db, request, auth.user.id, "room_updated", "room", r.id, commit=False)
    auth.db.commit()
    return room_out(r)


@router.delete("/{rid}")
def delete_room(rid: int, request: Request, auth: Auth = Depends(admin)):
    r = auth.db.get(Room, rid)
    if not r:
        raise HTTPException(404, "Sala não encontrada.")
    if auth.db.query(Reservation).filter_by(room_id=rid).first():
        r.active = False  # mantém o histórico de reservas e faturas
        msg = "deactivated"
    else:
        auth.db.delete(r)
        msg = "deleted"
    audit.log(auth.db, request, auth.user.id, f"room_{msg}", "room", rid, commit=False)
    auth.db.commit()
    return {"ok": True, "result": msg}


@router.post("/set-count")
def set_count(body: CountIn, request: Request, auth: Auth = Depends(admin)):
    """Ajusta a quantidade de salas ativas: cria 'Sala N' ou desativa as últimas."""
    if not 0 <= body.count <= 200:
        raise HTTPException(422, "Quantidade entre 0 e 200.")
    active = auth.db.query(Room).filter(Room.active.is_(True)).order_by(Room.sort_order, Room.id).all()
    if body.count > len(active):
        inactive = auth.db.query(Room).filter(Room.active.is_(False)).order_by(Room.sort_order, Room.id).all()
        need = body.count - len(active)
        for r in inactive[:need]:
            r.active = True
            need -= 1
        rate = settings_store.get(auth.db, "default_room_rate")
        total = auth.db.query(Room).count()
        for i in range(need):
            auth.db.add(Room(name=f"Sala {total + i + 1}", hourly_rate=rate, sort_order=total + i + 1))
    else:
        for r in active[body.count:]:
            r.active = False
    audit.log(auth.db, request, auth.user.id, "room_count_set", detail=str(body.count), commit=False)
    auth.db.commit()
    return [room_out(r) for r in auth.db.query(Room).filter(Room.active.is_(True)).order_by(Room.sort_order, Room.id)]
