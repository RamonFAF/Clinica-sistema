from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel

from .. import audit
from ..access import my_pid
from ..deps import Auth, current
from ..models import WaitlistEntry

router = APIRouter(prefix="/waitlist", tags=["waitlist"])
STATUSES = ("waiting", "contacted", "scheduled", "gave_up")


class WaitIn(BaseModel):
    professional_id: int | None = None
    patient_id: int | None = None
    name: str
    phone: str | None = None
    specialty: str | None = None
    preference: str | None = None
    notes: str | None = None
    status: str = "waiting"


def out(w: WaitlistEntry) -> dict:
    return {k: getattr(w, k) for k in ("id", "professional_id", "patient_id", "name", "phone", "specialty", "preference",
                                       "notes", "status", "created_at")}


def visible(auth: Auth, w: WaitlistEntry) -> bool:
    return auth.is_staff or w.professional_id in (None, my_pid(auth))


@router.get("")
def list_waitlist(status: str | None = "waiting", auth: Auth = Depends(current)):
    q = auth.db.query(WaitlistEntry)
    if status:
        q = q.filter(WaitlistEntry.status == status)
    rows = [w for w in q.order_by(WaitlistEntry.created_at).all() if visible(auth, w)]
    return [out(w) for w in rows]


@router.post("")
def create(body: WaitIn, request: Request, auth: Auth = Depends(current)):
    if body.status not in STATUSES or not body.name.strip():
        raise HTTPException(422, "Confira nome e situação.")
    data = body.model_dump()
    if not auth.is_staff:
        data["professional_id"] = my_pid(auth)
    w = WaitlistEntry(**data)
    auth.db.add(w)
    auth.db.flush()
    audit.log(auth.db, request, auth.user.id, "waitlist_added", "waitlist", w.id, commit=False)
    auth.db.commit()
    return out(w)


@router.put("/{wid}")
def update(wid: int, body: WaitIn, auth: Auth = Depends(current)):
    w = auth.db.get(WaitlistEntry, wid)
    if not w or not visible(auth, w):
        raise HTTPException(404, "Registro não encontrado.")
    if body.status not in STATUSES:
        raise HTTPException(422, "Situação inválida.")
    for k, v in body.model_dump().items():
        if k == "professional_id" and not auth.is_staff:
            continue
        setattr(w, k, v)
    auth.db.commit()
    return out(w)


@router.delete("/{wid}")
def delete(wid: int, auth: Auth = Depends(current)):
    w = auth.db.get(WaitlistEntry, wid)
    if not w or not visible(auth, w):
        raise HTTPException(404, "Registro não encontrado.")
    auth.db.delete(w)
    auth.db.commit()
    return {"ok": True}
