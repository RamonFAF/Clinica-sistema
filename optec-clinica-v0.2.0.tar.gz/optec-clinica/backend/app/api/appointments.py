import datetime as dt
import secrets

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel

from .. import audit, settings_store
from ..deps import Auth, current, utcnow
from ..access import get_patient, in_care, my_pid
from ..models import Appointment, Patient, PatientTeam, Professional, Reservation, SessionPackage
from ..util import hhmm, parse_date, parse_time
from .reservations import check_hours
from .serializers import appointment_out

router = APIRouter(prefix="/appointments", tags=["appointments"])
STATUSES = ("scheduled", "confirmed", "done", "no_show", "canceled")


class AppointmentIn(BaseModel):
    patient_id: int
    professional_id: int | None = None
    package_id: int | None = None
    date: str
    start: str
    end: str
    price: float = 0
    status: str = "scheduled"
    online: bool = False
    paid: bool = False
    payment_method: str | None = None
    notes: str | None = None
    repeat_weeks: int = 1


class PatchIn(BaseModel):
    status: str | None = None
    paid: bool | None = None
    payment_method: str | None = None


def can_access(auth: Auth, professional_id: int) -> bool:
    return auth.is_staff or bool(auth.professional and auth.professional.id == professional_id)


def package_left(auth: Auth, pkg: SessionPackage, exclude: int | None = None) -> int:
    q = auth.db.query(Appointment).filter(Appointment.package_id == pkg.id, Appointment.status != "canceled")
    if exclude:
        q = q.filter(Appointment.id != exclude)
    return pkg.sessions_total - q.count()


def check_package(auth: Auth, package_id: int | None, patient_id: int, prof_id: int, exclude: int | None = None):
    if not package_id:
        return None
    pkg = auth.db.get(SessionPackage, package_id)
    if not pkg or pkg.patient_id != patient_id or pkg.professional_id != prof_id or not pkg.active:
        raise HTTPException(422, "Pacote não encontrado para este paciente e profissional.")
    if package_left(auth, pkg, exclude) <= 0:
        raise HTTPException(409, f"O pacote \"{pkg.name}\" não tem mais sessões disponíveis.")
    return pkg


def validate(auth: Auth, prof_id: int, d: dt.date, start: dt.time, end: dt.time, online: bool, status: str,
             exclude: int | None = None) -> None:
    if status not in STATUSES:
        raise HTTPException(422, "Status inválido.")
    if status == "canceled":
        return
    check_hours(auth.db, d, start, end)
    if not online and settings_store.get(auth.db, "require_room_for_in_person"):
        room = auth.db.query(Reservation).filter(Reservation.professional_id == prof_id, Reservation.date == d,
                                                 Reservation.start <= start, Reservation.end >= end).first()
        if not room:
            raise HTTPException(409, f"Sem sala reservada em {d.strftime('%d/%m')} das {hhmm(start)} às {hhmm(end)}. "
                                     "Reserve uma sala ou marque como online.")
    q = auth.db.query(Appointment).filter(Appointment.professional_id == prof_id, Appointment.date == d,
                                          Appointment.status != "canceled", Appointment.start < end, Appointment.end > start)
    if exclude:
        q = q.filter(Appointment.id != exclude)
    clash = q.first()
    if clash:
        raise HTTPException(409, f"Já existe consulta com {clash.patient.name} das {hhmm(clash.start)} às {hhmm(clash.end)}.")


@router.get("")
def list_appointments(date_from: str, date_to: str, professional_id: int | None = None, auth: Auth = Depends(current)):
    q = auth.db.query(Appointment).filter(Appointment.date >= parse_date(date_from), Appointment.date <= parse_date(date_to))
    if not auth.is_staff:
        if not auth.professional:
            return []
        q = q.filter(Appointment.professional_id == auth.professional.id)
    elif professional_id:
        q = q.filter(Appointment.professional_id == professional_id)
    rows = q.order_by(Appointment.date, Appointment.start).all()
    missing = [a for a in rows if not a.confirm_token]
    for a in missing:  # consultas antigas ganham link de confirmação na primeira leitura
        a.confirm_token = secrets.token_urlsafe(24)
    if missing:
        auth.db.commit()
    return [appointment_out(a) for a in rows]


@router.post("")
def create_appointment(body: AppointmentIn, request: Request, auth: Auth = Depends(current)):
    p = get_patient(auth, body.patient_id)
    # Quem atende: a recepção/administração escolhe; o profissional marca para si.
    if auth.is_staff:
        prof_id = body.professional_id or p.professional_id
    else:
        prof_id = my_pid(auth)
        if not in_care(auth, p):
            raise HTTPException(404, "Paciente não encontrado.")
    prof = auth.db.get(Professional, prof_id)
    if not prof or not prof.attends:
        raise HTTPException(422, "Profissional não encontrado.")
    if prof_id != p.professional_id and not auth.db.query(PatientTeam).filter_by(patient_id=p.id, professional_id=prof_id).first():
        auth.db.add(PatientTeam(patient_id=p.id, professional_id=prof_id))  # passa a integrar a equipe de cuidado
    start, end, first = parse_time(body.start), parse_time(body.end), parse_date(body.date)
    weeks = max(1, min(body.repeat_weeks, 52))
    created = []
    for w in range(weeks):
        d = first + dt.timedelta(weeks=w)
        validate(auth, prof_id, d, start, end, body.online, body.status)
        pkg = check_package(auth, body.package_id, p.id, prof_id)
        a = Appointment(patient_id=p.id, professional_id=prof_id, date=d, start=start, end=end,
                        price=body.price, status=body.status, online=body.online, paid=body.paid or bool(pkg),
                        payment_method="pacote" if pkg else body.payment_method, notes=body.notes,
                        paid_at=utcnow() if (body.paid or pkg) else None, package_id=pkg.id if pkg else None,
                        confirm_token=secrets.token_urlsafe(24))
        auth.db.add(a)
        auth.db.flush()
        created.append(a)
    audit.log(auth.db, request, auth.user.id, "appointment_created", "appointment", created[0].id, f"x{weeks}", commit=False)
    auth.db.commit()
    return [appointment_out(a) for a in created]


@router.put("/{aid}")
def update_appointment(aid: int, body: AppointmentIn, request: Request, auth: Auth = Depends(current)):
    a = auth.db.get(Appointment, aid)
    if not a or not can_access(auth, a.professional_id):
        raise HTTPException(404, "Consulta não encontrada.")
    start, end, d = parse_time(body.start), parse_time(body.end), parse_date(body.date)
    validate(auth, a.professional_id, d, start, end, body.online, body.status, exclude=aid)
    pkg = check_package(auth, body.package_id, a.patient_id, a.professional_id, exclude=aid) if body.package_id != a.package_id else (
        auth.db.get(SessionPackage, body.package_id) if body.package_id else None)
    paid = body.paid or bool(pkg)
    if paid and not a.paid:
        a.paid_at = utcnow()
    if (d, start) != (a.date, a.start):
        a.reminder_sent_at, a.patient_response, a.patient_response_at = None, None, None  # remarcou: novo lembrete
    a.date, a.start, a.end, a.price, a.status, a.online = d, start, end, body.price, body.status, body.online
    a.paid, a.notes, a.package_id = paid, body.notes, pkg.id if pkg else None
    a.payment_method = "pacote" if pkg else body.payment_method
    if not a.paid:
        a.paid_at = None
    audit.log(auth.db, request, auth.user.id, "appointment_updated", "appointment", aid, commit=False)
    auth.db.commit()
    return appointment_out(a)


@router.patch("/{aid}")
def patch_appointment(aid: int, body: PatchIn, request: Request, auth: Auth = Depends(current)):
    a = auth.db.get(Appointment, aid)
    if not a or not can_access(auth, a.professional_id):
        raise HTTPException(404, "Consulta não encontrada.")
    if body.status:
        if body.status not in STATUSES:
            raise HTTPException(422, "Status inválido.")
        a.status = body.status
    if body.paid is not None:
        a.paid = body.paid
        a.paid_at = utcnow() if body.paid else None
    if body.payment_method is not None:
        a.payment_method = body.payment_method
    audit.log(auth.db, request, auth.user.id, "appointment_updated", "appointment", aid,
              body.model_dump_json(exclude_none=True), commit=False)
    auth.db.commit()
    return appointment_out(a)


@router.post("/{aid}/reminder-sent")
def reminder_sent(aid: int, request: Request, auth: Auth = Depends(current)):
    a = auth.db.get(Appointment, aid)
    if not a or not can_access(auth, a.professional_id):
        raise HTTPException(404, "Consulta não encontrada.")
    a.reminder_sent_at = utcnow()
    if not a.confirm_token:
        a.confirm_token = secrets.token_urlsafe(24)
    audit.log(auth.db, request, auth.user.id, "reminder_sent", "appointment", aid, commit=False)
    auth.db.commit()
    return appointment_out(a)


@router.get("/{aid}/confirm-link")
def confirm_link(aid: int, auth: Auth = Depends(current)):
    a = auth.db.get(Appointment, aid)
    if not a or not can_access(auth, a.professional_id):
        raise HTTPException(404, "Consulta não encontrada.")
    if not a.confirm_token:
        a.confirm_token = secrets.token_urlsafe(24)
        auth.db.commit()
    return {"token": a.confirm_token, "path": f"/c/{a.confirm_token}"}


@router.get("/{aid}/attendance.pdf")
def attendance_pdf(aid: int, request: Request, auth: Auth = Depends(current)):
    from fastapi.responses import Response
    from .. import pdfs
    a = auth.db.get(Appointment, aid)
    if not a or not can_access(auth, a.professional_id):
        raise HTTPException(404, "Consulta não encontrada.")
    audit.log(auth.db, request, auth.user.id, "attendance_pdf", "appointment", aid)
    return Response(pdfs.attendance_pdf(auth.db, a), media_type="application/pdf",
                    headers={"Content-Disposition": f'inline; filename="declaracao-{aid}.pdf"', "Cache-Control": "no-store"})


@router.delete("/{aid}")
def delete_appointment(aid: int, request: Request, auth: Auth = Depends(current)):
    a = auth.db.get(Appointment, aid)
    if not a or not can_access(auth, a.professional_id):
        raise HTTPException(404, "Consulta não encontrada.")
    auth.db.delete(a)
    audit.log(auth.db, request, auth.user.id, "appointment_deleted", "appointment", aid, commit=False)
    auth.db.commit()
    return {"ok": True}
