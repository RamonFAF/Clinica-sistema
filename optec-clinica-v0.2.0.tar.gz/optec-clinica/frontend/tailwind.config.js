/** @type {import('tailwindcss').Config} */
const v = (name) => `rgb(var(--${name}) / <alpha-value>)`;
export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      fontFamily: { sans: ['"Plus Jakarta Sans Variable"', "system-ui", "Segoe UI", "sans-serif"] },
      colors: {
        bg: v("bg"), surface: v("surface"), sunk: v("sunk"), line: v("line"),
        ink: v("ink"), muted: v("muted"),
        brand: v("brand"), "brand-2": v("brand-2"), indigo: v("indigo"), "brand-soft": v("brand-soft"),
        ok: v("ok"), "ok-soft": v("ok-soft"), warn: v("warn"), "warn-soft": v("warn-soft"),
        bad: v("bad"), "bad-soft": v("bad-soft"), info: v("info"), "info-soft": v("info-soft"),
        "chart-in": v("chart-in"), "chart-out": v("chart-out"),
      },
      boxShadow: { card: "0 1px 2px rgb(var(--shadow) / .06), 0 8px 24px -12px rgb(var(--shadow) / .18)" },
      borderRadius: { xl: "14px", "2xl": "18px" },
    },
  },
  plugins: [],
};
