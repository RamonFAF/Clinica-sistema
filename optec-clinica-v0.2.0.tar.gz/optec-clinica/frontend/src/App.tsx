import { Navigate, Route, Routes, useLocation } from "react-router-dom";
import { useAuth } from "./lib/auth";
import { Layout, MorePage } from "./components/Layout";
import { Spinner, Toaster } from "./components/ui";
import { ChangePasswordPage, LoginPage, MfaPage, MfaSetupPage } from "./pages/Login";
import { DashboardPage } from "./pages/Dashboard";
import { AgendaPage } from "./pages/Agenda";
import { RoomsPage } from "./pages/Rooms";
import { PatientsPage } from "./pages/Patients";
import { PatientDetailPage } from "./pages/PatientDetail";
import { TeamPage } from "./pages/Team";
import { FinancePage } from "./pages/Finance";
import { SettingsPage } from "./pages/Settings";
import { AuditPage } from "./pages/Audit";
import { ProfilePage } from "./pages/Profile";
import { ConfirmPage } from "./pages/Confirm";
import { MessagesPage } from "./pages/Messages";
import { WaitlistPage } from "./pages/Waitlist";

export function App() {
  const { state, loading } = useAuth();
  const location = useLocation();
  if (location.pathname.startsWith("/c/")) {
    return <Routes><Route path="/c/:token" element={<ConfirmPage />} /></Routes>;
  }
  if (loading) return <Spinner />;
  let screen;
  if (!state) screen = <LoginPage />;
  else if (state.mfa_pending) screen = <MfaPage />;
  else if (state.password_change_required) screen = <ChangePasswordPage />;
  else if (state.mfa_setup_required) screen = <MfaSetupPage />;
  else {
    const admin = state.user.role === "admin";
    const staff = admin || state.user.role === "reception";
    screen = (
      <Routes>
        <Route element={<Layout />}>
          <Route index element={<DashboardPage />} />
          <Route path="agenda" element={<AgendaPage />} />
          <Route path="salas" element={<RoomsPage />} />
          <Route path="pacientes" element={<PatientsPage />} />
          <Route path="pacientes/:id" element={<PatientDetailPage />} />
          <Route path="financeiro" element={<FinancePage />} />
          <Route path="perfil" element={<ProfilePage />} />
          <Route path="mais" element={<MorePage />} />
          <Route path="comunicacao" element={<MessagesPage />} />
          <Route path="espera" element={<WaitlistPage />} />
          {staff && <Route path="equipe" element={<TeamPage />} />}
          {admin && <Route path="configuracoes" element={<SettingsPage />} />}
          {admin && <Route path="relatorios" element={<AuditPage />} />}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Route>
      </Routes>
    );
  }
  return <>{screen}<Toaster /></>;
}
