import { NavLink, Outlet } from "react-router-dom";
import { CalendarDays, DoorOpen, FileClock, Home, ListTodo, LogOut, Menu, MessageCircle, Settings, Users, UserRound, Wallet } from "lucide-react";
import { useAuth, useMe } from "../lib/auth";
import { ROLE_LABEL } from "../lib/format";
import { Logo } from "./Logo";
import { Avatar, cx } from "./ui";

interface Item { to: string; label: string; icon: typeof Home; show: boolean; mobile?: boolean }

export function Layout() {
  const { user, isAdmin, isStaff } = useMe();
  const { logout } = useAuth();
  const items: Item[] = [
    { to: "/", label: "Início", icon: Home, show: true, mobile: true },
    { to: "/agenda", label: "Agenda", icon: CalendarDays, show: true, mobile: true },
    { to: "/pacientes", label: "Pacientes", icon: UserRound, show: true, mobile: true },
    { to: "/salas", label: "Salas", icon: DoorOpen, show: true, mobile: isStaff },
    { to: "/comunicacao", label: "Comunicação", icon: MessageCircle, show: true },
    { to: "/espera", label: "Lista de espera", icon: ListTodo, show: true },
    { to: "/financeiro", label: "Financeiro", icon: Wallet, show: user.role !== "reception", mobile: !isStaff },
    { to: "/equipe", label: "Equipe", icon: Users, show: isStaff },
    { to: "/relatorios", label: "Auditoria", icon: FileClock, show: isAdmin },
    { to: "/configuracoes", label: "Configurações", icon: Settings, show: isAdmin },
  ].filter((i) => i.show);

  return (
    <div className="min-h-full lg:grid lg:grid-cols-[260px_1fr]">
      <aside className="sticky top-0 hidden h-screen flex-col border-r border-line bg-surface px-4 py-5 lg:flex">
        <Logo compact className="px-2" />
        <nav className="mt-7 grid gap-1">
          {items.map((i) => (
            <NavLink key={i.to} to={i.to} end={i.to === "/"}
              className={({ isActive }) => cx("flex items-center gap-3 rounded-xl px-3 py-2.5 text-[14px] font-medium transition",
                isActive ? "bg-brand-soft text-brand" : "text-muted hover:bg-sunk hover:text-ink")}>
              <i.icon className="h-[18px] w-[18px]" />{i.label}
            </NavLink>
          ))}
        </nav>
        <div className="mt-auto grid gap-2">
          <NavLink to="/perfil" className={({ isActive }) => cx("flex items-center gap-3 rounded-xl p-2 transition", isActive ? "bg-sunk" : "hover:bg-sunk")}>
            <Avatar name={user.name} url={user.photo_url} color={user.color} size={38} />
            <div className="min-w-0">
              <p className="truncate text-sm font-semibold">{user.name}</p>
              <p className="text-xs text-muted">{ROLE_LABEL[user.role]}</p>
            </div>
          </NavLink>
          <button onClick={logout} className="flex items-center gap-3 rounded-xl px-3 py-2 text-sm text-muted hover:bg-sunk hover:text-ink">
            <LogOut className="h-4 w-4" /> Sair
          </button>
        </div>
      </aside>

      {/* Topo no celular */}
      <header className="sticky top-0 z-30 flex items-center justify-between border-b border-line bg-surface/90 px-4 py-2.5 backdrop-blur lg:hidden"
        style={{ paddingTop: "max(10px, env(safe-area-inset-top))" }}>
        <Logo compact />
        <NavLink to="/perfil" aria-label="Meu perfil"><Avatar name={user.name} url={user.photo_url} color={user.color} size={34} /></NavLink>
      </header>

      <main className="mx-auto w-full max-w-[1280px] px-4 pb-28 pt-5 sm:px-6 lg:px-8 lg:pb-10 lg:pt-8">
        <Outlet />
      </main>

      {/* Navegação inferior no celular */}
      <nav className="safe-bottom fixed inset-x-0 bottom-0 z-30 border-t border-line bg-surface/95 backdrop-blur lg:hidden">
        <div className="mx-auto flex max-w-lg justify-around">
          {items.filter((i) => i.mobile).map((i) => (
            <NavLink key={i.to} to={i.to} end={i.to === "/"}
              className={({ isActive }) => cx("flex flex-1 flex-col items-center gap-0.5 py-2 text-[11px] font-semibold", isActive ? "text-brand" : "text-muted")}>
              <i.icon className="h-[22px] w-[22px]" />{i.label}
            </NavLink>
          ))}
          <NavLink to="/mais" className={({ isActive }) => cx("flex flex-1 flex-col items-center gap-0.5 py-2 text-[11px] font-semibold", isActive ? "text-brand" : "text-muted")}>
            <Menu className="h-[22px] w-[22px]" />Mais
          </NavLink>
        </div>
      </nav>
    </div>
  );
}

/** Página "Mais" do celular: atalhos que não cabem na barra inferior. */
export function MorePage() {
  const { user, isAdmin, isStaff } = useMe();
  const { logout } = useAuth();
  const links = [
    { to: "/comunicacao", label: "Comunicação (WhatsApp)", icon: MessageCircle, show: true },
    { to: "/espera", label: "Lista de espera", icon: ListTodo, show: true },
    { to: "/salas", label: "Salas", icon: DoorOpen, show: !isStaff },
    { to: "/financeiro", label: "Financeiro", icon: Wallet, show: isStaff && user.role !== "reception" },
    { to: "/equipe", label: "Equipe", icon: Users, show: isStaff },
    { to: "/relatorios", label: "Auditoria", icon: FileClock, show: isAdmin },
    { to: "/configuracoes", label: "Configurações", icon: Settings, show: isAdmin },
    { to: "/perfil", label: "Meu perfil e segurança", icon: UserRound, show: true },
  ].filter((l) => l.show);
  return (
    <div className="grid gap-2">
      {links.map((l) => (
        <NavLink key={l.to} to={l.to} className="flex items-center gap-3 rounded-2xl border border-line bg-surface p-4 font-semibold shadow-card">
          <l.icon className="h-5 w-5 text-brand" />{l.label}
        </NavLink>
      ))}
      <button onClick={logout} className="flex items-center gap-3 rounded-2xl border border-line bg-surface p-4 font-semibold text-bad shadow-card">
        <LogOut className="h-5 w-5" /> Sair
      </button>
    </div>
  );
}
