import type { RecordTemplate, TemplateField } from "../lib/types";
import { Field, Input, Select, Textarea, cx } from "./ui";

/** Renderiza um modelo de prontuário (campos definidos no back-end) como formulário. */
export function RecordForm({ template, value, onChange }: { template: RecordTemplate; value: Record<string, any>; onChange: (v: Record<string, any>) => void }) {
  const set = (k: string, v: any) => onChange({ ...value, [k]: v });
  return (
    <div className="grid gap-4 sm:grid-cols-2">
      {template.fields.map((f) => (
        <div key={f.key} className={f.half ? "" : "sm:col-span-2"}>
          <FieldInput f={f} value={value[f.key]} onChange={(v) => set(f.key, v)} />
        </div>
      ))}
    </div>
  );
}

function FieldInput({ f, value, onChange }: { f: TemplateField; value: any; onChange: (v: any) => void }) {
  switch (f.type) {
    case "text":
      return <Field label={f.label}><Input value={value ?? ""} onChange={(e) => onChange(e.target.value)} /></Field>;
    case "number":
      return <Field label={f.label} hint={f.max != null ? `${f.min ?? 0} a ${f.max}` : undefined}>
        <Input type="number" inputMode="decimal" step="any" min={f.min} max={f.max} value={value ?? ""} onChange={(e) => onChange(e.target.value === "" ? null : Number(e.target.value))} /></Field>;
    case "date":
      return <Field label={f.label}><Input type="date" value={value ?? ""} onChange={(e) => onChange(e.target.value)} /></Field>;
    case "select":
      return <Field label={f.label}><Select value={value ?? ""} onChange={(e) => onChange(e.target.value)}>
        <option value="">—</option>{f.options?.map((o) => <option key={o}>{o}</option>)}</Select></Field>;
    case "scale":
      return (
        <div className="grid gap-1.5">
          <span className="text-[13px] font-medium text-muted">{f.label}</span>
          <div className="flex flex-wrap gap-1">
            {Array.from({ length: 11 }, (_, n) => (
              <button key={n} type="button" onClick={() => onChange(value === n ? null : n)}
                className={cx("h-9 w-9 rounded-lg border text-sm font-semibold transition", value === n ? "border-transparent text-white" : "border-line text-muted hover:border-brand/50")}
                style={value === n ? { background: `hsl(${120 - n * 12} 60% 42%)` } : undefined}>{n}</button>
            ))}
          </div>
        </div>
      );
    case "yesno":
      return (
        <div className="grid gap-1.5">
          <span className="text-[13px] font-medium text-muted">{f.label}</span>
          <div className="flex gap-2">
            {[["no", "Não"], ["yes", "Sim"]].map(([v, l]) => (
              <button key={v} type="button" onClick={() => onChange(value === v ? null : v)}
                className={cx("h-10 flex-1 rounded-xl border text-sm font-semibold", value === v ? (v === "yes" && f.alert ? "border-bad bg-bad-soft text-bad" : "border-brand bg-brand-soft text-brand") : "border-line text-muted")}>{l}</button>
            ))}
          </div>
        </div>
      );
    case "multi": {
      const list: string[] = Array.isArray(value) ? value : [];
      return (
        <div className="grid gap-1.5">
          <span className="text-[13px] font-medium text-muted">{f.label}</span>
          <div className="flex flex-wrap gap-1.5">
            {f.options?.map((o) => {
              const on = list.includes(o);
              return <button key={o} type="button" onClick={() => onChange(on ? list.filter((x) => x !== o) : [...list, o])}
                className={cx("rounded-full border px-3 py-1.5 text-[13px] font-medium", on ? "border-brand bg-brand-soft text-brand" : "border-line text-muted")}>{o}</button>;
            })}
          </div>
        </div>
      );
    }
    case "table": {
      const rows = (f.rows as string[]) ?? [];
      const v: Record<string, Record<string, string>> = value ?? {};
      const setCell = (r: string, c: string, x: string) => onChange({ ...v, [r]: { ...(v[r] ?? {}), [c]: x } });
      return (
        <div className="grid gap-1.5">
          <span className="text-[13px] font-medium text-muted">{f.label}</span>
          <div className="grid gap-3">
            {rows.map((r) => (
              <div key={r} className="rounded-xl border border-line p-3">
                <p className="mb-2 text-sm font-semibold">{r}</p>
                <div className="grid gap-2 sm:grid-cols-2">
                  {f.cols?.map((c) => <Input key={c} placeholder={c} className="h-10 text-sm" value={v[r]?.[c] ?? ""} onChange={(e) => setCell(r, c, e.target.value)} />)}
                </div>
              </div>
            ))}
          </div>
        </div>
      );
    }
    default:
      return <Field label={f.label}><Textarea rows={typeof f.rows === "number" ? f.rows : 3} value={value ?? ""} onChange={(e) => onChange(e.target.value)} /></Field>;
  }
}

/** Exibe um registro estruturado (somente leitura). */
export function RecordView({ template, data }: { template: RecordTemplate; data: Record<string, any> }) {
  return (
    <dl className="grid gap-x-6 gap-y-3 sm:grid-cols-2">
      {template.fields.map((f) => {
        const v = data[f.key];
        if (v == null || v === "" || (Array.isArray(v) && !v.length) || (typeof v === "object" && !Array.isArray(v) && !Object.keys(v).length)) return null;
        if (f.type === "table") {
          const rows = Object.entries(v as Record<string, Record<string, string>>).filter(([, c]) => Object.values(c ?? {}).some(Boolean));
          if (!rows.length) return null;
          return (
            <div key={f.key} className="sm:col-span-2">
              <dt className="text-xs font-semibold text-muted">{f.label}</dt>
              <dd className="scroll-x mt-1">
                <table className="w-full min-w-[520px] text-sm">
                  <thead><tr className="text-left text-xs text-muted"><th className="py-1 pr-3 font-medium">Área</th>{f.cols?.map((c) => <th key={c} className="py-1 pr-3 font-medium">{c}</th>)}</tr></thead>
                  <tbody>{rows.map(([r, c]) => <tr key={r} className="border-t border-line"><td className="py-1.5 pr-3 font-semibold">{r}</td>{f.cols?.map((col) => <td key={col} className="py-1.5 pr-3">{c?.[col] || "—"}</td>)}</tr>)}</tbody>
                </table>
              </dd>
            </div>
          );
        }
        let text: string = String(v);
        if (f.type === "yesno") text = v === "yes" ? "Sim" : "Não";
        if (f.type === "multi") text = (v as string[]).join(", ");
        if (f.type === "date") text = String(v).split("-").reverse().join("/");
        if (f.type === "scale") text = `${v} / 10`;
        const alert = (f.alert === "yes" && v === "yes");
        return (
          <div key={f.key} className={f.half ? "" : "sm:col-span-2"}>
            <dt className="text-xs font-semibold text-muted">{f.label}</dt>
            <dd className={cx("whitespace-pre-wrap text-[15px]", alert && "font-semibold text-bad")}>{text}</dd>
          </div>
        );
      })}
    </dl>
  );
}
