import { useState } from "react";
import { brl, fmtMonth } from "../lib/format";

/** Barras agrupadas por mês: entradas × saídas (uma escala só, valores em R$). */
export function MonthBars({ data, inLabel, outLabel }: { data: { month: string; in: number; out: number }[]; inLabel: string; outLabel: string }) {
  const [hover, setHover] = useState<number | null>(null);
  const W = 640, H = 220, padL = 56, padB = 28, padT = 12;
  const max = Math.max(1, ...data.flatMap((d) => [d.in, d.out]));
  const step = niceStep(max / 4);
  const top = Math.ceil(max / step) * step;
  const y = (v: number) => padT + (H - padT - padB) * (1 - v / top);
  const band = (W - padL - 8) / data.length;
  const bw = Math.min(26, band / 2 - 6);
  const ticks = Array.from({ length: Math.round(top / step) + 1 }, (_, i) => i * step);
  return (
    <div className="relative">
      <div className="mb-2 flex flex-wrap gap-4 text-xs text-muted">
        <span className="inline-flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-sm bg-chart-in" />{inLabel}</span>
        <span className="inline-flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-sm bg-chart-out" />{outLabel}</span>
      </div>
      <svg viewBox={`0 0 ${W} ${H}`} className="w-full" role="img" aria-label={`${inLabel} e ${outLabel} por mês`} onMouseLeave={() => setHover(null)}>
        {ticks.map((t) => (
          <g key={t}>
            <line x1={padL} x2={W - 4} y1={y(t)} y2={y(t)} stroke="rgb(var(--line))" strokeWidth={1} />
            <text x={padL - 8} y={y(t) + 4} textAnchor="end" fontSize={11} fill="rgb(var(--muted))">{short(t)}</text>
          </g>
        ))}
        {data.map((d, i) => {
          const cx = padL + band * i + band / 2;
          return (
            <g key={d.month} onMouseEnter={() => setHover(i)} onFocus={() => setHover(i)} tabIndex={0}>
              <rect x={padL + band * i} y={padT} width={band} height={H - padT - padB} fill={hover === i ? "rgb(var(--sunk))" : "transparent"} />
              <Bar x={cx - bw - 1} w={bw} y0={y(0)} y1={y(d.in)} fill="rgb(var(--chart-in))" />
              <Bar x={cx + 1} w={bw} y0={y(0)} y1={y(d.out)} fill="rgb(var(--chart-out))" />
              <text x={cx} y={H - 8} textAnchor="middle" fontSize={11} fill="rgb(var(--muted))">{fmtMonth(d.month).slice(0, 3)}</text>
            </g>
          );
        })}
      </svg>
      {hover != null && (
        <div className="pointer-events-none absolute top-8 rounded-xl border border-line bg-surface px-3 py-2 text-xs shadow-lg"
          style={{ left: `min(calc(${((padL + band * hover + band / 2) / W) * 100}% + 8px), calc(100% - 170px))` }}>
          <p className="mb-1 font-semibold">{fmtMonth(data[hover].month)}</p>
          <p className="flex items-center gap-1.5"><span className="h-2 w-2 rounded-sm bg-chart-in" />{inLabel}: <b className="tabular">{brl(data[hover].in)}</b></p>
          <p className="flex items-center gap-1.5"><span className="h-2 w-2 rounded-sm bg-chart-out" />{outLabel}: <b className="tabular">{brl(data[hover].out)}</b></p>
          <p className="mt-1 text-muted">Saldo: <b className="tabular text-ink">{brl(data[hover].in - data[hover].out)}</b></p>
        </div>
      )}
    </div>
  );
}

function Bar({ x, w, y0, y1, fill }: { x: number; w: number; y0: number; y1: number; fill: string }) {
  const h = Math.max(0, y0 - y1);
  if (h < 0.5) return null;
  const r = Math.min(4, h, w / 2);
  return <path d={`M${x},${y0} V${y1 + r} Q${x},${y1} ${x + r},${y1} H${x + w - r} Q${x + w},${y1} ${x + w},${y1 + r} V${y0} Z`} fill={fill} />;
}

function niceStep(raw: number) {
  const p = Math.pow(10, Math.floor(Math.log10(Math.max(raw, 1))));
  const n = raw / p;
  return (n <= 1 ? 1 : n <= 2 ? 2 : n <= 5 ? 5 : 10) * p;
}
const short = (v: number) => (v >= 1000 ? `${(v / 1000).toLocaleString("pt-BR", { maximumFractionDigits: 1 })} mil` : `${v}`);
