import { useEffect, useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Trash2 } from "lucide-react";
import { del, post, put } from "../lib/api";
import { useMe } from "../lib/auth";
import { brl, toHHMM, toMin } from "../lib/format";
import { useProfessionals, useRooms } from "../lib/queries";
import type { Reservation } from "../lib/types";
import { Button, ErrorBox, Field, Input, Select, Sheet, toast } from "./ui";

export type ResDraft = Partial<Reservation> & { date: string; start: string };

export function ReservationSheet({ draft, onClose }: { draft: ResDraft | null; onClose: () => void }) {
  const qc = useQueryClient();
  const { data: rooms } = useRooms();
  const { data: pros } = useProfessionals();
  const { isStaff, professionalId } = useMe();
  const [f, setF] = useState<any>(null);
  const [repeat, setRepeat] = useState(1);
  const [confirm, setConfirm] = useState<"" | "one" | "future">("");

  useEffect(() => {
    if (!draft) { setF(null); setConfirm(""); setRepeat(1); return; }
    setF({
      room_id: draft.room_id ?? rooms?.[0]?.id ?? "", professional_id: draft.professional_id ?? (isStaff ? "" : professionalId),
      date: draft.date, start: draft.start, end: draft.end ?? toHHMM(toMin(draft.start) + 240), notes: draft.notes ?? "",
    });
  }, [draft, rooms, isStaff, professionalId]);

  const done = (msg: string) => { qc.invalidateQueries({ queryKey: ["reservations"] }); qc.invalidateQueries({ queryKey: ["dashboard"] }); toast(msg); onClose(); };
  const save = useMutation({
    mutationFn: () => {
      const body = { ...f, room_id: Number(f.room_id), professional_id: Number(f.professional_id), repeat_weeks: repeat };
      return draft?.id ? put(`/reservations/${draft.id}`, body) : post("/reservations", body);
    },
    onSuccess: () => done("Reserva salva"),
  });
  const remove = useMutation({ mutationFn: (scope: string) => del(`/reservations/${draft!.id}?scope=${scope}`), onSuccess: () => done("Reserva excluída") });
  const room = rooms?.find((r) => r.id === Number(f?.room_id));
  const hours = f ? Math.max(0, (toMin(f.end) - toMin(f.start)) / 60) : 0;
  const set = (k: string) => (e: any) => setF({ ...f, [k]: e.target.value });

  return (
    <Sheet open={!!draft} onClose={onClose} title={draft?.id ? "Reserva de sala" : "Reservar sala"}
      footer={f && <>
        {(save.error || remove.error) && <div className="w-full"><ErrorBox error={save.error || remove.error} /></div>}
        {draft?.id && !confirm && <Button variant="ghost" className="mr-auto text-bad" onClick={() => setConfirm("one")}><Trash2 className="h-4 w-4" />Excluir</Button>}
        {confirm && <>
          <Button variant="danger" loading={remove.isPending} onClick={() => remove.mutate("one")}>Só esta</Button>
          {draft?.series_id && <Button variant="danger" loading={remove.isPending} onClick={() => remove.mutate("future")}>Esta e as próximas</Button>}
        </>}
        <Button onClick={onClose}>Cancelar</Button>
        <Button variant="primary" loading={save.isPending} disabled={!f.professional_id || !f.room_id} onClick={() => save.mutate()}>Salvar</Button>
      </>}>
      {f && (
        <div className="grid gap-4">
          <Field label="Sala">
            <Select value={f.room_id} onChange={set("room_id")}>
              {rooms?.map((r) => <option key={r.id} value={r.id}>{r.name} · {brl(r.hourly_rate)}/h</option>)}
            </Select>
          </Field>
          <Field label="Profissional">
            <Select value={f.professional_id} onChange={set("professional_id")} disabled={!isStaff}>
              <option value="">Selecione…</option>
              {pros?.filter((p) => p.attends && p.is_active).map((p) => <option key={p.id} value={p.id}>{p.name}{p.specialty ? ` · ${p.specialty}` : ""}</option>)}
            </Select>
          </Field>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
            <Field label="Data" className="col-span-2 sm:col-span-1"><Input type="date" value={f.date} onChange={set("date")} /></Field>
            <Field label="Início"><Input type="time" step={900} value={f.start} onChange={set("start")} /></Field>
            <Field label="Fim"><Input type="time" step={900} value={f.end} onChange={set("end")} /></Field>
          </div>
          {!draft?.id && (
            <Field label="Repetir toda semana">
              <Select value={repeat} onChange={(e) => setRepeat(Number(e.target.value))}>
                {[1, 4, 8, 12, 26, 52].map((n) => <option key={n} value={n}>{n === 1 ? "Não repetir (avulsa)" : `${n} semanas (fixa)`}</option>)}
              </Select>
            </Field>
          )}
          <Field label="Observação"><Input value={f.notes} onChange={set("notes")} /></Field>
          {room && <p className="rounded-xl bg-sunk p-3 text-sm">Valor estimado: <b>{hours.toLocaleString("pt-BR")} h × {brl(room.hourly_rate)} = {brl(hours * room.hourly_rate)}</b>{repeat > 1 && ` por semana`}<br />
            <span className="text-xs text-muted">Profissionais com cobrança mensal ou percentual pagam conforme o contrato.</span></p>}
        </div>
      )}
    </Sheet>
  );
}
