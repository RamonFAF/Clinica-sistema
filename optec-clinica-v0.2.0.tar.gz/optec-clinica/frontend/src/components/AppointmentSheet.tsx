import { useEffect, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { CheckCheck, FileText, MessageCircle, Receipt, RefreshCw, Trash2 } from "lucide-react";
import { del, get, post, put } from "../lib/api";
import { useMe } from "../lib/auth";
import { PAYMENT_METHODS, STATUS, fmtDateTime, toHHMM, toMin } from "../lib/format";
import { markReminderSent, reminderLink, reminderText } from "../lib/whatsapp";
import { useProfessionals, useSettings } from "../lib/queries";
import type { Appointment, Patient, SessionPackage, Status } from "../lib/types";
import { Button, ErrorBox, Field, Input, Select, Sheet, Textarea, Toggle, cx, toast } from "./ui";

export interface Draft { id?: number; patient_id?: number; date: string; start: string; end?: string; professional_id: number }

export function AppointmentSheet({ draft, onClose }: { draft: Draft | null; onClose: () => void }) {
  const qc = useQueryClient();
  const { data: settings } = useSettings();
  const { data: pros } = useProfessionals();
  const { isStaff } = useMe();
  const existing = useQuery({
    queryKey: ["appointment-edit", draft?.id],
    enabled: !!draft?.id,
    queryFn: async () => (await get<Appointment[]>(`/appointments?date_from=${draft!.date}&date_to=${draft!.date}&professional_id=${draft!.professional_id}`)).find((a) => a.id === draft!.id),
  });
  const patients = useQuery({
    queryKey: ["patients", "for", isStaff],
    enabled: !!draft,
    queryFn: () => get<Patient[]>("/patients"),
  });
  const [f, setF] = useState<any>(null);
  const [repeat, setRepeat] = useState(1);
  const [confirmDel, setConfirmDel] = useState(false);

  useEffect(() => {
    if (!draft) { setF(null); setConfirmDel(false); setRepeat(1); return; }
    if (draft.id && existing.data) setF({ ...existing.data });
    else if (!draft.id && settings) {
      const end = draft.end ?? toHHMM(toMin(draft.start) + settings.default_session_minutes);
      setF({ patient_id: draft.patient_id ?? "", professional_id: draft.professional_id, date: draft.date, start: draft.start, end,
             price: settings.default_price, status: "scheduled", online: false, paid: false, payment_method: "", notes: "", package_id: "" });
    }
  }, [draft, existing.data, settings]);

  const save = useMutation({
    mutationFn: () => {
      const body = { ...f, patient_id: Number(f.patient_id), price: Number(f.price), payment_method: f.payment_method || null, repeat_weeks: repeat,
                     professional_id: f.professional_id ? Number(f.professional_id) : null, package_id: f.package_id ? Number(f.package_id) : null };
      return draft?.id ? put(`/appointments/${draft.id}`, body) : post("/appointments", body);
    },
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["appointments"] }); qc.invalidateQueries({ queryKey: ["dashboard"] }); toast("Consulta salva"); onClose(); },
  });
  const remove = useMutation({
    mutationFn: () => del(`/appointments/${draft!.id}`),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["appointments"] }); toast("Consulta excluída"); onClose(); },
  });

  const profId = Number(f?.professional_id ?? draft?.professional_id);
  const prof = pros?.find((p) => p.id === profId);
  const pkgs = useQuery({
    queryKey: ["packages", "for", f?.patient_id, profId], enabled: !!f?.patient_id && !!profId,
    queryFn: () => get<SessionPackage[]>(`/packages?patient_id=${f.patient_id}&professional_id=${profId}&active_only=true`),
  });
  const usable = (pkgs.data ?? []).filter((k) => k.professional_id === profId && (k.left > 0 || k.id === existing.data?.package_id));
  const appt = existing.data;
  const waText = settings && appt ? reminderText(settings, appt, prof?.name ?? "") : "";
  const queryClient = qc;
  const set = (k: string) => (e: any) => setF({ ...f, [k]: e?.target ? e.target.value : e });

  return (
    <Sheet open={!!draft} onClose={onClose} title={draft?.id ? "Consulta" : "Nova consulta"}
      footer={f && <>
        {(save.error || remove.error) && <div className="w-full"><ErrorBox error={save.error || remove.error} /></div>}
        {draft?.id && (confirmDel
          ? <Button variant="danger" loading={remove.isPending} onClick={() => remove.mutate()}>Confirmar exclusão</Button>
          : <Button variant="ghost" className="mr-auto text-bad" onClick={() => setConfirmDel(true)}><Trash2 className="h-4 w-4" />Excluir</Button>)}
        <Button onClick={onClose}>Cancelar</Button>
        <Button variant="primary" loading={save.isPending} disabled={!f.patient_id} onClick={() => save.mutate()}>Salvar</Button>
      </>}>
      {!f ? <p className="text-sm text-muted">Carregando…</p> : (
        <div className="grid gap-4">
          {draft?.id && (
            <div className="flex flex-wrap gap-1.5">
              {(Object.keys(STATUS) as Status[]).map((s) => (
                <button key={s} onClick={() => setF({ ...f, status: s })}
                  className={cx("rounded-full border px-3 py-1 text-xs font-semibold", f.status === s ? "border-brand bg-brand-soft text-brand" : "border-line text-muted")}>{STATUS[s].label}</button>
              ))}
            </div>
          )}
          {isStaff && !draft?.id && (
            <Field label="Profissional que vai atender">
              <Select value={f.professional_id ?? ""} onChange={set("professional_id")}>
                {pros?.filter((p) => p.attends && p.is_active).map((p) => <option key={p.id} value={p.id}>{p.name} · {p.specialty}</option>)}
              </Select>
            </Field>
          )}
          <Field label="Paciente">
            <Select id="patient" value={f.patient_id} onChange={set("patient_id")} disabled={!!draft?.id}>
              <option value="">Selecione…</option>
              {patients.data?.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
            </Select>
          </Field>
          {!draft?.id && patients.data?.length === 0 && (
            <p className="text-sm text-muted">Nenhum paciente cadastrado. <Link to="/pacientes" className="font-semibold text-brand">Cadastrar paciente</Link></p>
          )}
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
            <Field label="Data" className="col-span-2 sm:col-span-1"><Input type="date" value={f.date} onChange={set("date")} /></Field>
            <Field label="Início"><Input type="time" step={300} value={f.start} onChange={set("start")} /></Field>
            <Field label="Fim"><Input type="time" step={300} value={f.end} onChange={set("end")} /></Field>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Valor (R$)"><Input type="number" inputMode="decimal" step="0.01" value={f.price} onChange={set("price")} /></Field>
            {!draft?.id
              ? <Field label="Repetir semanalmente"><Select value={repeat} onChange={(e) => setRepeat(Number(e.target.value))}>
                  {[1, 2, 4, 8, 12, 24].map((n) => <option key={n} value={n}>{n === 1 ? "Não repetir" : `${n} semanas`}</option>)}
                </Select></Field>
              : <Field label="Forma de pagamento"><Select value={f.payment_method ?? ""} onChange={set("payment_method")}>
                  <option value="">—</option>{PAYMENT_METHODS.map((m) => <option key={m}>{m}</option>)}
                </Select></Field>}
          </div>
          {usable.length > 0 && (
            <Field label="Usar pacote de sessões">
              <Select value={f.package_id ?? ""} onChange={set("package_id")}>
                <option value="">Não (consulta avulsa)</option>
                {usable.map((k) => <option key={k.id} value={k.id}>{k.name} · restam {k.left}</option>)}
              </Select>
            </Field>
          )}
          <Toggle checked={f.online} onChange={set("online")} label="Atendimento online" hint="Não precisa de sala reservada." />
          {!f.package_id && <Toggle checked={f.paid} onChange={set("paid")} label="Pago" />}
          <Field label="Observação (não clínica)"><Textarea rows={2} className="min-h-[64px]" value={f.notes ?? ""} onChange={set("notes")} /></Field>
          {appt?.patient_response === "confirmed" && <p className="flex items-center gap-2 rounded-xl bg-ok-soft p-3 text-sm font-semibold text-ok"><CheckCheck className="h-4 w-4" />Paciente confirmou pelo link {fmtDateTime(appt.patient_response_at)}</p>}
          {appt?.patient_response === "reschedule" && <p className="flex items-center gap-2 rounded-xl bg-warn-soft p-3 text-sm font-semibold text-warn"><RefreshCw className="h-4 w-4" />Paciente pediu para remarcar {fmtDateTime(appt.patient_response_at)}</p>}
          {appt && settings && (
            appt.consent_whatsapp && appt.patient_phone ? (
              <a href={reminderLink(settings, appt, prof?.name ?? "")} target="_blank" rel="noopener noreferrer"
                onClick={() => markReminderSent(appt.id).then(() => queryClient.invalidateQueries({ queryKey: ["appointments"] }))}
                className="flex items-start gap-3 rounded-xl border border-ok/30 bg-ok-soft p-3 text-sm text-ok">
                <MessageCircle className="mt-0.5 h-5 w-5 shrink-0" />
                <span><b>{appt.reminder_sent_at ? `Lembrete enviado ${fmtDateTime(appt.reminder_sent_at)} · reenviar` : "Enviar lembrete no WhatsApp"}</b><br /><span className="break-words text-ink/80">{waText}</span></span>
              </a>
            ) : <p className="rounded-xl bg-sunk p-3 text-xs text-muted">Lembrete por WhatsApp indisponível: paciente sem telefone ou sem consentimento registrado.</p>
          )}
          {appt && (
            <div className="flex flex-wrap gap-2">
              {["done", "confirmed"].includes(appt.status) && <a href={`/api/appointments/${appt.id}/attendance.pdf`} target="_blank" rel="noopener"><Button size="sm"><FileText className="h-4 w-4" />Declaração de comparecimento</Button></a>}
              {appt.paid && !appt.package_id && <a href={`/api/finance/receipt/appointment/${appt.id}.pdf`} target="_blank" rel="noopener"><Button size="sm"><Receipt className="h-4 w-4" />Recibo</Button></a>}
            </div>
          )}
        </div>
      )}
    </Sheet>
  );
}
