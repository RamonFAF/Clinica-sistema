import { useBranding } from "../lib/queries";
import { cx } from "./ui";

/** Logo da NeuroInsight (arquivos em /public). Se o administrador enviar outra logo, ela substitui a padrão. */
export function Logo({ compact, className }: { compact?: boolean; className?: string }) {
  const { data } = useBranding();
  const name = data?.clinic_name ?? "NeuroInsight";
  if (data?.logo_url) {
    return <img src={data.logo_url} alt={name} className={cx("object-contain", compact ? "h-10" : "h-28", className)} />;
  }
  if (!compact) {
    return (
      <div className={cx("mx-auto w-fit rounded-3xl bg-white p-3", className)}>
        <img src="/logo-full.png" alt={`${name} — ${data?.clinic_tagline ?? ""}`} className="h-36 w-auto object-contain" />
      </div>
    );
  }
  return (
    <div className={cx("flex items-center gap-2.5", className)}>
      <Mark size={38} />
      <div className="min-w-0 leading-tight">
        <p className="text-[17px] font-bold tracking-wide text-indigo">{name}</p>
      </div>
    </div>
  );
}

export function Mark({ size = 36 }: { size?: number }) {
  return <img src="/logo-mark.png" alt="" width={size} height={size} className="shrink-0 object-contain" style={{ width: size, height: size }} />;
}
