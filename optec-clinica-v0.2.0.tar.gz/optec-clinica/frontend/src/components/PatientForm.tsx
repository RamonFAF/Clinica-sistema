import { useEffect, useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { post, put } from "../lib/api";
import { useMe } from "../lib/auth";
import { useProfessionals } from "../lib/queries";
import type { Patient } from "../lib/types";
import { Button, ErrorBox, Field, Input, Select, Sheet, Textarea, Toggle, toast } from "./ui";

export function PatientForm({ open, patient, onClose, onSaved }: { open: boolean; patient?: Patient | null; onClose: () => void; onSaved?: (p: Patient) => void }) {
  const qc = useQueryClient();
  const { isStaff, professionalId } = useMe();
  const { data: pros } = useProfessionals();
  const [f, setF] = useState<any>({});
  useEffect(() => {
    if (open) setF(patient ? { ...patient } : { name: "", phone: "", email: "", birth_date: "", cpf: "", rg: "", sex: "", marital_status: "",
      occupation: "", address: "", insurance: "Particular", guardian: "", notes: "", consent_care: false, consent_ehr: false,
      consent_shared: false, consent_whatsapp: false, professional_id: isStaff ? "" : professionalId });
  }, [open, patient, isStaff, professionalId]);
  const owner = !patient || patient.notes !== undefined;
  const save = useMutation({
    mutationFn: () => {
      const body = { ...f, professional_id: f.professional_id ? Number(f.professional_id) : null, birth_date: f.birth_date || null };
      return patient ? put<Patient>(`/patients/${patient.id}`, body) : post<Patient>("/patients", body);
    },
    onSuccess: (p) => { qc.invalidateQueries({ queryKey: ["patients"] }); qc.invalidateQueries({ queryKey: ["patient", p.id] }); toast("Paciente salvo"); onSaved?.(p); onClose(); },
  });
  const set = (k: string) => (e: any) => setF({ ...f, [k]: e?.target ? e.target.value : e });
  return (
    <Sheet open={open} onClose={onClose} title={patient ? "Editar paciente" : "Novo paciente"} wide
      footer={<><Button onClick={onClose}>Cancelar</Button><Button variant="primary" loading={save.isPending} disabled={!f.name} onClick={() => save.mutate()}>Salvar</Button></>}>
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="Nome completo" className="sm:col-span-2"><Input id="patient-name" value={f.name ?? ""} onChange={set("name")} required /></Field>
        {isStaff && (
          <Field label="Profissional responsável" className="sm:col-span-2">
            <Select value={f.professional_id ?? ""} onChange={set("professional_id")}>
              <option value="">Selecione…</option>
              {pros?.filter((p) => p.attends).map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
            </Select>
          </Field>
        )}
        <Field label="WhatsApp (DDD + número)"><Input inputMode="tel" value={f.phone ?? ""} onChange={set("phone")} placeholder="11 91234-5678" /></Field>
        <Field label="E-mail"><Input type="email" value={f.email ?? ""} onChange={set("email")} /></Field>
        <Field label="Nascimento"><Input type="date" value={f.birth_date ?? ""} onChange={set("birth_date")} /></Field>
        <Field label="Sexo"><Select value={f.sex ?? ""} onChange={set("sex")}>
          <option value="">—</option>{["Feminino", "Masculino", "Outro", "Prefere não informar"].map((o) => <option key={o}>{o}</option>)}
        </Select></Field>
        <Field label="CPF" hint="Guardado cifrado."><Input inputMode="numeric" value={f.cpf ?? ""} onChange={set("cpf")} /></Field>
        <Field label="RG" hint="Guardado cifrado."><Input value={f.rg ?? ""} onChange={set("rg")} /></Field>
        <Field label="Estado civil"><Select value={f.marital_status ?? ""} onChange={set("marital_status")}>
          <option value="">—</option>{["Solteiro(a)", "Casado(a)", "União estável", "Divorciado(a)", "Viúvo(a)"].map((o) => <option key={o}>{o}</option>)}
        </Select></Field>
        <Field label="Profissão"><Input value={f.occupation ?? ""} onChange={set("occupation")} /></Field>
        <Field label="Endereço" className="sm:col-span-2" hint="Guardado cifrado."><Input value={f.address ?? ""} onChange={set("address")} /></Field>
        <Field label="Convênio"><Input value={f.insurance ?? ""} onChange={set("insurance")} placeholder="Particular" /></Field>
        <Field label="Responsável (se menor)"><Input value={f.guardian ?? ""} onChange={set("guardian")} /></Field>
        {owner && <Field label="Alertas clínicos (alergias, riscos)" className="sm:col-span-2" hint="Visível só para quem atende o paciente. Guardado cifrado.">
          <Textarea value={f.notes ?? ""} onChange={set("notes")} rows={2} className="min-h-[64px]" /></Field>}
        <div className="grid gap-3 rounded-2xl bg-sunk p-4 sm:col-span-2">
          <p className="text-xs font-semibold uppercase tracking-wide text-muted">Consentimento livre e esclarecido e LGPD</p>
          <Toggle checked={!!f.consent_care} onChange={set("consent_care")} label="Leu e concorda com o Termo de Consentimento" hint="Funcionamento, sigilo e seus limites, valores, faltas e cancelamento." />
          <Toggle checked={!!f.consent_ehr} onChange={set("consent_ehr")} label="Autoriza uso de dados para prontuário eletrônico seguro" />
          <Toggle checked={!!f.consent_shared} onChange={set("consent_shared")} label="Autoriza registro de evolução em prontuário compartilhado" hint="Sem isso, cada profissional vê só os próprios registros." />
          <Toggle checked={!!f.consent_whatsapp} onChange={set("consent_whatsapp")} label="Autoriza contato por WhatsApp para agendamentos" />
        </div>
        {patient && <div className="sm:col-span-2"><Toggle checked={!!f.archived} onChange={set("archived")} label="Arquivar paciente" hint="Sai da lista, mas o prontuário continua guardado." /></div>}
        <div className="sm:col-span-2"><ErrorBox error={save.error} /></div>
      </div>
    </Sheet>
  );
}
