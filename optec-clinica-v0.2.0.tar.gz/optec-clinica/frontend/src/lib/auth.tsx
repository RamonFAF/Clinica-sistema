import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { ApiError, get, post } from "./api";
import type { AuthState } from "./types";

interface Ctx {
  state: AuthState | null;
  loading: boolean;
  setState: (s: AuthState | null) => void;
  refresh: () => Promise<void>;
  logout: () => Promise<void>;
}
const AuthCtx = createContext<Ctx>(null as unknown as Ctx);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<AuthState | null>(null);
  const [loading, setLoading] = useState(true);
  const qc = useQueryClient();

  const refresh = useCallback(async () => {
    try {
      setState(await get<AuthState>("/auth/me"));
    } catch (e) {
      if (e instanceof ApiError && e.status === 401) setState(null);
    } finally {
      setLoading(false);
    }
  }, []);

  const logout = useCallback(async () => {
    try { await post("/auth/logout"); } catch { /* sessão já expirada */ }
    qc.clear();
    setState(null);
  }, [qc]);

  useEffect(() => {
    refresh();
    const onChange = () => refresh();
    window.addEventListener("auth:changed", onChange);
    return () => window.removeEventListener("auth:changed", onChange);
  }, [refresh]);

  return <AuthCtx.Provider value={{ state, loading, setState, refresh, logout }}>{children}</AuthCtx.Provider>;
}

export const useAuth = () => useContext(AuthCtx);

export function useMe() {
  const { state } = useAuth();
  const u = state!.user;
  return {
    user: u,
    isAdmin: u.role === "admin",
    isStaff: u.role === "admin" || u.role === "reception",
    professionalId: u.professional_id,
  };
}
