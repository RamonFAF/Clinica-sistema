import { useQuery } from "@tanstack/react-query";
import { get } from "./api";
import type { Professional, Room, Settings } from "./types";

export const useSettings = () => useQuery({ queryKey: ["settings"], queryFn: () => get<Settings>("/settings"), staleTime: 60_000 });
export const useRooms = (includeInactive = false) =>
  useQuery({ queryKey: ["rooms", includeInactive], queryFn: () => get<Room[]>(`/rooms${includeInactive ? "?include_inactive=true" : ""}`) });
export const useProfessionals = () => useQuery({ queryKey: ["professionals"], queryFn: () => get<Professional[]>("/professionals") });
export const useBranding = () =>
  useQuery({ queryKey: ["branding"], queryFn: () => get<{ clinic_name: string; clinic_tagline: string; logo_url: string | null }>("/public/branding"), staleTime: 300_000 });
