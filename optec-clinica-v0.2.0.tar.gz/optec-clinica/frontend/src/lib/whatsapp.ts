import { post } from "./api";
import { brl, fillTemplate, fmtDate, whatsappLink } from "./format";
import type { Appointment, Settings } from "./types";

export const confirmUrl = (a: Appointment) => (a.confirm_token ? `${window.location.origin}/c/${a.confirm_token}` : "");

export function reminderText(s: Settings, a: Appointment, professional: string) {
  return fillTemplate(s.whatsapp_template, {
    paciente: a.patient_name.split(" ")[0], profissional: professional, data: fmtDate(a.date), hora: a.start,
    clinica: s.clinic_name, link: confirmUrl(a),
  });
}

export function reminderLink(s: Settings, a: Appointment, professional: string) {
  return whatsappLink(a.patient_phone, reminderText(s, a, professional));
}

export function chargeText(s: Settings, patient: string, total: number, items: string, professional: string) {
  return fillTemplate(s.whatsapp_charge_template, { paciente: patient.split(" ")[0], valor: brl(total), itens: items, profissional: professional, clinica: s.clinic_name });
}

export function birthdayText(s: Settings, patient: string) {
  return fillTemplate(s.whatsapp_birthday_template, { paciente: patient.split(" ")[0], clinica: s.clinic_name });
}

/** Marca o lembrete como enviado (a mensagem em si sai pelo WhatsApp do celular/computador). */
export const markReminderSent = (id: number) => post(`/appointments/${id}/reminder-sent`);
