export type Role = "admin" | "reception" | "professional";

export interface User {
  id: number; email: string; name: string; role: Role; is_active: boolean; totp_enabled: boolean;
  professional_id: number | null; photo_url: string | null; color: string | null; last_login_at: string | null;
}
export interface AuthState {
  user: User; mfa_pending: boolean; password_change_required: boolean; mfa_setup_required: boolean;
}
export interface Professional {
  id: number; user_id: number; name: string; email?: string; role: Role; is_active: boolean; totp_enabled?: boolean;
  council: string | null; document?: string | null; specialty: string | null; phone: string | null; color: string;
  billing_model?: "hourly" | "monthly" | "percent"; monthly_fee?: number; percent?: number; bio: string | null;
  attends: boolean; photo_url: string | null; last_login_at?: string | null; temp_password?: string;
}
export interface Room { id: number; name: string; resources: string | null; area_m2: number; hourly_rate: number; active: boolean; sort_order: number }
export interface Reservation { id: number; room_id: number; professional_id: number; date: string; start: string; end: string; series_id: string | null; notes: string | null }
export type Status = "scheduled" | "confirmed" | "done" | "no_show" | "canceled";
export interface Appointment {
  id: number; patient_id: number; patient_name: string; patient_phone: string | null; professional_id: number;
  date: string; start: string; end: string; price: number; status: Status; online: boolean; paid: boolean;
  payment_method: string | null; notes: string | null; package_id: number | null; reminder_sent_at: string | null;
  patient_response: "confirmed" | "reschedule" | null; patient_response_at: string | null; consent_whatsapp: boolean;
  confirm_token: string | null;
}
export interface Patient {
  id: number; professional_id: number; name: string; phone: string | null; email: string | null; birth_date: string | null;
  cpf?: string | null; rg?: string | null; sex?: string | null; marital_status?: string | null; occupation?: string | null;
  address?: string | null; insurance?: string | null; guardian?: string | null; notes?: string | null;
  consent_care: boolean; consent_ehr: boolean; consent_shared: boolean; consent_whatsapp: boolean; consent_at: string | null;
  archived: boolean; created_at: string; team?: number[]; record_number?: string;
}
export interface RecordEntry {
  id: number; kind: "note" | "soap" | "addendum" | "form"; template: string | null; template_name: string | null;
  visibility: "team" | "private"; title: string | null; content: string; data: Record<string, any> | null; parent_id: number | null;
  created_at: string; professional_id: number; author: string; author_specialty: string | null; alerts: string[];
}
export interface TemplateField {
  key: string; label: string; type: "text" | "textarea" | "number" | "scale" | "select" | "multi" | "yesno" | "date" | "table";
  options?: string[]; rows?: string[] | number; cols?: string[]; half?: boolean; min?: number; max?: number; alert?: string;
}
export interface RecordTemplate { key: string; name: string; area: string; visibility: "team" | "private"; hint?: string; frequent?: boolean; fields: TemplateField[] }
export interface Attachment { id: number; filename: string; mime: string; size: number; visibility: "team" | "private"; created_at: string; author: string; professional_id: number }
export interface SessionPackage {
  id: number; patient_id: number; professional_id: number; name: string; sessions_total: number; used: number; left: number;
  price: number; paid: boolean; paid_at: string | null; payment_method: string | null; active: boolean; created_at: string;
}
export interface Expense { id: number; date: string; description: string; category: string; amount: number; paid: boolean; series_id: string | null; scope: "clinic" | "mine" }
export interface WaitItem {
  id: number; professional_id: number | null; patient_id: number | null; name: string; phone: string | null; specialty: string | null;
  preference: string | null; notes: string | null; status: "waiting" | "contacted" | "scheduled" | "gave_up"; created_at: string;
}
export interface Settings {
  clinic_name: string; clinic_tagline: string; clinic_phone: string; clinic_address: string; clinic_city: string; clinic_document: string;
  logo_url: string | null; whatsapp_charge_template: string; whatsapp_birthday_template: string; record_footer: string;
  open_time: string; close_time: string; slot_minutes: number; open_weekdays: number[]; default_session_minutes: number;
  default_price: number; default_room_rate: number; cancel_hours: number; invoice_due_day: number;
  professionals_can_book_rooms: boolean; require_room_for_in_person: boolean; mfa_required: boolean;
  session_idle_minutes: number; min_password_length: number; max_failed_logins: number; lockout_minutes: number;
  whatsapp_template: string;
}
