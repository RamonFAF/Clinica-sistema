import type { Status } from "./types";

export const brl = (v: number | null | undefined) =>
  (v ?? 0).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
export const pct = (v: number) => `${Math.round((v || 0) * 100)}%`;

export const iso = (d: Date) => {
  const z = new Date(d.getTime() - d.getTimezoneOffset() * 60000);
  return z.toISOString().slice(0, 10);
};
export const today = () => iso(new Date());
export const parseISO = (s: string) => new Date(s + "T12:00:00");
export const addDays = (s: string, n: number) => { const d = parseISO(s); d.setDate(d.getDate() + n); return iso(d); };
export const mondayOf = (s: string) => { const d = parseISO(s); d.setDate(d.getDate() - ((d.getDay() + 6) % 7)); return iso(d); };
export const fmtDate = (s: string | null | undefined) => (s ? s.slice(0, 10).split("-").reverse().join("/") : "");
export const capFirst = (s: string) => s.charAt(0).toUpperCase() + s.slice(1);
export const fmtDayLong = (s: string) =>
  capFirst(parseISO(s).toLocaleDateString("pt-BR", { weekday: "long", day: "numeric", month: "long" }));
export const fmtDateTime = (s: string | null | undefined) =>
  s ? new Date(s).toLocaleString("pt-BR", { dateStyle: "short", timeStyle: "short" }) : "";
export const WEEKDAYS = ["Seg", "Ter", "Qua", "Qui", "Sex", "Sáb", "Dom"];
export const toMin = (t: string) => Number(t.slice(0, 2)) * 60 + Number(t.slice(3, 5));
export const toHHMM = (m: number) => `${String(Math.floor(m / 60)).padStart(2, "0")}:${String(m % 60).padStart(2, "0")}`;
export const monthNow = () => today().slice(0, 7);
export const fmtMonth = (m: string) =>
  capFirst(parseISO(m + "-01").toLocaleDateString("pt-BR", { month: "long", year: "numeric" }));
export const shiftMonth = (m: string, n: number) => {
  const d = parseISO(m + "-01"); d.setMonth(d.getMonth() + n); return iso(d).slice(0, 7);
};
export const age = (birth: string | null) => {
  if (!birth) return null;
  const b = parseISO(birth), n = new Date();
  let a = n.getFullYear() - b.getFullYear();
  if (n < new Date(n.getFullYear(), b.getMonth(), b.getDate())) a--;
  return a;
};

export const STATUS: Record<Status, { label: string; tone: "warn" | "ok" | "info" | "bad" | "muted" }> = {
  scheduled: { label: "Agendada", tone: "warn" },
  confirmed: { label: "Confirmada", tone: "ok" },
  done: { label: "Realizada", tone: "info" },
  no_show: { label: "Faltou", tone: "bad" },
  canceled: { label: "Cancelada", tone: "muted" },
};
export const ROLE_LABEL = { admin: "Administrador", reception: "Recepção", professional: "Profissional" } as const;
export const BILLING_LABEL = { hourly: "Por hora de sala", monthly: "Mensal fixo", percent: "% dos atendimentos" } as const;
export const PAYMENT_METHODS = ["pix", "dinheiro", "cartão de débito", "cartão de crédito", "convênio", "transferência"];

export function whatsappLink(phone: string | null, text: string) {
  const digits = (phone ?? "").replace(/\D/g, "");
  const full = digits.length <= 11 ? "55" + digits : digits;
  return `https://wa.me/${full}?text=${encodeURIComponent(text)}`;
}
export function fillTemplate(tpl: string, vars: Record<string, string>) {
  return tpl.replace(/\{(\w+)\}/g, (_, k) => vars[k] ?? `{${k}}`);
}
