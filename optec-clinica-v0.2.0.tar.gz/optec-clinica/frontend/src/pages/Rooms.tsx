import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { ChevronLeft, ChevronRight, DoorOpen, Plus } from "lucide-react";
import { get } from "../lib/api";
import { useMe } from "../lib/auth";
import { addDays, brl, fmtDayLong, toHHMM, toMin, today } from "../lib/format";
import { useProfessionals, useRooms, useSettings } from "../lib/queries";
import type { Reservation } from "../lib/types";
import { ReservationSheet, type ResDraft } from "../components/ReservationSheet";
import { Avatar, Button, Card, Empty, Input, PageHeader, Spinner, cx } from "../components/ui";

const COL_PX = 34;

export function RoomsPage() {
  const { isStaff, professionalId } = useMe();
  const { data: settings } = useSettings();
  const { data: rooms } = useRooms();
  const { data: pros } = useProfessionals();
  const [day, setDay] = useState(today());
  const [draft, setDraft] = useState<ResDraft | null>(null);
  const res = useQuery({ queryKey: ["reservations", "day", day], queryFn: () => get<Reservation[]>(`/reservations?date_from=${day}&date_to=${day}`) });
  if (!settings || !rooms) return <Spinner />;
  const canBook = isStaff || settings.professionals_can_book_rooms;
  const open = toMin(settings.open_time), close = toMin(settings.close_time), slot = 30;
  const slots = Array.from({ length: Math.ceil((close - open) / slot) }, (_, i) => open + i * slot);
  const prof = (id: number) => pros?.find((p) => p.id === id);
  const canEdit = (r: Reservation) => isStaff || (canBook && r.professional_id === professionalId);
  const book = (room_id: number, start: string) => canBook && setDraft({ room_id, date: day, start, professional_id: isStaff ? undefined : professionalId ?? undefined });

  return (
    <div className="grid gap-4">
      <PageHeader title="Salas" subtitle={fmtDayLong(day)}
        actions={<>
          <div className="flex items-center gap-1">
            <Button aria-label="Dia anterior" onClick={() => setDay(addDays(day, -1))}><ChevronLeft className="h-4 w-4" /></Button>
            <Input type="date" className="h-10 w-auto" value={day} onChange={(e) => e.target.value && setDay(e.target.value)} />
            <Button aria-label="Próximo dia" onClick={() => setDay(addDays(day, 1))}><ChevronRight className="h-4 w-4" /></Button>
          </div>
          {canBook && <Button variant="primary" onClick={() => book(rooms[0]?.id, settings.open_time)} disabled={!rooms.length}><Plus className="h-4 w-4" />Reservar</Button>}
        </>} />

      {!rooms.length ? (
        <Card><Empty icon={<DoorOpen className="h-8 w-8" />} title="Nenhuma sala cadastrada" text="O administrador define a quantidade de salas em Configurações." /></Card>
      ) : (
        <>
          {/* Grade (tablet e desktop) */}
          <div className="scroll-x hidden rounded-2xl border border-line bg-surface shadow-card md:block">
            <div className="grid" style={{ gridTemplateColumns: `150px repeat(${slots.length}, minmax(${COL_PX}px, 1fr))`, minWidth: 150 + slots.length * COL_PX }}>
              <div className="border-b border-line" />
              {slots.map((m, i) => (
                <div key={m} className="border-b border-l border-line py-2 text-center text-[11px] text-muted tabular">{i % 2 === 0 ? toHHMM(m) : ""}</div>
              ))}
              {rooms.map((r, ri) => {
                const row = ri + 2;
                return [
                  <div key={"l" + r.id} className="border-b border-line px-3 py-2" style={{ gridRow: row, gridColumn: 1 }}>
                    <p className="font-semibold">{r.name}</p>
                    <p className="truncate text-xs text-muted">{r.resources || "—"} · {brl(r.hourly_rate)}/h</p>
                  </div>,
                  ...slots.map((m, i) => (
                    <button key={r.id + "-" + m} aria-label={`Reservar ${r.name} ${toHHMM(m)}`} disabled={!canBook} onClick={() => book(r.id, toHHMM(m))}
                      className={cx("border-b border-l border-line/60 hover:bg-brand-soft/60 disabled:cursor-default disabled:hover:bg-transparent", i % 2 === 0 && "border-l-line")}
                      style={{ gridRow: row, gridColumn: i + 2, minHeight: 58 }} />
                  )),
                  ...(res.data ?? []).filter((x) => x.room_id === r.id).map((x) => {
                    const a = Math.max(0, Math.floor((toMin(x.start) - open) / slot)), b = Math.min(slots.length, Math.ceil((toMin(x.end) - open) / slot));
                    const p = prof(x.professional_id);
                    if (b <= 0 || a >= slots.length) return null;
                    return (
                      <button key={"r" + x.id} onClick={() => canEdit(x) && setDraft(x)}
                        className={cx("z-10 m-1 flex items-center gap-2 overflow-hidden rounded-xl px-2 text-left text-white shadow-sm", !canEdit(x) && "cursor-default")}
                        style={{ gridRow: row, gridColumn: `${a + 2} / ${b + 2}`, background: p?.color ?? "rgb(var(--brand))" }}>
                        {p && <Avatar name={p.name} url={p.photo_url} color={p.color} size={26} />}
                        <span className="min-w-0 leading-tight"><span className="block truncate text-[13px] font-semibold">{p?.name ?? "Profissional"}</span>
                          <span className="block truncate text-[11px] opacity-90">{x.start}–{x.end}{x.series_id ? " · fixa" : ""}</span></span>
                      </button>
                    );
                  }),
                ];
              })}
            </div>
          </div>

          {/* Lista (celular) */}
          <div className="grid gap-3 md:hidden">
            {rooms.map((r) => {
              const list = (res.data ?? []).filter((x) => x.room_id === r.id);
              return (
                <Card key={r.id} title={<span>{r.name} <span className="text-xs font-normal text-muted">· {brl(r.hourly_rate)}/h</span></span>}
                  action={canBook && <Button size="sm" onClick={() => book(r.id, settings.open_time)}><Plus className="h-4 w-4" />Reservar</Button>}>
                  {list.length === 0 ? <p className="text-sm text-muted">Livre o dia todo.</p> : (
                    <ul className="grid gap-2">
                      {list.map((x) => {
                        const p = prof(x.professional_id);
                        return (
                          <li key={x.id}>
                            <button onClick={() => canEdit(x) && setDraft(x)} className="flex w-full items-center gap-3 rounded-xl border border-line p-2.5 text-left">
                              <span className="h-9 w-1.5 rounded-full" style={{ background: p?.color }} />
                              {p && <Avatar name={p.name} url={p.photo_url} color={p.color} size={32} />}
                              <span className="min-w-0 flex-1"><span className="block truncate font-semibold">{p?.name}</span><span className="text-xs text-muted">{p?.specialty}</span></span>
                              <span className="tabular text-sm font-semibold">{x.start}–{x.end}</span>
                            </button>
                          </li>
                        );
                      })}
                    </ul>
                  )}
                </Card>
              );
            })}
          </div>
        </>
      )}
      <ReservationSheet draft={draft} onClose={() => setDraft(null)} />
    </div>
  );
}
