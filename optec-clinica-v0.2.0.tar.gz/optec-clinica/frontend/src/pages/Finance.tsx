import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { AlertTriangle, CheckCircle2, ChevronLeft, ChevronRight, Download, Package, Plus, Receipt, Trash2, Wallet } from "lucide-react";
import { del, get, patch, post, put } from "../lib/api";
import { useMe } from "../lib/auth";
import { BILLING_LABEL, PAYMENT_METHODS, STATUS, brl, fmtDate, fmtMonth, monthNow, shiftMonth, today } from "../lib/format";
import { useProfessionals } from "../lib/queries";
import type { Expense, SessionPackage } from "../lib/types";
import { MonthBars } from "../components/MonthBars";
import { Badge, Button, Card, Empty, ErrorBox, Field, Input, PageHeader, Segmented, Select, Sheet, Spinner, Stat, Toggle, toast } from "../components/ui";

interface Invoice {
  professional_id: number; name: string; specialty: string | null; billing_model: keyof typeof BILLING_LABEL; hours: number; revenue: number;
  base: number; adjustments_total: number; amount: number; paid: boolean; paid_at: string | null; payment_method: string | null;
  due_date: string; overdue: boolean; month: string;
  reservations?: { date: string; start: string; end: string; room: string; hours: number; value: number }[];
  adjustments?: { id: number; description: string; amount: number }[];
}

function MonthNav({ month, setMonth }: { month: string; setMonth: (m: string) => void }) {
  return (
    <div className="flex items-center gap-1">
      <Button aria-label="Mês anterior" onClick={() => setMonth(shiftMonth(month, -1))}><ChevronLeft className="h-4 w-4" /></Button>
      <span className="min-w-[140px] text-center text-sm font-semibold">{fmtMonth(month)}</span>
      <Button aria-label="Próximo mês" onClick={() => setMonth(shiftMonth(month, 1))}><ChevronRight className="h-4 w-4" /></Button>
    </div>
  );
}

const invalidate = (qc: ReturnType<typeof useQueryClient>) => ["invoices", "invoice", "overview", "statement", "expenses", "dashboard", "packages"].forEach((k) => qc.invalidateQueries({ queryKey: [k] }));

/* ---------- clínica ---------- */

function Overview({ month }: { month: string }) {
  const { data, isLoading } = useQuery({ queryKey: ["overview", month], queryFn: () => get<any>(`/finance/overview?month=${month}`) });
  if (isLoading || !data) return <Spinner />;
  const maxCat = Math.max(1, ...data.by_category.map((c: [string, number]) => c[1]));
  return (
    <div className="grid gap-4">
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat label="Aluguel faturado" value={brl(data.billed)} hint={`recebido ${brl(data.received)}`} />
        <Stat label="Despesas da clínica" value={brl(data.expenses)} />
        <Stat label="Resultado (recebido − despesas)" value={brl(data.result)} tone={data.result < 0 ? "bad" : "ok"} hint={`previsto ${brl(data.projected)}`} />
        <Stat label="Faturas em atraso" value={brl(data.overdue_total)} tone={data.overdue_total ? "bad" : undefined} hint={`${data.overdue.length} fatura(s)`} />
      </div>
      <div className="grid gap-4 lg:grid-cols-[1.5fr_1fr]">
        <Card title="Últimos 6 meses">
          <MonthBars inLabel="Aluguel recebido" outLabel="Despesas" data={data.series.map((m: any) => ({ month: m.month, in: m.received, out: m.expenses }))} />
        </Card>
        <Card title="Despesas por categoria">
          {!data.by_category.length ? <Empty title="Sem despesas no mês" /> : (
            <div className="grid gap-2.5">
              {data.by_category.map(([c, v]: [string, number]) => (
                <div key={c} className="grid grid-cols-[1fr_auto] items-center gap-x-3 gap-y-1 text-sm">
                  <span className="truncate">{c}</span><span className="tabular font-semibold">{brl(v)}</span>
                  <div className="col-span-2 h-2 overflow-hidden rounded-full bg-sunk"><div className="h-full rounded-full bg-chart-out" style={{ width: `${(v / maxCat) * 100}%` }} /></div>
                </div>
              ))}
            </div>
          )}
        </Card>
      </div>
      <div className="grid gap-4 lg:grid-cols-2">
        <Card title="Receita por sala no mês">
          <table className="w-full text-sm tabular">
            <tbody>{data.rooms.filter((r: any) => r.active || r.hours).map((r: any) => (
              <tr key={r.room} className="border-b border-line last:border-0"><td className="py-2 font-medium">{r.room}</td><td className="text-right text-muted">{r.hours.toLocaleString("pt-BR")} h</td><td className="text-right font-semibold">{brl(r.value)}</td></tr>
            ))}</tbody>
          </table>
          <p className="mt-2 text-xs text-muted">Valor por hora de tabela; profissionais com cobrança mensal ou percentual pagam conforme o contrato.</p>
        </Card>
        <Card title="Faturas em atraso">
          {!data.overdue.length ? <Empty title="Nenhuma fatura em atraso" /> : (
            <ul className="divide-y divide-line">{data.overdue.map((o: Invoice) => (
              <li key={o.professional_id + o.month} className="flex items-center justify-between gap-2 py-2 text-sm">
                <span><b>{o.name}</b> <span className="text-muted">· {fmtMonth(o.month)} · venceu {fmtDate(o.due_date)}</span></span>
                <span className="tabular font-semibold text-bad">{brl(o.amount)}</span>
              </li>
            ))}</ul>
          )}
        </Card>
      </div>
    </div>
  );
}

function InvoiceSheet({ pid, month, onClose }: { pid: number | null; month: string; onClose: () => void }) {
  const qc = useQueryClient();
  const { isAdmin } = useMe();
  const { data } = useQuery({ queryKey: ["invoice", pid, month], enabled: !!pid, queryFn: () => get<Invoice>(`/finance/invoices/${pid}/${month}`) });
  const [adj, setAdj] = useState({ description: "", amount: "" });
  const [method, setMethod] = useState("pix");
  const addAdj = useMutation({ mutationFn: () => post(`/finance/invoices/${pid}/${month}/adjustments`, { description: adj.description, amount: Number(adj.amount) }),
    onSuccess: () => { invalidate(qc); setAdj({ description: "", amount: "" }); } });
  const delAdj = useMutation({ mutationFn: (id: number) => del(`/finance/adjustments/${id}`), onSuccess: () => invalidate(qc) });
  const pay = useMutation({ mutationFn: () => data!.paid ? del(`/finance/invoices/${pid}/${month}/pay`) : post(`/finance/invoices/${pid}/${month}/pay`, { payment_method: method }),
    onSuccess: () => { invalidate(qc); toast("Fatura atualizada"); } });
  return (
    <Sheet open={!!pid} onClose={onClose} wide title={data ? `Aluguel · ${data.name} · ${fmtMonth(month)}` : "Fatura"}
      footer={data && <>
        {data.paid && <a href={`/api/finance/invoices/${pid}/${month}/receipt.pdf`} target="_blank" rel="noopener" className="mr-auto"><Button><Receipt className="h-4 w-4" />Recibo</Button></a>}
        {isAdmin && !data.paid && <Select className="h-10 w-40" value={method} onChange={(e) => setMethod(e.target.value)}>{PAYMENT_METHODS.map((m) => <option key={m}>{m}</option>)}</Select>}
        {isAdmin && <Button variant={data.paid ? "secondary" : "primary"} loading={pay.isPending} onClick={() => pay.mutate()}>{data.paid ? "Desfazer pagamento" : "Registrar pagamento"}</Button>}
      </>}>
      {!data ? <Spinner /> : (
        <div className="grid gap-4">
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            <Stat label="Modelo" value={<span className="text-base">{BILLING_LABEL[data.billing_model]}</span>} />
            <Stat label="Horas de sala" value={`${data.hours.toLocaleString("pt-BR")} h`} />
            <Stat label="Valor" value={brl(data.amount)} hint={data.adjustments_total ? `base ${brl(data.base)}` : undefined} />
            <Stat label="Vencimento" value={<span className="text-base">{fmtDate(data.due_date)}</span>} hint={data.paid ? `pago ${data.payment_method ?? ""}` : data.overdue ? "em atraso" : "em aberto"} tone={data.paid ? "ok" : data.overdue ? "bad" : undefined} />
          </div>
          <div>
            <p className="mb-2 text-sm font-semibold">Descontos e acréscimos</p>
            {data.adjustments?.map((a) => (
              <div key={a.id} className="flex items-center justify-between border-b border-line py-1.5 text-sm">
                <span>{a.description}</span>
                <span className="flex items-center gap-2"><b className={a.amount < 0 ? "text-ok" : "text-bad"}>{brl(a.amount)}</b>
                  {isAdmin && !data.paid && <button aria-label="Remover" onClick={() => delAdj.mutate(a.id)} className="text-muted hover:text-bad"><Trash2 className="h-4 w-4" /></button>}</span>
              </div>
            ))}
            {isAdmin && !data.paid && (
              <div className="mt-2 flex flex-wrap gap-2">
                <Input className="h-10 min-w-[180px] flex-1" placeholder="Descrição (ex.: desconto parceria)" value={adj.description} onChange={(e) => setAdj({ ...adj, description: e.target.value })} />
                <Input className="h-10 w-32" type="number" step="0.01" placeholder="-50,00" value={adj.amount} onChange={(e) => setAdj({ ...adj, amount: e.target.value })} />
                <Button loading={addAdj.isPending} onClick={() => addAdj.mutate()} disabled={!adj.description || !adj.amount}>Adicionar</Button>
              </div>
            )}
            <ErrorBox error={addAdj.error} />
          </div>
          <div>
            <p className="mb-2 text-sm font-semibold">Reservas do mês ({data.reservations?.length ?? 0})</p>
            <div className="scroll-x max-h-72 overflow-y-auto">
              <table className="w-full min-w-[420px] text-sm tabular">
                <tbody>{data.reservations?.map((r, i) => (
                  <tr key={i} className="border-b border-line"><td className="py-1.5">{fmtDate(r.date)}</td><td>{r.start}–{r.end}</td><td>{r.room}</td><td className="text-right">{r.hours.toLocaleString("pt-BR")} h</td><td className="text-right">{brl(r.value)}</td></tr>
                ))}</tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </Sheet>
  );
}

function Invoices({ month }: { month: string }) {
  const { data, isLoading } = useQuery({ queryKey: ["invoices", month], queryFn: () => get<Invoice[]>(`/finance/invoices?month=${month}`) });
  const [open, setOpen] = useState<number | null>(null);
  if (isLoading) return <Spinner />;
  return (
    <>
      <Card title="Faturas de aluguel" className="p-0 sm:p-0">
        {!data?.length ? <Empty icon={<Wallet className="h-8 w-8" />} title="Nada faturado neste mês" text="As faturas vêm das reservas de sala e do modelo de cobrança de cada profissional." /> : (
          <div className="scroll-x">
            <table className="w-full min-w-[720px] text-sm">
              <thead><tr className="border-b border-line text-left text-xs text-muted">
                <th className="px-5 py-2 font-medium">Profissional</th><th className="font-medium">Modelo</th><th className="text-right font-medium">Horas</th>
                <th className="text-right font-medium">Valor</th><th className="px-3 font-medium">Vencimento</th><th className="px-5 font-medium">Situação</th>
              </tr></thead>
              <tbody className="tabular">
                {data.map((i) => (
                  <tr key={i.professional_id} onClick={() => setOpen(i.professional_id)} className="cursor-pointer border-b border-line last:border-0 hover:bg-sunk/60">
                    <td className="px-5 py-3"><p className="font-semibold">{i.name}</p><p className="text-xs text-muted">{i.specialty}</p></td>
                    <td>{BILLING_LABEL[i.billing_model]}</td>
                    <td className="text-right">{i.hours.toLocaleString("pt-BR")} h</td>
                    <td className="text-right font-bold">{brl(i.amount)}{i.adjustments_total ? <span className="block text-xs font-normal text-muted">ajuste {brl(i.adjustments_total)}</span> : null}</td>
                    <td className="px-3">{fmtDate(i.due_date)}</td>
                    <td className="px-5">{i.paid ? <Badge tone="ok"><CheckCircle2 className="h-3 w-3" />Pago</Badge> : i.overdue ? <Badge tone="bad"><AlertTriangle className="h-3 w-3" />Atrasado</Badge> : <Badge tone="warn">Em aberto</Badge>}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>
      <InvoiceSheet pid={open} month={month} onClose={() => setOpen(null)} />
    </>
  );
}

function Expenses({ month, scope }: { month: string; scope: "clinic" | "mine" }) {
  const qc = useQueryClient();
  const { data: cats } = useQuery({ queryKey: ["categories"], queryFn: () => get<{ clinic: string[]; mine: string[] }>("/finance/categories"), staleTime: Infinity });
  const { data, isLoading } = useQuery({ queryKey: ["expenses", month, scope], queryFn: () => get<Expense[]>(`/finance/expenses?month=${month}&scope=${scope}`) });
  const [form, setForm] = useState<any>(null);
  const save = useMutation({
    mutationFn: () => { const b = { ...form, scope, amount: Number(form.amount), repeat_months: Number(form.repeat_months || 1) };
      return form.id ? put(`/finance/expenses/${form.id}`, b) : post("/finance/expenses", b); },
    onSuccess: () => { invalidate(qc); toast("Despesa salva"); setForm(null); },
  });
  const remove = useMutation({ mutationFn: (s: string) => del(`/finance/expenses/${form.id}?scope=${s}`), onSuccess: () => { invalidate(qc); setForm(null); } });
  const togglePaid = useMutation({ mutationFn: (e: Expense) => put(`/finance/expenses/${e.id}`, { ...e, paid: !e.paid, scope }), onSuccess: () => invalidate(qc) });
  const total = data?.reduce((a, e) => a + e.amount, 0) ?? 0;
  const list = cats?.[scope] ?? [];
  return (
    <div className="grid gap-3">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <p className="text-sm text-muted">Total do mês: <b className="tabular text-ink">{brl(total)}</b> · a pagar: <b className="tabular text-ink">{brl(data?.filter((e) => !e.paid).reduce((a, e) => a + e.amount, 0) ?? 0)}</b></p>
        <Button variant="primary" onClick={() => setForm({ date: month === today().slice(0, 7) ? today() : `${month}-05`, description: "", category: list[0] ?? "Outros", amount: "", paid: true, repeat_months: 1 })}><Plus className="h-4 w-4" />Despesa</Button>
      </div>
      <Card className="p-0 sm:p-0">
        {isLoading ? <Spinner /> : !data?.length ? <Empty icon={<Wallet className="h-8 w-8" />} title="Nenhuma despesa no mês" text="Cadastre contas fixas com “repetir mensalmente”." /> : (
          <ul className="divide-y divide-line">
            {data.map((e) => (
              <li key={e.id} className="flex flex-wrap items-center gap-3 px-4 py-3 sm:px-5">
                <span className="tabular w-12 text-sm font-semibold">{fmtDate(e.date).slice(0, 5)}</span>
                <button className="min-w-0 flex-1 text-left" onClick={() => setForm({ ...e })}>
                  <span className="block truncate font-medium">{e.description}{e.series_id && <span className="ml-1 text-xs text-muted">(mensal)</span>}</span>
                  <span className="text-xs text-muted">{e.category}</span>
                </button>
                <span className="tabular font-semibold">{brl(e.amount)}</span>
                <button onClick={() => togglePaid.mutate(e)}><Badge tone={e.paid ? "ok" : "warn"}>{e.paid ? "Pago" : "A pagar"}</Badge></button>
              </li>
            ))}
          </ul>
        )}
      </Card>
      <Sheet open={!!form} onClose={() => setForm(null)} title={form?.id ? "Editar despesa" : "Nova despesa"}
        footer={form && <>
          {form.id && <Button variant="ghost" className="mr-auto text-bad" onClick={() => remove.mutate("one")}><Trash2 className="h-4 w-4" />Excluir</Button>}
          {form.id && form.series_id && <Button variant="danger" onClick={() => remove.mutate("future")}>Excluir esta e as próximas</Button>}
          <Button onClick={() => setForm(null)}>Cancelar</Button>
          <Button variant="primary" loading={save.isPending} disabled={!form.description || !form.amount} onClick={() => save.mutate()}>Salvar</Button></>}>
        {form && (
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Descrição" className="sm:col-span-2"><Input value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} /></Field>
            <Field label="Categoria"><Select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}>{list.map((c) => <option key={c}>{c}</option>)}</Select></Field>
            <Field label="Valor (R$)"><Input type="number" step="0.01" inputMode="decimal" value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} /></Field>
            <Field label="Data / vencimento"><Input type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} /></Field>
            {!form.id && <Field label="Repetir mensalmente"><Select value={form.repeat_months} onChange={(e) => setForm({ ...form, repeat_months: e.target.value })}>
              {[1, 3, 6, 12, 24].map((n) => <option key={n} value={n}>{n === 1 ? "Não repetir" : `${n} meses`}</option>)}</Select></Field>}
            <div className="sm:col-span-2"><Toggle checked={form.paid} onChange={(v) => setForm({ ...form, paid: v })} label="Pago" /></div>
            <div className="sm:col-span-2"><ErrorBox error={save.error || remove.error} /></div>
          </div>
        )}
      </Sheet>
    </div>
  );
}

/* ---------- profissional ---------- */

function Statement({ month, professionalId, view }: { month: string; professionalId?: number; view: string }) {
  const qc = useQueryClient();
  const q = professionalId ? `&professional_id=${professionalId}` : "";
  const { data, isLoading } = useQuery({ queryKey: ["statement", month, professionalId], queryFn: () => get<any>(`/finance/statement?month=${month}${q}`) });
  const pkgs = useQuery({ queryKey: ["packages", "pro", professionalId], enabled: view === "packages", queryFn: () => get<SessionPackage[]>(`/packages${professionalId ? `?professional_id=${professionalId}` : ""}`) });
  const [rentOpen, setRentOpen] = useState(false);
  const pay = useMutation({
    mutationFn: ({ id, paid, method }: { id: number; paid: boolean; method?: string }) => patch(`/appointments/${id}`, { paid, payment_method: method ?? null }),
    onSuccess: () => invalidate(qc),
  });
  if (isLoading || !data) return <Spinner />;
  if (view === "summary") return (
    <div className="grid gap-4">
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-5">
        <Stat label="Recebido" value={brl(data.received)} tone="ok" hint={`${data.appointments} atendimentos · ${data.no_shows} faltas`} />
        <Stat label="A receber (mês)" value={brl(data.pending)} />
        <Stat label="Aluguel de sala" value={`− ${brl(data.room_cost)}`} hint={data.room_cost_paid ? "pago à clínica" : data.room_overdue ? "em atraso" : `vence ${fmtDate(data.room_due_date)}`} tone={data.room_cost_paid ? "ok" : data.room_overdue ? "bad" : "warn"} />
        <Stat label="Outras despesas" value={`− ${brl(data.expenses)}`} />
        <Stat label="Líquido" value={brl(data.net)} tone={data.net < 0 ? "bad" : undefined} />
      </div>
      <div className="grid gap-4 lg:grid-cols-[1.5fr_1fr]">
        <Card title="Últimos 6 meses"><MonthBars inLabel="Recebido" outLabel="Aluguel + despesas" data={data.series.map((m: any) => ({ month: m.month, in: m.received, out: m.room_cost + m.expenses }))} /></Card>
        <Card title="Recebido por forma de pagamento">
          {!Object.keys(data.by_method).length ? <Empty title="Nada recebido no mês" /> : (
            <ul className="divide-y divide-line">{Object.entries(data.by_method).map(([m, v]) => (
              <li key={m} className="flex justify-between py-2 text-sm"><span className="capitalize">{m}</span><b className="tabular">{brl(v as number)}</b></li>))}</ul>
          )}
          <Button className="mt-3 w-full" onClick={() => setRentOpen(true)}>Ver fatura do aluguel</Button>
        </Card>
      </div>
      <InvoiceSheet pid={rentOpen ? data.professional_id : null} month={month} onClose={() => setRentOpen(false)} />
    </div>
  );
  if (view === "items") return (
    <Card title="Atendimentos do mês" className="p-0 sm:p-0">
      {!data.items.length ? <Empty title="Sem consultas neste mês" /> : (
        <ul className="divide-y divide-line">
          {data.items.map((i: any) => (
            <li key={i.id} className="flex flex-wrap items-center gap-x-3 gap-y-2 px-4 py-3 sm:px-5">
              <span className="tabular w-24 text-sm font-semibold">{fmtDate(i.date).slice(0, 5)} {i.start}</span>
              <span className="min-w-0 flex-1 truncate">{i.patient_name}</span>
              <Badge tone={STATUS[i.status as keyof typeof STATUS].tone}>{STATUS[i.status as keyof typeof STATUS].label}</Badge>
              <span className="tabular w-24 text-right font-semibold">{i.package_id ? <span className="text-xs font-medium text-muted">pacote</span> : brl(i.price)}</span>
              {i.package_id ? <span className="w-40 text-right text-xs text-muted">pago no pacote</span> : ["scheduled", "confirmed", "done"].includes(i.status) && (i.paid ? (
                <span className="flex w-40 items-center justify-end gap-2">
                  <a href={`/api/finance/receipt/appointment/${i.id}.pdf`} target="_blank" rel="noopener" className="text-xs font-semibold text-brand">Recibo</a>
                  <button onClick={() => pay.mutate({ id: i.id, paid: false })} className="inline-flex items-center gap-1 text-xs font-semibold text-ok"><CheckCircle2 className="h-4 w-4" />{i.payment_method ?? "pago"}</button>
                </span>
              ) : (
                <Select className="h-9 w-40 text-sm" value="" onChange={(e) => e.target.value && pay.mutate({ id: i.id, paid: true, method: e.target.value })}>
                  <option value="">Receber…</option>{PAYMENT_METHODS.map((m) => <option key={m} value={m}>{m}</option>)}
                </Select>
              ))}
            </li>
          ))}
        </ul>
      )}
    </Card>
  );
  if (view === "receivables") return (
    <Card title="A receber por paciente (até hoje)" className="p-0 sm:p-0">
      {!data.debtors.length ? <Empty title="Nenhum valor em aberto" /> : (
        <ul className="divide-y divide-line">
          {data.debtors.map((d: any) => (
            <li key={d.patient_id} className="flex flex-wrap items-center gap-3 px-4 py-3 sm:px-5">
              <span className="min-w-0 flex-1"><span className="block truncate font-semibold">{d.name}</span><span className="text-xs text-muted">{d.count} atendimento(s) desde {fmtDate(d.oldest)}</span></span>
              <b className="tabular">{brl(d.total)}</b>
            </li>
          ))}
        </ul>
      )}
      <p className="px-5 pb-4 text-xs text-muted">Para cobrar pelo WhatsApp, use Comunicação → Cobranças.</p>
    </Card>
  );
  if (view === "packages") return (
    <Card title="Pacotes de sessões" className="p-0 sm:p-0">
      {pkgs.isLoading ? <Spinner /> : !pkgs.data?.length ? <Empty icon={<Package className="h-8 w-8" />} title="Nenhum pacote" text="Crie pacotes na ficha do paciente, aba Pacotes." /> : (
        <ul className="divide-y divide-line">
          {pkgs.data.map((k) => (
            <li key={k.id} className="flex flex-wrap items-center gap-3 px-4 py-3 sm:px-5">
              <span className="min-w-0 flex-1"><a href={`/pacientes/${k.patient_id}`} className="block truncate font-semibold hover:text-brand">{k.name}</a>
                <span className="text-xs text-muted">usadas {k.used}/{k.sessions_total} · {brl(k.price)}</span></span>
              <Badge tone={k.paid ? "ok" : "warn"}>{k.paid ? "Pago" : "A receber"}</Badge>
              {k.paid && <a href={`/api/finance/receipt/package/${k.id}.pdf`} target="_blank" rel="noopener" className="text-xs font-semibold text-brand">Recibo</a>}
            </li>
          ))}
        </ul>
      )}
    </Card>
  );
  return null;
}

export function FinancePage() {
  const { isAdmin, professionalId } = useMe();
  const { data: pros } = useProfessionals();
  const [month, setMonth] = useState(monthNow());
  const [tab, setTab] = useState<string>(isAdmin ? "overview" : "summary");
  const attending = pros?.filter((p) => p.attends) ?? [];
  const [prof, setProf] = useState<number | undefined>(undefined);
  const selected = isAdmin ? prof ?? attending[0]?.id : professionalId ?? undefined;
  const adminTabs: [string, string][] = [["overview", "Visão geral"], ["invoices", "Faturas"], ["expenses", "Despesas"], ["prof", "Por profissional"]];
  const proTabs: [string, string][] = [["summary", "Resumo"], ["items", "Atendimentos"], ["packages", "Pacotes"], ["receivables", "A receber"], ["expenses-mine", "Minhas despesas"]];
  const [proView, setProView] = useState("summary");
  const csv = isAdmin && tab !== "prof" ? `/api/finance/export.csv?month=${month}` : `/api/finance/statement.csv?month=${month}${isAdmin && selected ? `&professional_id=${selected}` : ""}`;
  return (
    <div className="grid gap-4">
      <PageHeader title="Financeiro" subtitle={isAdmin ? "Aluguel das salas, despesas e caixa dos profissionais" : "Seus recebimentos, pacotes, aluguel e despesas"}
        actions={<><MonthNav month={month} setMonth={setMonth} /><a href={csv}><Button><Download className="h-4 w-4" />CSV</Button></a></>} />
      <div className="scroll-x -mx-4 flex items-center gap-2 px-4 sm:mx-0 sm:px-0">
        <Segmented value={isAdmin ? tab : proView} onChange={(v) => (isAdmin ? setTab(v) : setProView(v))} options={isAdmin ? adminTabs : proTabs} />
      </div>
      {isAdmin && tab === "overview" && <Overview month={month} />}
      {isAdmin && tab === "invoices" && <Invoices month={month} />}
      {isAdmin && tab === "expenses" && <Expenses month={month} scope="clinic" />}
      {isAdmin && tab === "prof" && (
        <div className="grid gap-4">
          <div className="flex flex-wrap gap-2">
            <Select className="h-10 w-auto" value={selected ?? ""} onChange={(e) => setProf(Number(e.target.value))}>{attending.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}</Select>
            <Segmented value={proView} onChange={setProView} options={proTabs.filter(([k]) => k !== "expenses-mine")} />
          </div>
          {selected && <Statement month={month} professionalId={selected} view={proView} />}
        </div>
      )}
      {!isAdmin && (proView === "expenses-mine" ? <Expenses month={month} scope="mine" /> : <Statement month={month} view={proView} />)}
    </div>
  );
}
