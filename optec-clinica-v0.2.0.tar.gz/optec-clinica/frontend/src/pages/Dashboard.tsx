import { useQuery } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { Cake, CalendarClock, DoorOpen, ListTodo, MessageCircle, RefreshCw, Video } from "lucide-react";
import { get } from "../lib/api";
import { useMe } from "../lib/auth";
import { STATUS, brl, fmtDate, fmtDayLong, pct, today } from "../lib/format";
import type { Appointment } from "../lib/types";
import { Badge, Card, Empty, PageHeader, Spinner, Stat } from "../components/ui";

interface Dash {
  today: Appointment[]; today_confirmed: number; occupancy_today?: number;
  rooms?: { room_id: number; name: string; occupancy: number; revenue: number }[];
  professionals?: number; patients?: number; invoiced_month?: number; open_month?: number; open_count?: number;
  my_month?: { appointments: number; received: number; pending: number; patients: number };
  my_rooms?: { date: string; start: string; end: string; room: string }[];
  reminders_pending: number; reschedule_requests: Appointment[]; birthdays_today: { id: number; name: string }[]; waitlist: number;
}

export function DashboardPage() {
  const { user, isStaff, isAdmin } = useMe();
  const { data, isLoading } = useQuery({ queryKey: ["dashboard"], queryFn: () => get<Dash>("/dashboard"), refetchInterval: 60_000 });
  const hour = new Date().getHours();
  const greet = hour < 12 ? "Bom dia" : hour < 18 ? "Boa tarde" : "Boa noite";
  if (isLoading || !data) return <Spinner />;
  return (
    <div className="grid gap-5">
      <PageHeader title={`${greet}, ${user.name.split(" ")[0]}`} subtitle={fmtDayLong(today())} />

      {(data.reminders_pending > 0 || data.reschedule_requests.length > 0 || data.birthdays_today.length > 0 || data.waitlist > 0) && (
        <div className="flex flex-wrap gap-2">
          {data.reminders_pending > 0 && <Link to="/comunicacao" className="inline-flex items-center gap-2 rounded-xl border border-line bg-surface px-3 py-2 text-sm font-medium shadow-card hover:border-brand/50"><MessageCircle className="h-4 w-4 text-brand" />{data.reminders_pending} lembrete(s) de amanhã para enviar</Link>}
          {data.reschedule_requests.length > 0 && <Link to="/comunicacao" className="inline-flex items-center gap-2 rounded-xl border border-warn/40 bg-warn-soft px-3 py-2 text-sm font-medium text-warn"><RefreshCw className="h-4 w-4" />{data.reschedule_requests.length} pedido(s) de remarcação</Link>}
          {data.birthdays_today.length > 0 && <Link to="/comunicacao" className="inline-flex items-center gap-2 rounded-xl border border-line bg-surface px-3 py-2 text-sm font-medium shadow-card"><Cake className="h-4 w-4 text-brand" />Aniversário hoje: {data.birthdays_today.map((b) => b.name.split(" ")[0]).join(", ")}</Link>}
          {data.waitlist > 0 && <Link to="/espera" className="inline-flex items-center gap-2 rounded-xl border border-line bg-surface px-3 py-2 text-sm font-medium shadow-card"><ListTodo className="h-4 w-4 text-brand" />{data.waitlist} na lista de espera</Link>}
        </div>
      )}
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {isStaff && <Stat label="Ocupação das salas hoje" value={pct(data.occupancy_today ?? 0)} hint={`${data.rooms?.length ?? 0} salas ativas`} />}
        <Stat label="Consultas hoje" value={data.today.length} hint={`${data.today_confirmed} confirmadas`} tone="ok" />
        {isAdmin && <Stat label="Aluguel do mês" value={brl(data.invoiced_month)} hint="faturado para os profissionais" />}
        {isAdmin && <Stat label="Em aberto" value={brl(data.open_month)} hint={`${data.open_count} profissionais`} tone={data.open_count ? "bad" : undefined} />}
        {data.my_month && !isAdmin && <>
          <Stat label="Recebido no mês" value={brl(data.my_month.received)} tone="ok" hint={`${data.my_month.appointments} atendimentos`} />
          <Stat label="A receber" value={brl(data.my_month.pending)} />
          <Stat label="Meus pacientes" value={data.my_month.patients} />
        </>}
        {user.role === "reception" && <><Stat label="Profissionais" value={data.professionals} /><Stat label="Pacientes ativos" value={data.patients} /></>}
      </div>

      <div className="grid gap-4 lg:grid-cols-[1.4fr_1fr]">
        <Card title="Consultas de hoje" action={<Link to="/agenda" className="text-sm font-semibold text-brand">Ver agenda</Link>}>
          {data.today.length === 0 ? (
            <Empty icon={<CalendarClock className="h-8 w-8" />} title="Nenhuma consulta hoje" text="As consultas marcadas para hoje aparecem aqui." />
          ) : (
            <ul className="divide-y divide-line">
              {data.today.map((a) => (
                <li key={a.id} className="flex items-center gap-3 py-2.5">
                  <span className="tabular w-12 text-sm font-bold">{a.start}</span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate font-medium">{a.patient_name}</p>
                    <p className="flex items-center gap-1 text-xs text-muted">{a.online && <Video className="h-3 w-3" />}{a.online ? "Online" : "Presencial"} · {brl(a.price)}</p>
                  </div>
                  <Badge tone={STATUS[a.status].tone}>{STATUS[a.status].label}</Badge>
                </li>
              ))}
            </ul>
          )}
        </Card>

        {isStaff && data.rooms && (
          <Card title="Ocupação das salas no mês" action={<Link to="/salas" className="text-sm font-semibold text-brand">Ver salas</Link>}>
            <div className="grid gap-3">
              {data.rooms.map((r) => (
                <div key={r.room_id} className="grid grid-cols-[90px_1fr_44px] items-center gap-3 text-sm">
                  <span className="truncate font-medium">{r.name}</span>
                  <div className="h-2.5 overflow-hidden rounded-full bg-sunk"><div className="h-full rounded-full brand-gradient" style={{ width: `${Math.min(100, r.occupancy * 100)}%` }} /></div>
                  <span className="tabular text-right font-semibold">{pct(r.occupancy)}</span>
                </div>
              ))}
              {data.rooms.length === 0 && <Empty icon={<DoorOpen className="h-8 w-8" />} title="Nenhuma sala ativa" text="Cadastre salas em Configurações." />}
            </div>
          </Card>
        )}
        {!isStaff && (
          <Card title="Minhas salas nos próximos 7 dias">
            {data.my_rooms?.length ? (
              <ul className="divide-y divide-line">
                {data.my_rooms.map((r, i) => (
                  <li key={i} className="flex items-center justify-between py-2.5 text-sm">
                    <span><b>{fmtDate(r.date).slice(0, 5)}</b> · {r.start}–{r.end}</span><Badge tone="brand">{r.room}</Badge>
                  </li>
                ))}
              </ul>
            ) : <Empty icon={<DoorOpen className="h-8 w-8" />} title="Sem reservas" text="Reserve uma sala na tela Salas." />}
          </Card>
        )}
      </div>

    </div>
  );
}
