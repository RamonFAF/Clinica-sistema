import { useEffect, useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { CheckCheck, ChevronLeft, ChevronRight, MessageCircle, Plus, RefreshCw, Video } from "lucide-react";
import { get } from "../lib/api";
import { useMe } from "../lib/auth";
import { STATUS, WEEKDAYS, addDays, fmtDate, fmtDayLong, mondayOf, parseISO, toHHMM, toMin, today } from "../lib/format";
import { useProfessionals, useSettings } from "../lib/queries";
import type { Appointment, Reservation } from "../lib/types";
import { AppointmentSheet, type Draft } from "../components/AppointmentSheet";
import { Badge, Button, Card, Empty, PageHeader, Segmented, Select, Spinner, cx } from "../components/ui";

const SLOT_PX = 26;
const tone: Record<string, string> = {
  scheduled: "bg-warn-soft border-warn text-ink", confirmed: "bg-ok-soft border-ok text-ink", done: "bg-info-soft border-info text-ink",
  no_show: "bg-bad-soft border-bad text-ink", canceled: "bg-sunk border-line text-muted line-through",
};

function useIsMobile() {
  const [m, setM] = useState(() => window.matchMedia("(max-width: 767px)").matches);
  useEffect(() => {
    const mq = window.matchMedia("(max-width: 767px)");
    const fn = () => setM(mq.matches);
    mq.addEventListener("change", fn);
    return () => mq.removeEventListener("change", fn);
  }, []);
  return m;
}

export function AgendaPage() {
  const { isStaff, professionalId } = useMe();
  const mobile = useIsMobile();
  const { data: settings } = useSettings();
  const { data: pros } = useProfessionals();
  const attending = (pros ?? []).filter((p) => p.attends && p.is_active);
  const [prof, setProf] = useState<number | null>(isStaff ? null : professionalId);
  const [day, setDay] = useState(today());
  const [view, setView] = useState<"week" | "day">(mobile ? "day" : "week");
  const [draft, setDraft] = useState<Draft | null>(null);
  useEffect(() => { if (prof == null && attending.length) setProf(attending[0].id); }, [prof, attending]);
  useEffect(() => { if (mobile) setView("day"); }, [mobile]);

  const week = mondayOf(day);
  const days = useMemo(() => {
    const open = settings?.open_weekdays ?? [0, 1, 2, 3, 4, 5];
    return open.slice().sort().map((d) => addDays(week, d));
  }, [week, settings]);
  const from = view === "week" ? week : day, to = view === "week" ? addDays(week, 6) : day;
  const appts = useQuery({ queryKey: ["appointments", prof, from, to], enabled: !!prof,
    queryFn: () => get<Appointment[]>(`/appointments?date_from=${from}&date_to=${to}&professional_id=${prof}`) });
  const res = useQuery({ queryKey: ["reservations", "prof", prof, from, to], enabled: !!prof,
    queryFn: () => get<Reservation[]>(`/reservations?date_from=${from}&date_to=${to}&professional_id=${prof}`) });

  if (!settings) return <Spinner />;
  const open = toMin(settings.open_time), close = toMin(settings.close_time), slot = settings.slot_minutes;
  const slots = Array.from({ length: Math.ceil((close - open) / slot) }, (_, i) => open + i * slot);
  const shown = view === "week" ? days : [day];
  const newAt = (d: string, start: string) => prof && setDraft({ date: d, start, professional_id: prof });
  const step = view === "week" ? 7 : 1;

  return (
    <div className="grid gap-4">
      <PageHeader title="Agenda" subtitle={view === "week" ? `Semana de ${fmtDate(week)}` : fmtDayLong(day)}
        actions={<>
          {isStaff && <Select className="h-10 w-auto min-w-[200px]" value={prof ?? ""} onChange={(e) => setProf(Number(e.target.value))}>
            {attending.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
          </Select>}
          {!mobile && <Segmented value={view} onChange={setView} options={[["week", "Semana"], ["day", "Dia"]]} />}
          <div className="flex items-center gap-1">
            <Button size="md" variant="secondary" aria-label="Anterior" onClick={() => setDay(addDays(day, -step))}><ChevronLeft className="h-4 w-4" /></Button>
            <Button size="md" onClick={() => setDay(today())}>Hoje</Button>
            <Button size="md" variant="secondary" aria-label="Próximo" onClick={() => setDay(addDays(day, step))}><ChevronRight className="h-4 w-4" /></Button>
          </div>
          <Button variant="primary" onClick={() => newAt(day, settings.open_time)}><Plus className="h-4 w-4" />Consulta</Button>
        </>} />

      {view === "day" && (
        <div className="scroll-x -mx-4 flex gap-2 px-4 pb-1 sm:mx-0 sm:px-0">
          {days.map((d) => {
            const dt = parseISO(d);
            return (
              <button key={d} onClick={() => setDay(d)}
                className={cx("grid min-w-[56px] justify-items-center rounded-2xl border px-3 py-2 transition", d === day ? "brand-gradient border-transparent text-white shadow" : "border-line bg-surface")}>
                <span className="text-[11px] font-semibold uppercase opacity-80">{WEEKDAYS[(dt.getDay() + 6) % 7]}</span>
                <span className="text-lg font-bold">{dt.getDate()}</span>
                {d === today() && d !== day && <span className="h-1 w-1 rounded-full bg-brand" />}
              </button>
            );
          })}
        </div>
      )}

      <div className="flex flex-wrap gap-2 text-xs">
        <span className="inline-flex items-center gap-1.5 text-muted"><span className="h-3 w-3 rounded bg-brand-soft ring-1 ring-brand/30" />Sala reservada</span>
        {Object.entries(STATUS).map(([k, v]) => <Badge key={k} tone={v.tone}>{v.label}</Badge>)}
        <span className="inline-flex items-center gap-1 text-muted"><MessageCircle className="h-3.5 w-3.5" />lembrete enviado</span>
        <span className="inline-flex items-center gap-1 text-muted"><CheckCheck className="h-3.5 w-3.5 text-ok" />confirmou pelo link</span>
        <span className="inline-flex items-center gap-1 text-muted"><RefreshCw className="h-3.5 w-3.5 text-warn" />pediu remarcação</span>
      </div>

      {view === "day" && mobile ? (
        <Card className="p-0 sm:p-0">
          {appts.isLoading ? <Spinner /> : (
            <ul className="divide-y divide-line">
              {(() => {
                const list = (appts.data ?? []).filter((a) => a.date === day);
                const rs = (res.data ?? []).filter((r) => r.date === day);
                if (!list.length && !rs.length) return <Empty title="Dia livre" text="Sem sala reservada e sem consultas neste dia." />;
                return <>
                  {rs.map((r) => <li key={"r" + r.id} className="bg-brand-soft/50 px-4 py-2 text-xs font-semibold text-brand">Sala reservada {r.start}–{r.end}</li>)}
                  {list.map((a) => (
                    <li key={a.id}>
                      <button onClick={() => setDraft({ id: a.id, date: a.date, start: a.start, professional_id: a.professional_id })} className="flex w-full items-center gap-3 px-4 py-3 text-left">
                        <span className="tabular w-12 font-bold">{a.start}</span>
                        <span className="min-w-0 flex-1"><span className="block truncate font-medium">{a.patient_name}</span>
                          <span className="flex items-center gap-1 text-xs text-muted">{a.online && <Video className="h-3 w-3" />}até {a.end}{a.paid && " · pago"}
                            {a.patient_response === "reschedule" ? <><RefreshCw className="h-3 w-3 text-warn" />pediu remarcação</> : a.patient_response === "confirmed" ? <><CheckCheck className="h-3 w-3 text-ok" />confirmou</> : a.reminder_sent_at ? <><MessageCircle className="h-3 w-3" />lembrete enviado</> : null}</span></span>
                        <Badge tone={STATUS[a.status].tone}>{STATUS[a.status].label}</Badge>
                      </button>
                    </li>
                  ))}
                </>;
              })()}
            </ul>
          )}
        </Card>
      ) : (
        <div className="scroll-x rounded-2xl border border-line bg-surface shadow-card">
          <div className="grid min-w-[640px]" style={{ gridTemplateColumns: `56px repeat(${shown.length}, minmax(120px, 1fr))` }}>
            <div className="sticky top-0 z-10 border-b border-line bg-surface" />
            {shown.map((d) => {
              const dt = parseISO(d);
              return (
                <div key={d} className={cx("sticky top-0 z-10 border-b border-l border-line bg-surface px-2 py-2 text-center", d === today() && "text-brand")}>
                  <span className="text-xs font-semibold uppercase text-muted">{WEEKDAYS[(dt.getDay() + 6) % 7]}</span>{" "}
                  <span className="font-bold">{dt.getDate()}/{dt.getMonth() + 1}</span>
                </div>
              );
            })}
            <div className="relative">
              {slots.map((m, i) => (
                <div key={m} className="pr-2 text-right text-[11px] text-muted tabular" style={{ height: SLOT_PX }}>{i % Math.max(1, Math.round(60 / slot)) === 0 ? toHHMM(m) : ""}</div>
              ))}
            </div>
            {shown.map((d) => (
              <div key={d} className="relative border-l border-line">
                {slots.map((m) => (
                  <button key={m} aria-label={`Marcar ${fmtDate(d)} ${toHHMM(m)}`} onClick={() => newAt(d, toHHMM(m))}
                    className={cx("block w-full border-t border-line/60 hover:bg-brand-soft/60", (m - open) % 60 === 0 && "border-line")} style={{ height: SLOT_PX }} />
                ))}
                {(res.data ?? []).filter((r) => r.date === d).map((r) => (
                  <div key={r.id} className="pointer-events-none absolute inset-x-0.5 rounded-md bg-brand-soft/70"
                    style={{ top: ((toMin(r.start) - open) / slot) * SLOT_PX, height: ((toMin(r.end) - toMin(r.start)) / slot) * SLOT_PX }} />
                ))}
                {(appts.data ?? []).filter((a) => a.date === d).map((a) => (
                  <button key={a.id} onClick={() => setDraft({ id: a.id, date: a.date, start: a.start, professional_id: a.professional_id })}
                    className={cx("absolute inset-x-1 overflow-hidden rounded-lg border-l-4 px-2 py-1 text-left text-xs shadow-sm", tone[a.status])}
                    style={{ top: ((toMin(a.start) - open) / slot) * SLOT_PX + 1, height: Math.max(SLOT_PX, ((toMin(a.end) - toMin(a.start)) / slot) * SLOT_PX) - 2 }}>
                    <span className="block truncate font-semibold">{a.patient_name}</span>
                    <span className="flex items-center gap-1 text-[11px] text-muted">{a.online && <Video className="h-3 w-3" />}{a.start}–{a.end}{a.paid ? " · pago" : ""}
                      {a.patient_response === "reschedule" ? <RefreshCw className="h-3 w-3 text-warn" /> : a.patient_response === "confirmed" ? <CheckCheck className="h-3 w-3 text-ok" /> : a.reminder_sent_at ? <MessageCircle className="h-3 w-3" /> : null}</span>
                  </button>
                ))}
              </div>
            ))}
          </div>
        </div>
      )}
      <AppointmentSheet draft={draft} onClose={() => setDraft(null)} />
    </div>
  );
}
