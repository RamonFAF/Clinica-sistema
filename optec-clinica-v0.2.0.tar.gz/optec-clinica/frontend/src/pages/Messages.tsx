import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Cake, CheckCheck, Copy, MessageCircle, RefreshCw, Send, Wallet } from "lucide-react";
import { get } from "../lib/api";
import { useMe } from "../lib/auth";
import { addDays, brl, fmtDate, fmtDayLong, monthNow, today, whatsappLink } from "../lib/format";
import { useProfessionals, useSettings } from "../lib/queries";
import type { Appointment } from "../lib/types";
import { birthdayText, chargeText, markReminderSent, reminderLink, reminderText } from "../lib/whatsapp";
import { Badge, Button, Card, Empty, Input, PageHeader, Segmented, Select, Spinner, cx, toast } from "../components/ui";

function copy(text: string) {
  navigator.clipboard?.writeText(text).then(() => toast("Mensagem copiada")).catch(() => toast("Não foi possível copiar", "bad"));
}

function Reminders() {
  const qc = useQueryClient();
  const { isStaff } = useMe();
  const { data: s } = useSettings();
  const { data: pros } = useProfessionals();
  const [day, setDay] = useState(addDays(today(), 1));
  const [prof, setProf] = useState("");
  const { data, isLoading } = useQuery({ queryKey: ["appointments", "reminders", day, prof],
    queryFn: () => get<Appointment[]>(`/appointments?date_from=${day}&date_to=${day}${prof ? `&professional_id=${prof}` : ""}`) });
  const sent = useMutation({ mutationFn: markReminderSent, onSuccess: () => qc.invalidateQueries({ queryKey: ["appointments"] }) });
  const list = (data ?? []).filter((a) => ["scheduled", "confirmed"].includes(a.status));
  const pending = list.filter((a) => !a.reminder_sent_at).length;
  const profName = (id: number) => pros?.find((p) => p.id === id)?.name ?? "";
  return (
    <div className="grid gap-3">
      <div className="flex flex-wrap items-center gap-2">
        <Input type="date" className="h-10 w-auto" value={day} onChange={(e) => e.target.value && setDay(e.target.value)} />
        <Button size="md" onClick={() => setDay(addDays(today(), 1))}>Amanhã</Button>
        {isStaff && <Select className="h-10 w-auto" value={prof} onChange={(e) => setProf(e.target.value)}>
          <option value="">Todos os profissionais</option>{pros?.filter((p) => p.attends).map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}</Select>}
        <span className="text-sm text-muted">{fmtDayLong(day)} · {list.length} consultas · {pending} sem lembrete</span>
      </div>
      <p className="rounded-xl bg-info-soft px-3 py-2 text-sm text-info">Toque em <b>Enviar</b>: o WhatsApp abre com a mensagem pronta e o link para o paciente confirmar ou pedir remarcação. A resposta aparece aqui e na agenda.</p>
      <Card className="p-0 sm:p-0">
        {isLoading || !s ? <Spinner /> : !list.length ? <Empty icon={<MessageCircle className="h-8 w-8" />} title="Nenhuma consulta neste dia" /> : (
          <ul className="divide-y divide-line">
            {list.map((a) => {
              const can = a.consent_whatsapp && a.patient_phone;
              return (
                <li key={a.id} className="flex flex-wrap items-center gap-3 px-4 py-3 sm:px-5">
                  <span className="tabular w-12 font-bold">{a.start}</span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate font-semibold">{a.patient_name}</p>
                    <p className="truncate text-xs text-muted">{profName(a.professional_id)} · {a.patient_phone || "sem telefone"}</p>
                  </div>
                  {a.patient_response === "confirmed" || a.status === "confirmed" ? <Badge tone="ok"><CheckCheck className="h-3 w-3" />Confirmou</Badge>
                    : a.patient_response === "reschedule" ? <Badge tone="warn"><RefreshCw className="h-3 w-3" />Pediu remarcação</Badge>
                    : a.reminder_sent_at ? <Badge tone="info">Lembrete enviado</Badge> : <Badge>Sem lembrete</Badge>}
                  {can ? (
                    <div className="flex gap-1.5">
                      <Button size="sm" variant="ghost" aria-label="Copiar mensagem" onClick={() => copy(reminderText(s, a, profName(a.professional_id)))}><Copy className="h-4 w-4" /></Button>
                      <a href={reminderLink(s, a, profName(a.professional_id))} target="_blank" rel="noopener noreferrer" onClick={() => sent.mutate(a.id)}
                        className="inline-flex h-8 items-center gap-1.5 rounded-xl bg-[#1f9e5a] px-3 text-[13px] font-semibold text-white">
                        <Send className="h-4 w-4" />{a.reminder_sent_at ? "Reenviar" : "Enviar"}</a>
                    </div>
                  ) : <span className="text-xs text-muted">{a.patient_phone ? "sem consentimento" : "sem telefone"}</span>}
                </li>
              );
            })}
          </ul>
        )}
      </Card>
    </div>
  );
}

function RescheduleRequests() {
  const { data: pros } = useProfessionals();
  const { data, isLoading } = useQuery({ queryKey: ["dashboard"], queryFn: () => get<{ reschedule_requests: Appointment[] }>("/dashboard") });
  const list = data?.reschedule_requests ?? [];
  return (
    <Card className="p-0 sm:p-0">
      {isLoading ? <Spinner /> : !list.length ? <Empty icon={<RefreshCw className="h-8 w-8" />} title="Nenhum pedido de remarcação" text="Quando o paciente toca em “Preciso remarcar” no link, o pedido aparece aqui." /> : (
        <ul className="divide-y divide-line">
          {list.map((a) => (
            <li key={a.id} className="flex flex-wrap items-center gap-3 px-4 py-3 sm:px-5">
              <span className="tabular w-28 text-sm font-semibold">{fmtDate(a.date)} {a.start}</span>
              <span className="min-w-0 flex-1 truncate">{a.patient_name} <span className="text-xs text-muted">· {pros?.find((p) => p.id === a.professional_id)?.name}</span></span>
              <a href={whatsappLink(a.patient_phone, `Olá, ${a.patient_name.split(" ")[0]}! Vi seu pedido para remarcar a consulta de ${fmtDate(a.date)} às ${a.start}. Qual dia e horário ficam melhores para você?`)}
                target="_blank" rel="noopener noreferrer" className="inline-flex h-8 items-center gap-1.5 rounded-xl bg-[#1f9e5a] px-3 text-[13px] font-semibold text-white"><MessageCircle className="h-4 w-4" />Conversar</a>
            </li>
          ))}
        </ul>
      )}
    </Card>
  );
}

function Birthdays() {
  const { data: s } = useSettings();
  const [month, setMonth] = useState(new Date().getMonth() + 1);
  const { data, isLoading } = useQuery({ queryKey: ["birthdays", month], queryFn: () => get<{ id: number; name: string; phone: string | null; birth_date: string; consent_whatsapp: boolean; turns: number }[]>(`/patients/birthdays?month=${month}`) });
  const todayMD = today().slice(5);
  return (
    <div className="grid gap-3">
      <Select className="h-10 w-auto justify-self-start" value={month} onChange={(e) => setMonth(Number(e.target.value))}>
        {["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"].map((m, i) => <option key={m} value={i + 1}>{m}</option>)}
      </Select>
      <Card className="p-0 sm:p-0">
        {isLoading || !s ? <Spinner /> : !data?.length ? <Empty icon={<Cake className="h-8 w-8" />} title="Nenhum aniversariante" /> : (
          <ul className="divide-y divide-line">
            {data.map((b) => (
              <li key={b.id} className={cx("flex flex-wrap items-center gap-3 px-4 py-3 sm:px-5", b.birth_date.slice(5) === todayMD && "bg-brand-soft/50")}>
                <span className="tabular w-14 font-bold">{b.birth_date.slice(8)}/{b.birth_date.slice(5, 7)}</span>
                <span className="min-w-0 flex-1 truncate">{b.name} <span className="text-xs text-muted">· {b.turns} anos</span></span>
                {b.birth_date.slice(5) === todayMD && <Badge tone="brand"><Cake className="h-3 w-3" />Hoje</Badge>}
                {b.consent_whatsapp && b.phone && <a href={whatsappLink(b.phone, birthdayText(s, b.name))} target="_blank" rel="noopener noreferrer"
                  className="inline-flex h-8 items-center gap-1.5 rounded-xl bg-[#1f9e5a] px-3 text-[13px] font-semibold text-white"><Send className="h-4 w-4" />Parabenizar</a>}
              </li>
            ))}
          </ul>
        )}
      </Card>
    </div>
  );
}

function Charges() {
  const { user } = useMe();
  const { data: s } = useSettings();
  const { data, isLoading } = useQuery({ queryKey: ["statement", monthNow(), undefined], queryFn: () => get<any>(`/finance/statement?month=${monthNow()}`) });
  const list: any[] = data?.debtors ?? [];
  return (
    <Card className="p-0 sm:p-0">
      {isLoading || !s ? <Spinner /> : !list.length ? <Empty icon={<Wallet className="h-8 w-8" />} title="Ninguém em aberto" text="Consultas confirmadas ou realizadas e não pagas aparecem aqui." /> : (
        <ul className="divide-y divide-line">
          {list.map((d) => (
            <li key={d.patient_id} className="flex flex-wrap items-center gap-3 px-4 py-3 sm:px-5">
              <span className="min-w-0 flex-1"><span className="block truncate font-semibold">{d.name}</span>
                <span className="text-xs text-muted">{d.count} atendimento(s) desde {fmtDate(d.oldest)}</span></span>
              <span className="tabular font-bold">{brl(d.total)}</span>
              {d.consent_whatsapp && d.phone && <a href={whatsappLink(d.phone, chargeText(s, d.name, d.total, `${d.count} atendimento(s) desde ${fmtDate(d.oldest)}`, user.name))}
                target="_blank" rel="noopener noreferrer" className="inline-flex h-8 items-center gap-1.5 rounded-xl bg-[#1f9e5a] px-3 text-[13px] font-semibold text-white"><Send className="h-4 w-4" />Cobrar</a>}
            </li>
          ))}
        </ul>
      )}
    </Card>
  );
}

export function MessagesPage() {
  const { professionalId, user } = useMe();
  const [tab, setTab] = useState<"reminders" | "reschedule" | "birthdays" | "charges">("reminders");
  const opts: ["reminders" | "reschedule" | "birthdays" | "charges", string][] = [["reminders", "Lembretes"], ["reschedule", "Remarcações"], ["birthdays", "Aniversariantes"]];
  if (professionalId && user.role !== "reception") opts.push(["charges", "Cobranças"]);
  return (
    <div className="grid gap-4">
      <PageHeader title="Comunicação" subtitle="Mensagens pelo WhatsApp com texto pronto. Nada é enviado sozinho: você revisa e envia." />
      <div className="scroll-x -mx-4 px-4 sm:mx-0 sm:px-0"><Segmented value={tab} onChange={setTab} options={opts} /></div>
      {tab === "reminders" && <Reminders />}
      {tab === "reschedule" && <RescheduleRequests />}
      {tab === "birthdays" && <Birthdays />}
      {tab === "charges" && <Charges />}
    </div>
  );
}
