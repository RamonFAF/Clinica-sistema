import { useMemo, useRef, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Link, useParams } from "react-router-dom";
import { AlertTriangle, ArrowLeft, Download, EyeOff, FileText, FileUp, Lock, Package, Paperclip, Pencil, Plus, Printer,
  Reply, Users, X } from "lucide-react";
import { api, del, get, post, put } from "../lib/api";
import { useMe } from "../lib/auth";
import { PAYMENT_METHODS, STATUS, age, brl, fmtDate, fmtDateTime } from "../lib/format";
import { useProfessionals } from "../lib/queries";
import type { Appointment, Attachment, Patient, RecordEntry, RecordTemplate, SessionPackage } from "../lib/types";
import { PatientForm } from "../components/PatientForm";
import { RecordForm, RecordView } from "../components/RecordForm";
import { Avatar, Badge, Button, Card, Empty, ErrorBox, Field, Input, PageHeader, Segmented, Select, Sheet, Spinner, Textarea,
  Toggle, cx, toast } from "../components/ui";

const useTemplates = () => useQuery({ queryKey: ["templates"], queryFn: () => get<RecordTemplate[]>("/patients/templates"), staleTime: Infinity });

function NewEntry({ patient, parent, initialTemplate, onDone }: { patient: Patient; parent?: RecordEntry | null; initialTemplate?: string | null; onDone: () => void }) {
  const qc = useQueryClient();
  const { data: templates } = useTemplates();
  const [tplKey, setTplKey] = useState<string>(parent ? "" : initialTemplate ?? "");
  const tpl = templates?.find((t) => t.key === tplKey);
  const [data, setData] = useState<Record<string, any>>({});
  const [text, setText] = useState("");
  const [title, setTitle] = useState(parent ? `Adendo ao registro de ${fmtDateTime(parent.created_at)}` : "");
  const [privateEntry, setPrivate] = useState<boolean | null>(null);
  const isPrivate = privateEntry ?? (tpl ? tpl.visibility === "private" : false);
  const save = useMutation({
    mutationFn: () => post(`/patients/${patient.id}/records`, tpl
      ? { kind: "form", template: tpl.key, data, title: title || null, visibility: isPrivate ? "private" : "team" }
      : { kind: parent ? "addendum" : "note", content: text, title: title || null, parent_id: parent?.id ?? null, visibility: isPrivate ? "private" : "team" }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["records", patient.id] }); toast("Registro salvo"); onDone(); },
  });
  const groups = useMemo(() => {
    const g: Record<string, RecordTemplate[]> = {};
    templates?.forEach((t) => (g[t.area] ??= []).push(t));
    return g;
  }, [templates]);
  return (
    <Card className="border-brand/40">
      <div className="grid gap-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h3 className="font-semibold">{parent ? "Adendo" : tpl ? tpl.name : "Novo registro"}</h3>
          {!parent && (
            <Select className="h-10 w-auto min-w-[260px]" value={tplKey} onChange={(e) => { setTplKey(e.target.value); setData({}); setPrivate(null); }}>
              <option value="">Texto livre</option>
              {Object.entries(groups).map(([area, list]) => (
                <optgroup key={area} label={area}>{list.map((t) => <option key={t.key} value={t.key}>{t.name}</option>)}</optgroup>
              ))}
            </Select>
          )}
        </div>
        {tpl?.hint && <p className="rounded-xl bg-info-soft px-3 py-2 text-sm text-info">{tpl.hint}</p>}
        <Input placeholder={tpl ? `Título (padrão: ${tpl.name})` : "Título (opcional), ex.: Sessão 5"} value={title} onChange={(e) => setTitle(e.target.value)} />
        {tpl ? <RecordForm template={tpl} value={data} onChange={setData} />
          : <Textarea rows={7} placeholder="Descreva o atendimento…" value={text} onChange={(e) => setText(e.target.value)} autoFocus />}
        {!parent && (
          <div className="rounded-xl bg-sunk p-3">
            <Toggle checked={isPrivate} onChange={setPrivate} label="Registro privado (só eu vejo)"
              hint={isPrivate ? "Outros profissionais da equipe não verão este registro." :
                patient.consent_shared ? "Visível para a equipe de cuidado do paciente." : "O paciente não autorizou prontuário compartilhado: por enquanto só você verá."} />
          </div>
        )}
        <p className="flex items-center gap-1.5 text-xs text-muted"><Lock className="h-3.5 w-3.5" />Depois de salvo, o registro não pode ser editado nem apagado. Para corrigir, adicione um adendo.</p>
        <ErrorBox error={save.error} />
        <div className="flex justify-end gap-2">
          <Button onClick={onDone}>Cancelar</Button>
          <Button variant="primary" loading={save.isPending} onClick={() => save.mutate()}>Salvar registro</Button>
        </div>
      </div>
    </Card>
  );
}

function Records({ patient }: { patient: Patient }) {
  const { professionalId } = useMe();
  const { data: templates } = useTemplates();
  const [writing, setWriting] = useState<false | { parent?: RecordEntry; template?: string }>(false);
  const [filter, setFilter] = useState("");
  const { data, isLoading, error } = useQuery({ queryKey: ["records", patient.id], queryFn: () => get<{ entries: RecordEntry[]; hidden: number; shared_consent: boolean }>(`/patients/${patient.id}/records`) });
  if (error) return <Card><Empty icon={<Lock className="h-8 w-8" />} title="Prontuário restrito" text="Somente os profissionais da equipe de cuidado do paciente veem o prontuário." /></Card>;
  const entries = (data?.entries ?? []).filter((e) => !filter || e.template === filter || (filter === "free" && !e.template));
  const byId = new Map((data?.entries ?? []).map((e) => [e.id, e]));
  const frequent = templates?.filter((t) => t.frequent) ?? [];
  return (
    <div className="grid gap-3">
      {writing ? <NewEntry patient={patient} parent={writing.parent} initialTemplate={writing.template} onDone={() => setWriting(false)} /> : (
        <div className="flex flex-wrap items-center gap-2">
          <Button variant="primary" onClick={() => setWriting({})}><Plus className="h-4 w-4" />Novo registro</Button>
          {frequent.map((t) => <Button key={t.key} size="md" onClick={() => setWriting({ template: t.key })}>{t.name}</Button>)}
          <Select className="ml-auto h-10 w-auto" value={filter} onChange={(e) => setFilter(e.target.value)}>
            <option value="">Todos os registros</option><option value="free">Texto livre</option>
            {templates?.map((t) => <option key={t.key} value={t.key}>{t.name}</option>)}
          </Select>
        </div>
      )}
      {data && data.hidden > 0 && (
        <p className="flex items-center gap-2 rounded-xl bg-sunk px-3 py-2 text-sm text-muted"><EyeOff className="h-4 w-4" />
          {data.hidden} registro(s) de outros profissionais não aparecem para você ({data.shared_consent ? "privados" : "o paciente não autorizou prontuário compartilhado"}).</p>
      )}
      {isLoading ? <Spinner /> : !entries.length ? (
        <Card><Empty icon={<FileText className="h-8 w-8" />} title="Nenhum registro" text="Comece pela anamnese geral ou registre a evolução do atendimento." /></Card>
      ) : entries.map((e) => {
        const tpl = templates?.find((t) => t.key === e.template);
        return (
          <article key={e.id} className={cx("rounded-2xl border bg-surface p-4 shadow-card sm:p-5", e.kind === "addendum" ? "ml-4 border-warn/40 sm:ml-8" : "border-line")}>
            <header className="mb-3 flex flex-wrap items-start justify-between gap-2">
              <div className="grid gap-1">
                <div className="flex flex-wrap items-center gap-2">
                  <Badge tone={e.kind === "addendum" ? "warn" : e.template ? "info" : "brand"}>{e.template_name ?? (e.kind === "addendum" ? "Adendo" : e.kind === "soap" ? "SOAP" : "Evolução")}</Badge>
                  {e.title && e.title !== e.template_name && <span className="font-semibold">{e.title}</span>}
                  {e.visibility === "private" && <Badge tone="muted"><Lock className="h-3 w-3" />Privado</Badge>}
                </div>
                <span className="text-xs text-muted">{e.author}{e.author_specialty ? ` · ${e.author_specialty}` : ""}{e.professional_id === professionalId ? " (você)" : ""}</span>
              </div>
              <span className="text-xs text-muted">{fmtDateTime(e.created_at)}</span>
            </header>
            {e.alerts.length > 0 && <p className="mb-3 flex items-center gap-2 rounded-xl bg-bad-soft px-3 py-2 text-sm font-semibold text-bad"><AlertTriangle className="h-4 w-4" />{e.alerts.join(" · ")}</p>}
            {e.parent_id && byId.get(e.parent_id) && <p className="mb-1 text-xs text-muted">Corrige o registro de {fmtDateTime(byId.get(e.parent_id)!.created_at)}</p>}
            {tpl && e.data ? <RecordView template={tpl} data={e.data} /> : <p className="whitespace-pre-wrap text-[15px] leading-relaxed">{e.content}</p>}
            {e.kind !== "addendum" && (
              <button onClick={() => setWriting({ parent: e })} className="mt-3 inline-flex items-center gap-1 text-xs font-semibold text-muted hover:text-brand"><Reply className="h-3.5 w-3.5" />Adicionar adendo</button>
            )}
          </article>
        );
      })}
    </div>
  );
}

function Attachments({ patient }: { patient: Patient }) {
  const qc = useQueryClient();
  const ref = useRef<HTMLInputElement>(null);
  const [priv, setPriv] = useState(false);
  const { data, isLoading, error } = useQuery({ queryKey: ["attachments", patient.id], queryFn: () => get<Attachment[]>(`/patients/${patient.id}/attachments`) });
  const send = useMutation({
    mutationFn: async (file: File) => {
      const form = new FormData(); form.append("file", file); form.append("visibility", priv ? "private" : "team");
      return api(`/patients/${patient.id}/attachments`, { method: "POST", form });
    },
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["attachments", patient.id] }); toast("Arquivo anexado"); },
  });
  if (error) return <Card><Empty icon={<Lock className="h-8 w-8" />} title="Anexos restritos" text="Somente a equipe de cuidado vê os anexos." /></Card>;
  return (
    <div className="grid gap-3">
      <Card>
        <div className="flex flex-wrap items-center gap-3">
          <input ref={ref} type="file" hidden accept="application/pdf,image/jpeg,image/png,image/webp" onChange={(e) => { const f = e.target.files?.[0]; if (f) send.mutate(f); e.target.value = ""; }} />
          <Button variant="primary" loading={send.isPending} onClick={() => ref.current?.click()}><FileUp className="h-4 w-4" />Anexar exame ou documento</Button>
          <Toggle checked={priv} onChange={setPriv} label="Privado (só eu)" />
          <p className="w-full text-xs text-muted">PDF, JPG, PNG ou WebP até 15 MB. Os arquivos ficam cifrados no servidor.</p>
          <ErrorBox error={send.error} />
        </div>
      </Card>
      <Card className="p-0 sm:p-0">
        {isLoading ? <Spinner /> : !data?.length ? <Empty icon={<Paperclip className="h-8 w-8" />} title="Nenhum anexo" /> : (
          <ul className="divide-y divide-line">
            {data.map((a) => (
              <li key={a.id}>
                <a href={`/api/patients/${patient.id}/attachments/${a.id}`} target="_blank" rel="noopener" className="flex items-center gap-3 px-4 py-3 hover:bg-sunk/60 sm:px-5">
                  <Paperclip className="h-5 w-5 text-brand" />
                  <span className="min-w-0 flex-1"><span className="block truncate font-medium">{a.filename}</span>
                    <span className="text-xs text-muted">{(a.size / 1024).toFixed(0)} KB · {a.author} · {fmtDateTime(a.created_at)}</span></span>
                  {a.visibility === "private" && <Badge><Lock className="h-3 w-3" />Privado</Badge>}
                </a>
              </li>
            ))}
          </ul>
        )}
      </Card>
    </div>
  );
}

function Packages({ patient }: { patient: Patient }) {
  const qc = useQueryClient();
  const { isStaff, professionalId } = useMe();
  const { data: pros } = useProfessionals();
  const { data, isLoading } = useQuery({ queryKey: ["packages", patient.id], queryFn: () => get<SessionPackage[]>(`/packages?patient_id=${patient.id}`) });
  const [form, setForm] = useState<any>(null);
  const save = useMutation({
    mutationFn: () => {
      const body = { ...form, patient_id: patient.id, sessions_total: Number(form.sessions_total), price: Number(form.price), professional_id: form.professional_id ? Number(form.professional_id) : null };
      return form.id ? put(`/packages/${form.id}`, body) : post("/packages", body);
    },
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["packages"] }); toast("Pacote salvo"); setForm(null); },
  });
  return (
    <div className="grid gap-3">
      <Button variant="primary" className="justify-self-start" onClick={() => setForm({ name: "Pacote 10 sessões", sessions_total: 10, price: 1500, paid: false, payment_method: "", active: true, professional_id: isStaff ? "" : professionalId })}>
        <Plus className="h-4 w-4" />Novo pacote</Button>
      <Card className="p-0 sm:p-0">
        {isLoading ? <Spinner /> : !data?.length ? <Empty icon={<Package className="h-8 w-8" />} title="Nenhum pacote" text="Venda pacotes de sessões pagos de uma vez; cada consulta marcada no pacote desconta uma sessão." /> : (
          <ul className="divide-y divide-line">
            {data.map((k) => (
              <li key={k.id} className="flex flex-wrap items-center gap-3 px-4 py-3 sm:px-5">
                <div className="min-w-0 flex-1">
                  <p className="font-semibold">{k.name} {!k.active && <Badge>encerrado</Badge>}</p>
                  <p className="text-xs text-muted">{pros?.find((p) => p.id === k.professional_id)?.name} · {brl(k.price)} · usadas {k.used} de {k.sessions_total}</p>
                  <div className="mt-1.5 h-1.5 w-48 overflow-hidden rounded-full bg-sunk"><div className="h-full rounded-full bg-brand" style={{ width: `${(k.used / k.sessions_total) * 100}%` }} /></div>
                </div>
                <Badge tone={k.paid ? "ok" : "warn"}>{k.paid ? "Pago" : "A receber"}</Badge>
                {k.paid && <a className="text-sm font-semibold text-brand" href={`/api/finance/receipt/package/${k.id}.pdf`} target="_blank" rel="noopener">Recibo</a>}
                <Button size="sm" onClick={() => setForm({ ...k })}>Editar</Button>
              </li>
            ))}
          </ul>
        )}
      </Card>
      <Sheet open={!!form} onClose={() => setForm(null)} title={form?.id ? "Editar pacote" : "Novo pacote"}
        footer={<><Button onClick={() => setForm(null)}>Cancelar</Button><Button variant="primary" loading={save.isPending} onClick={() => save.mutate()}>Salvar</Button></>}>
        {form && (
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Nome" className="sm:col-span-2"><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></Field>
            {isStaff && !form.id && <Field label="Profissional" className="sm:col-span-2"><Select value={form.professional_id} onChange={(e) => setForm({ ...form, professional_id: e.target.value })}>
              <option value="">Selecione…</option>{pros?.filter((p) => p.attends).map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}</Select></Field>}
            <Field label="Sessões"><Input type="number" min={1} value={form.sessions_total} onChange={(e) => setForm({ ...form, sessions_total: e.target.value })} /></Field>
            <Field label="Valor total (R$)"><Input type="number" step="0.01" value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} /></Field>
            <div className="sm:col-span-2"><Toggle checked={form.paid} onChange={(v) => setForm({ ...form, paid: v })} label="Pago" /></div>
            {form.paid && <Field label="Forma de pagamento"><Select value={form.payment_method ?? ""} onChange={(e) => setForm({ ...form, payment_method: e.target.value })}>
              <option value="">—</option>{PAYMENT_METHODS.map((m) => <option key={m}>{m}</option>)}</Select></Field>}
            {form.id && <div className="sm:col-span-2"><Toggle checked={form.active} onChange={(v) => setForm({ ...form, active: v })} label="Pacote ativo" /></div>}
            <div className="sm:col-span-2"><ErrorBox error={save.error} /></div>
          </div>
        )}
      </Sheet>
    </div>
  );
}

function TeamCard({ patient }: { patient: Patient }) {
  const qc = useQueryClient();
  const { isStaff, professionalId } = useMe();
  const { data: pros } = useProfessionals();
  const [adding, setAdding] = useState("");
  const canEdit = isStaff || patient.professional_id === professionalId;
  const refresh = (p: Patient) => qc.setQueryData(["patient", patient.id], p);
  const add = useMutation({ mutationFn: (id: number) => post<Patient>(`/patients/${patient.id}/team`, { professional_id: id }), onSuccess: (p) => { refresh(p); setAdding(""); toast("Profissional adicionado à equipe"); } });
  const remove = useMutation({ mutationFn: (id: number) => del<Patient>(`/patients/${patient.id}/team/${id}`), onSuccess: refresh });
  const members = [patient.professional_id, ...(patient.team ?? [])];
  return (
    <Card title={<span className="flex items-center gap-2"><Users className="h-4 w-4 text-brand" />Equipe de cuidado</span>}>
      <div className="flex flex-wrap items-center gap-2">
        {members.map((id) => {
          const p = pros?.find((x) => x.id === id);
          if (!p) return null;
          return (
            <span key={id} className="inline-flex items-center gap-2 rounded-full border border-line py-1 pl-1 pr-3 text-sm">
              <Avatar name={p.name} url={p.photo_url} color={p.color} size={26} />
              <span><b>{p.name.split(" ")[0]}</b> <span className="text-muted">· {p.specialty}{id === patient.professional_id ? " · responsável" : ""}</span></span>
              {canEdit && id !== patient.professional_id && <button aria-label="Remover" onClick={() => remove.mutate(id)} className="text-muted hover:text-bad"><X className="h-3.5 w-3.5" /></button>}
            </span>
          );
        })}
        {canEdit && (
          <Select className="h-9 w-auto text-sm" value={adding} onChange={(e) => { setAdding(e.target.value); if (e.target.value) add.mutate(Number(e.target.value)); }}>
            <option value="">+ Adicionar profissional</option>
            {pros?.filter((p) => p.attends && p.is_active && !members.includes(p.id)).map((p) => <option key={p.id} value={p.id}>{p.name} · {p.specialty}</option>)}
          </Select>
        )}
      </div>
      {!patient.consent_shared && <p className="mt-3 text-xs text-warn">O paciente ainda não autorizou prontuário compartilhado: cada profissional vê só os próprios registros.</p>}
    </Card>
  );
}

export function PatientDetailPage() {
  const { id } = useParams();
  const pid = Number(id);
  const { professionalId } = useMe();
  const { data: pros } = useProfessionals();
  const [tab, setTab] = useState<"records" | "attachments" | "appointments" | "packages" | "data">("records");
  const [editing, setEditing] = useState(false);
  const patient = useQuery({ queryKey: ["patient", pid], queryFn: () => get<Patient>(`/patients/${pid}`) });
  const appts = useQuery({ queryKey: ["patient-appts", pid], queryFn: () => get<Appointment[]>(`/patients/${pid}/appointments`), enabled: tab === "appointments" });
  if (patient.isLoading) return <Spinner />;
  if (!patient.data) return <ErrorBox error={patient.error} />;
  const p = patient.data;
  const inCare = p.professional_id === professionalId || (p.team ?? []).includes(professionalId ?? -1);
  const pr = pros?.find((x) => x.id === p.professional_id);
  const a = age(p.birth_date);

  async function exportData() {
    const data = await get(`/patients/${pid}/export`);
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = `paciente-${p.record_number}.json`;
    link.click();
    URL.revokeObjectURL(link.href);
  }

  return (
    <div className="grid gap-4">
      <Link to="/pacientes" className="inline-flex items-center gap-1 text-sm font-semibold text-muted hover:text-ink"><ArrowLeft className="h-4 w-4" />Pacientes</Link>
      <div className="flex flex-wrap items-center gap-4">
        <Avatar name={p.name} size={56} color="rgb(var(--indigo))" />
        <div className="min-w-0 flex-1">
          <PageHeader title={p.name} subtitle={[`Prontuário nº ${p.record_number}`, a != null && `${a} anos`, p.phone, pr && `Responsável: ${pr.name}`].filter(Boolean).join(" · ")} />
        </div>
        <div className="flex flex-wrap gap-2">
          {inCare && <a href={`/api/patients/${pid}/record.pdf`} target="_blank" rel="noopener"><Button><Printer className="h-4 w-4" />PDF</Button></a>}
          {inCare && <Button onClick={exportData}><Download className="h-4 w-4" />Exportar</Button>}
          <Button onClick={() => setEditing(true)}><Pencil className="h-4 w-4" />Editar</Button>
        </div>
      </div>
      <div className="flex flex-wrap gap-2">
        {p.notes && <Badge tone="bad"><AlertTriangle className="h-3 w-3" />{p.notes.slice(0, 80)}</Badge>}
        <Badge tone={p.consent_care ? "ok" : "warn"}>{p.consent_care ? "Termo assinado" : "Sem termo de consentimento"}</Badge>
        {p.consent_shared && <Badge tone="ok">Prontuário compartilhado</Badge>}
        {p.consent_whatsapp && <Badge tone="ok">Aceita WhatsApp</Badge>}
        {p.insurance && <Badge>{p.insurance}</Badge>}
      </div>
      <TeamCard patient={p} />
      <div className="scroll-x -mx-4 px-4 sm:mx-0 sm:px-0">
        <Segmented value={tab} onChange={setTab} options={[["records", "Prontuário"], ["attachments", "Anexos"], ["appointments", "Consultas"], ["packages", "Pacotes"], ["data", "Dados"]]} />
      </div>
      {tab === "records" && <Records patient={p} />}
      {tab === "attachments" && <Attachments patient={p} />}
      {tab === "packages" && <Packages patient={p} />}
      {tab === "appointments" && (
        <Card className="p-0 sm:p-0">
          {appts.isLoading ? <Spinner /> : !appts.data?.length ? <Empty title="Nenhuma consulta" /> : (
            <ul className="divide-y divide-line">
              {appts.data.map((x) => (
                <li key={x.id} className="flex flex-wrap items-center gap-3 px-4 py-3 text-sm sm:px-5">
                  <span className="tabular w-28 font-semibold">{fmtDate(x.date)} {x.start}</span>
                  <span className="flex-1 text-muted">{pros?.find((q) => q.id === x.professional_id)?.name} · {x.online ? "Online" : "Presencial"} · {x.package_id ? "pacote" : brl(x.price)} {x.paid && !x.package_id && "· pago"}</span>
                  <Badge tone={STATUS[x.status].tone}>{STATUS[x.status].label}</Badge>
                  {["done", "confirmed"].includes(x.status) && <a className="text-xs font-semibold text-brand" href={`/api/appointments/${x.id}/attendance.pdf`} target="_blank" rel="noopener">Declaração</a>}
                </li>
              ))}
            </ul>
          )}
        </Card>
      )}
      {tab === "data" && (
        <Card>
          <dl className="grid gap-x-6 gap-y-3 text-sm sm:grid-cols-2">
            {[["Nome", p.name], ["Prontuário nº", p.record_number], ["Nascimento", fmtDate(p.birth_date)], ["Sexo", p.sex], ["Estado civil", p.marital_status],
              ["CPF", p.cpf], ["RG", p.rg], ["Profissão", p.occupation], ["Endereço", p.address], ["WhatsApp", p.phone], ["E-mail", p.email],
              ["Convênio", p.insurance], ["Responsável", p.guardian], ["Consentimentos em", fmtDateTime(p.consent_at)], ["Cadastrado em", fmtDateTime(p.created_at)],
              ["Alertas", inCare ? p.notes : "Restrito à equipe de cuidado"]]
              .map(([k, v]) => <div key={k as string}><dt className="text-xs text-muted">{k}</dt><dd className="font-medium">{v || "—"}</dd></div>)}
          </dl>
        </Card>
      )}
      <PatientForm open={editing} patient={p} onClose={() => setEditing(false)} />
    </div>
  );
}
