import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { get } from "../lib/api";
import { fmtDateTime } from "../lib/format";
import { Card, Empty, PageHeader, Select, Spinner } from "../components/ui";

interface Row { id: number; at: string; user: string | null; action: string; entity: string | null; entity_id: number | null; ip: string | null; detail: string | null }

const LABELS: Record<string, string> = {
  login: "Entrou", login_failed: "Senha errada", login_blocked: "Login bloqueado", logout: "Saiu", mfa_ok: "2FA confirmado", mfa_failed: "Código 2FA errado",
  mfa_enabled: "Ativou 2FA", mfa_reset: "2FA removido", password_changed: "Trocou a senha", password_reset: "Senha redefinida",
  patient_created: "Cadastrou paciente", patient_updated: "Alterou paciente", patient_viewed: "Abriu paciente", patient_exported: "Exportou dados do paciente",
  record_viewed: "Abriu prontuário", record_created: "Registrou no prontuário", appointment_created: "Marcou consulta", appointment_updated: "Alterou consulta",
  appointment_deleted: "Excluiu consulta", reservation_created: "Reservou sala", reservation_updated: "Alterou reserva", reservation_deleted: "Excluiu reserva",
  professional_created: "Cadastrou membro da equipe", professional_updated: "Alterou membro da equipe", settings_updated: "Alterou configurações",
  room_created: "Criou sala", room_updated: "Alterou sala", room_deleted: "Excluiu sala", room_deactivated: "Desativou sala", room_count_set: "Mudou quantidade de salas",
  invoice_paid: "Fatura paga", invoice_unpaid: "Desfez pagamento de fatura", photo_updated: "Trocou foto", logo_updated: "Trocou logo", session_revoked: "Encerrou sessão",
  profile_updated: "Alterou perfil",
};

export function AuditPage() {
  const [action, setAction] = useState("");
  const { data, isLoading } = useQuery({ queryKey: ["audit", action], queryFn: () => get<Row[]>(`/audit?limit=300${action ? `&action=${action}` : ""}`) });
  return (
    <div className="grid gap-4">
      <PageHeader title="Auditoria" subtitle="Quem fez o quê, quando e de onde (LGPD art. 37)."
        actions={<Select className="h-10 w-auto" value={action} onChange={(e) => setAction(e.target.value)}>
          <option value="">Todas as ações</option>
          {Object.entries(LABELS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
        </Select>} />
      <Card className="p-0 sm:p-0">
        {isLoading ? <Spinner /> : !data?.length ? <Empty title="Nenhum registro" /> : (
          <div className="scroll-x">
            <table className="w-full min-w-[700px] text-sm">
              <thead><tr className="border-b border-line text-left text-xs text-muted">
                <th className="px-5 py-2 font-medium">Quando</th><th className="font-medium">Usuário</th><th className="font-medium">Ação</th><th className="font-medium">Detalhe</th><th className="px-5 font-medium">IP</th>
              </tr></thead>
              <tbody>
                {data.map((r) => (
                  <tr key={r.id} className="border-b border-line last:border-0">
                    <td className="tabular px-5 py-2.5 text-muted">{fmtDateTime(r.at)}</td>
                    <td className="font-medium">{r.user ?? "—"}</td>
                    <td className={r.action.includes("failed") || r.action.includes("blocked") ? "text-bad" : ""}>{LABELS[r.action] ?? r.action}</td>
                    <td className="max-w-[280px] truncate text-muted">{[r.entity && `${r.entity} #${r.entity_id}`, r.detail].filter(Boolean).join(" · ")}</td>
                    <td className="tabular px-5 text-muted">{r.ip}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </div>
  );
}
