import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { ListTodo, MessageCircle, Plus, Trash2 } from "lucide-react";
import { del, get, post, put } from "../lib/api";
import { useMe } from "../lib/auth";
import { fmtDate, whatsappLink } from "../lib/format";
import { useProfessionals, useSettings } from "../lib/queries";
import type { WaitItem } from "../lib/types";
import { Badge, Button, Card, Empty, ErrorBox, Field, Input, PageHeader, Segmented, Select, Sheet, Spinner, Textarea, toast } from "../components/ui";

const ST: Record<WaitItem["status"], [string, "warn" | "info" | "ok" | "muted"]> = {
  waiting: ["Aguardando", "warn"], contacted: ["Contatado", "info"], scheduled: ["Agendado", "ok"], gave_up: ["Desistiu", "muted"],
};

export function WaitlistPage() {
  const qc = useQueryClient();
  const { isStaff } = useMe();
  const { data: pros } = useProfessionals();
  const { data: settings } = useSettings();
  const [status, setStatus] = useState<WaitItem["status"]>("waiting");
  const [form, setForm] = useState<any>(null);
  const { data, isLoading } = useQuery({ queryKey: ["waitlist", status], queryFn: () => get<WaitItem[]>(`/waitlist?status=${status}`) });
  const refresh = () => qc.invalidateQueries({ queryKey: ["waitlist"] });
  const save = useMutation({
    mutationFn: () => { const b = { ...form, professional_id: form.professional_id ? Number(form.professional_id) : null };
      return form.id ? put(`/waitlist/${form.id}`, b) : post("/waitlist", b); },
    onSuccess: () => { refresh(); toast("Lista de espera atualizada"); setForm(null); },
  });
  const setSt = useMutation({ mutationFn: (w: WaitItem & { status: string }) => put(`/waitlist/${w.id}`, w), onSuccess: refresh });
  const remove = useMutation({ mutationFn: (id: number) => del(`/waitlist/${id}`), onSuccess: () => { refresh(); setForm(null); } });
  return (
    <div className="grid gap-4">
      <PageHeader title="Lista de espera" subtitle="Quem quer um horário que ainda não existe. Quando abrir vaga, chame pelo WhatsApp."
        actions={<Button variant="primary" onClick={() => setForm({ name: "", phone: "", specialty: "", preference: "", notes: "", status: "waiting", professional_id: "" })}><Plus className="h-4 w-4" />Adicionar</Button>} />
      <Segmented value={status} onChange={setStatus} options={Object.entries(ST).map(([k, v]) => [k as WaitItem["status"], v[0]])} />
      <Card className="p-0 sm:p-0">
        {isLoading ? <Spinner /> : !data?.length ? <Empty icon={<ListTodo className="h-8 w-8" />} title="Ninguém nesta situação" /> : (
          <ul className="divide-y divide-line">
            {data.map((w) => (
              <li key={w.id} className="flex flex-wrap items-center gap-3 px-4 py-3 sm:px-5">
                <button className="min-w-0 flex-1 text-left" onClick={() => setForm({ ...w, professional_id: w.professional_id ?? "" })}>
                  <span className="block truncate font-semibold">{w.name}</span>
                  <span className="block truncate text-xs text-muted">{[w.specialty, pros?.find((p) => p.id === w.professional_id)?.name, w.preference, `desde ${fmtDate(w.created_at)}`].filter(Boolean).join(" · ")}</span>
                </button>
                <Select className="h-9 w-36 text-sm" value={w.status} onChange={(e) => setSt.mutate({ ...w, status: e.target.value as WaitItem["status"] })}>
                  {Object.entries(ST).map(([k, v]) => <option key={k} value={k}>{v[0]}</option>)}
                </Select>
                {w.phone && <a href={whatsappLink(w.phone, `Olá, ${w.name.split(" ")[0]}! Aqui é da ${settings?.clinic_name ?? "clínica"}. Abriu um horário${w.specialty ? ` de ${w.specialty.toLowerCase()}` : ""}. Ainda tem interesse?`)}
                  target="_blank" rel="noopener noreferrer" onClick={() => w.status === "waiting" && setSt.mutate({ ...w, status: "contacted" })}
                  className="inline-flex h-8 items-center gap-1.5 rounded-xl bg-[#1f9e5a] px-3 text-[13px] font-semibold text-white"><MessageCircle className="h-4 w-4" />Chamar</a>}
                <Badge tone={ST[w.status][1]}>{ST[w.status][0]}</Badge>
              </li>
            ))}
          </ul>
        )}
      </Card>
      <Sheet open={!!form} onClose={() => setForm(null)} title={form?.id ? "Editar" : "Adicionar à lista de espera"}
        footer={<>{form?.id && <Button variant="ghost" className="mr-auto text-bad" onClick={() => remove.mutate(form.id)}><Trash2 className="h-4 w-4" />Excluir</Button>}
          <Button onClick={() => setForm(null)}>Cancelar</Button><Button variant="primary" loading={save.isPending} disabled={!form?.name} onClick={() => save.mutate()}>Salvar</Button></>}>
        {form && (
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Nome" className="sm:col-span-2"><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></Field>
            <Field label="WhatsApp"><Input inputMode="tel" value={form.phone ?? ""} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></Field>
            <Field label="Especialidade"><Input value={form.specialty ?? ""} onChange={(e) => setForm({ ...form, specialty: e.target.value })} placeholder="Psicologia, Nutrição…" /></Field>
            {isStaff && <Field label="Profissional (opcional)" className="sm:col-span-2"><Select value={form.professional_id} onChange={(e) => setForm({ ...form, professional_id: e.target.value })}>
              <option value="">Qualquer profissional</option>{pros?.filter((p) => p.attends).map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}</Select></Field>}
            <Field label="Preferência de dias e horários" className="sm:col-span-2"><Input value={form.preference ?? ""} onChange={(e) => setForm({ ...form, preference: e.target.value })} placeholder="Terças e quintas à tarde" /></Field>
            <Field label="Observações" className="sm:col-span-2"><Textarea rows={2} className="min-h-[64px]" value={form.notes ?? ""} onChange={(e) => setForm({ ...form, notes: e.target.value })} /></Field>
            <div className="sm:col-span-2"><ErrorBox error={save.error} /></div>
          </div>
        )}
      </Sheet>
    </div>
  );
}
