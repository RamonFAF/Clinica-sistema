import { useEffect, useRef, useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Camera, Copy, KeyRound, Plus, ShieldOff, Users } from "lucide-react";
import { post, put, upload } from "../lib/api";
import { useMe } from "../lib/auth";
import { BILLING_LABEL, ROLE_LABEL, brl, fmtDateTime } from "../lib/format";
import { useProfessionals } from "../lib/queries";
import type { Professional } from "../lib/types";
import { Avatar, Badge, Button, Card, Empty, ErrorBox, Field, Input, PageHeader, Select, Sheet, Spinner, Textarea, Toggle, toast } from "../components/ui";

const COLORS = ["#0f766e", "#2563eb", "#7c3aed", "#db2777", "#d97706", "#059669", "#4f46e5", "#0891b2", "#be123c", "#65a30d"];

function TempPassword({ value, onClose }: { value: string | null; onClose: () => void }) {
  return (
    <Sheet open={!!value} onClose={onClose} title="Senha provisória" footer={<Button variant="primary" onClick={onClose}>Pronto</Button>}>
      <div className="grid gap-3 text-sm">
        <p>Passe esta senha ao profissional por um canal seguro. Ela só aparece agora. No primeiro acesso, ele cria uma senha própria e ativa a verificação em duas etapas.</p>
        <div className="flex items-center gap-2 rounded-xl bg-sunk p-3">
          <code className="flex-1 select-all text-lg font-bold tracking-wide">{value}</code>
          <Button size="sm" onClick={() => navigator.clipboard?.writeText(value ?? "").then(() => toast("Copiado"))}><Copy className="h-4 w-4" />Copiar</Button>
        </div>
      </div>
    </Sheet>
  );
}

function ProfessionalSheet({ prof, open, onClose, onTemp }: { prof: Professional | null; open: boolean; onClose: () => void; onTemp: (s: string) => void }) {
  const qc = useQueryClient();
  const [f, setF] = useState<any>({});
  const fileRef = useRef<HTMLInputElement>(null);
  useEffect(() => {
    if (open) setF(prof ? { ...prof } : { name: "", email: "", role: "professional", council: "", specialty: "", phone: "", color: COLORS[Math.floor(Math.random() * COLORS.length)],
      billing_model: "hourly", monthly_fee: 0, percent: 0, bio: "", attends: true, is_active: true });
  }, [open, prof]);
  const refresh = () => qc.invalidateQueries({ queryKey: ["professionals"] });
  const save = useMutation({
    mutationFn: () => {
      const body = { ...f, monthly_fee: Number(f.monthly_fee) || 0, percent: Number(f.percent) || 0 };
      return prof ? put<Professional>(`/professionals/${prof.id}`, body) : post<Professional>("/professionals", body);
    },
    onSuccess: (p) => { refresh(); toast("Cadastro salvo"); if (p.temp_password) onTemp(p.temp_password); onClose(); },
  });
  const photo = useMutation({
    mutationFn: (file: File) => upload<Professional>(`/professionals/${prof!.id}/photo`, file),
    onSuccess: (p) => { setF({ ...f, photo_url: p.photo_url }); refresh(); toast("Foto atualizada"); },
  });
  const reset = useMutation({ mutationFn: () => post<{ temp_password: string }>(`/professionals/${prof!.id}/reset-password`), onSuccess: (r) => onTemp(r.temp_password) });
  const resetMfa = useMutation({ mutationFn: () => post(`/professionals/${prof!.id}/reset-mfa`), onSuccess: () => { refresh(); toast("2FA removido. Será configurado no próximo login.") } });
  const set = (k: string) => (e: any) => setF({ ...f, [k]: e?.target ? e.target.value : e });
  return (
    <Sheet open={open} onClose={onClose} title={prof ? "Editar cadastro" : "Novo membro da equipe"} wide
      footer={<><Button onClick={onClose}>Cancelar</Button><Button variant="primary" loading={save.isPending} disabled={!f.name || !f.email} onClick={() => save.mutate()}>Salvar</Button></>}>
      <div className="grid gap-4 sm:grid-cols-2">
        <div className="flex items-center gap-4 sm:col-span-2">
          <Avatar name={f.name || "?"} url={f.photo_url} color={f.color} size={72} />
          {prof ? (<>
            <input ref={fileRef} type="file" accept="image/jpeg,image/png,image/webp" hidden onChange={(e) => e.target.files?.[0] && photo.mutate(e.target.files[0])} />
            <Button loading={photo.isPending} onClick={() => fileRef.current?.click()}><Camera className="h-4 w-4" />Trocar foto</Button>
          </>) : <p className="text-sm text-muted">A foto pode ser enviada depois de salvar o cadastro.</p>}
        </div>
        <Field label="Nome completo"><Input value={f.name ?? ""} onChange={set("name")} /></Field>
        <Field label="E-mail de acesso"><Input type="email" value={f.email ?? ""} onChange={set("email")} /></Field>
        <Field label="Perfil de acesso">
          <Select value={f.role} onChange={(e) => setF({ ...f, role: e.target.value, attends: e.target.value === "professional" ? true : f.attends })}>
            <option value="professional">Profissional (vê só os próprios pacientes)</option>
            <option value="reception">Recepção (agenda e cadastros, sem prontuário)</option>
            <option value="admin">Administrador (gestão completa, sem prontuário de outros)</option>
          </Select>
        </Field>
        <Field label="Especialidade"><Input value={f.specialty ?? ""} onChange={set("specialty")} placeholder="Psicologia, Fisioterapia…" /></Field>
        <Field label="Conselho e registro"><Input value={f.council ?? ""} onChange={set("council")} placeholder="CRP 02/123456" /></Field>
        <Field label="CPF ou CNPJ (sai nos recibos)"><Input value={f.document ?? ""} onChange={set("document")} /></Field>
        <Field label="WhatsApp"><Input inputMode="tel" value={f.phone ?? ""} onChange={set("phone")} /></Field>
        <div className="grid gap-1.5 sm:col-span-2">
          <span className="text-[13px] font-medium text-muted">Cor na agenda</span>
          <div className="flex flex-wrap gap-2">
            {COLORS.map((c) => <button key={c} type="button" aria-label={c} onClick={() => setF({ ...f, color: c })}
              className="h-8 w-8 rounded-full ring-offset-2 ring-offset-surface" style={{ background: c, boxShadow: f.color === c ? `0 0 0 3px ${c}55` : undefined, outline: f.color === c ? `2px solid ${c}` : undefined }} />)}
          </div>
        </div>
        <div className="grid gap-3 rounded-2xl bg-sunk p-4 sm:col-span-2 sm:grid-cols-3">
          <p className="text-xs font-semibold uppercase tracking-wide text-muted sm:col-span-3">Cobrança da sala</p>
          <Field label="Modelo"><Select value={f.billing_model} onChange={set("billing_model")}>
            {Object.entries(BILLING_LABEL).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
          </Select></Field>
          {f.billing_model === "monthly" && <Field label="Valor mensal (R$)"><Input type="number" step="0.01" value={f.monthly_fee} onChange={set("monthly_fee")} /></Field>}
          {f.billing_model === "percent" && <Field label="Percentual (%)"><Input type="number" step="0.1" value={f.percent} onChange={set("percent")} /></Field>}
          {f.billing_model === "hourly" && <p className="self-end text-xs text-muted sm:col-span-2">Usa o valor por hora de cada sala reservada.</p>}
        </div>
        <Field label="Apresentação" className="sm:col-span-2"><Textarea rows={2} value={f.bio ?? ""} onChange={set("bio")} /></Field>
        <div className="grid gap-3 sm:col-span-2">
          <Toggle checked={!!f.attends} onChange={set("attends")} label="Atende pacientes" hint="Aparece na agenda, nas salas e no financeiro." />
          <Toggle checked={!!f.is_active} onChange={set("is_active")} label="Acesso ativo" hint="Desativar encerra as sessões abertas." />
        </div>
        {prof && (
          <div className="flex flex-wrap gap-2 sm:col-span-2">
            <Button loading={reset.isPending} onClick={() => reset.mutate()}><KeyRound className="h-4 w-4" />Gerar nova senha</Button>
            {prof.totp_enabled && <Button loading={resetMfa.isPending} onClick={() => resetMfa.mutate()}><ShieldOff className="h-4 w-4" />Remover 2FA (celular perdido)</Button>}
          </div>
        )}
        <div className="sm:col-span-2"><ErrorBox error={save.error || photo.error || reset.error} /></div>
      </div>
    </Sheet>
  );
}

export function TeamPage() {
  const { isAdmin } = useMe();
  const { data, isLoading } = useProfessionals();
  const [edit, setEdit] = useState<Professional | null>(null);
  const [open, setOpen] = useState(false);
  const [temp, setTemp] = useState<string | null>(null);
  return (
    <div className="grid gap-4">
      <PageHeader title="Equipe" subtitle="Profissionais, recepção e administradores"
        actions={isAdmin && <Button variant="primary" onClick={() => { setEdit(null); setOpen(true); }}><Plus className="h-4 w-4" />Adicionar</Button>} />
      {isLoading ? <Spinner /> : !data?.length ? <Card><Empty icon={<Users className="h-8 w-8" />} title="Nenhum cadastro" /></Card> : (
        <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
          {data.map((p) => (
            <button key={p.id} disabled={!isAdmin} onClick={() => { setEdit(p); setOpen(true); }}
              className="flex items-start gap-3 rounded-2xl border border-line bg-surface p-4 text-left shadow-card transition enabled:hover:border-brand/50">
              <Avatar name={p.name} url={p.photo_url} color={p.color} size={52} />
              <div className="min-w-0 flex-1">
                <p className="truncate font-semibold">{p.name}</p>
                <p className="truncate text-sm text-muted">{p.specialty || ROLE_LABEL[p.role]}{p.council ? ` · ${p.council}` : ""}</p>
                <div className="mt-2 flex flex-wrap gap-1.5">
                  <Badge tone={p.role === "admin" ? "info" : p.role === "reception" ? "muted" : "brand"}>{ROLE_LABEL[p.role]}</Badge>
                  {!p.is_active && <Badge tone="bad">Inativo</Badge>}
                  {isAdmin && p.totp_enabled === false && <Badge tone="warn">2FA pendente</Badge>}
                  {isAdmin && p.attends && p.billing_model && <Badge>{p.billing_model === "monthly" ? brl(p.monthly_fee) + "/mês" : p.billing_model === "percent" ? `${p.percent}%` : "por hora"}</Badge>}
                </div>
                {isAdmin && p.last_login_at && <p className="mt-2 text-xs text-muted">Último acesso {fmtDateTime(p.last_login_at)}</p>}
              </div>
            </button>
          ))}
        </div>
      )}
      <ProfessionalSheet prof={edit} open={open} onClose={() => setOpen(false)} onTemp={setTemp} />
      <TempPassword value={temp} onClose={() => setTemp(null)} />
    </div>
  );
}
