import { useEffect, useRef, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Camera, LogOut, Monitor, ShieldCheck } from "lucide-react";
import { del, get, post, put, upload } from "../lib/api";
import { useAuth, useMe } from "../lib/auth";
import { ROLE_LABEL, fmtDateTime } from "../lib/format";
import type { AuthState } from "../lib/types";
import { Avatar, Badge, Button, Card, ErrorBox, Field, Input, PageHeader, Textarea, toast } from "../components/ui";

export function ProfilePage() {
  const { user } = useMe();
  const { refresh, logout, setState } = useAuth();
  const qc = useQueryClient();
  const fileRef = useRef<HTMLInputElement>(null);
  const [phone, setPhone] = useState("");
  const [bio, setBio] = useState("");
  const [doc, setDoc] = useState("");
  const [pw, setPw] = useState({ current_password: "", new_password: "", again: "" });
  const me = useQuery({ queryKey: ["professionals"], queryFn: () => get<any[]>("/professionals") });
  const mine = me.data?.find((p) => p.id === user.professional_id);
  useEffect(() => { if (mine) { setPhone(mine.phone ?? ""); setBio(mine.bio ?? ""); setDoc(mine.document ?? ""); } }, [mine]);
  const sessions = useQuery({ queryKey: ["sessions"], queryFn: () => get<any[]>("/auth/sessions") });

  const photo = useMutation({ mutationFn: (f: File) => upload(`/professionals/${user.professional_id}/photo`, f), onSuccess: () => { refresh(); qc.invalidateQueries({ queryKey: ["professionals"] }); toast("Foto atualizada"); } });
  const profile = useMutation({ mutationFn: () => put("/professionals/me/profile", { phone, bio, document: doc }), onSuccess: () => { qc.invalidateQueries({ queryKey: ["professionals"] }); toast("Perfil salvo"); } });
  const password = useMutation({
    mutationFn: () => { if (pw.new_password !== pw.again) throw new Error("As senhas novas não são iguais."); return post<AuthState>("/auth/password", pw); },
    onSuccess: (s) => { setState(s); setPw({ current_password: "", new_password: "", again: "" }); qc.invalidateQueries({ queryKey: ["sessions"] }); toast("Senha alterada. Outras sessões foram encerradas."); },
  });
  const endSession = useMutation({ mutationFn: (id: number) => del(`/auth/sessions/${id}`), onSuccess: () => qc.invalidateQueries({ queryKey: ["sessions"] }) });

  return (
    <div className="grid gap-4">
      <PageHeader title="Meu perfil" subtitle={`${ROLE_LABEL[user.role]} · ${user.email}`} actions={<Button onClick={logout}><LogOut className="h-4 w-4" />Sair</Button>} />
      <div className="grid gap-4 lg:grid-cols-2">
        {user.professional_id && (
          <Card title="Dados pessoais">
            <div className="grid gap-4">
              <div className="flex items-center gap-4">
                <Avatar name={user.name} url={user.photo_url} color={user.color} size={80} />
                <input ref={fileRef} type="file" accept="image/jpeg,image/png,image/webp" hidden onChange={(e) => e.target.files?.[0] && photo.mutate(e.target.files[0])} />
                <div className="grid gap-1">
                  <Button loading={photo.isPending} onClick={() => fileRef.current?.click()}><Camera className="h-4 w-4" />Trocar foto</Button>
                  <span className="text-xs text-muted">JPG, PNG ou WebP até 5 MB.</span>
                </div>
              </div>
              <Field label="WhatsApp"><Input value={phone} onChange={(e) => setPhone(e.target.value)} /></Field>
              <Field label="CPF ou CNPJ (sai nos recibos)"><Input value={doc} onChange={(e) => setDoc(e.target.value)} /></Field>
              <Field label="Apresentação"><Textarea rows={3} value={bio} onChange={(e) => setBio(e.target.value)} /></Field>
              <ErrorBox error={photo.error || profile.error} />
              <Button variant="primary" className="justify-self-end" loading={profile.isPending} onClick={() => profile.mutate()}>Salvar</Button>
            </div>
          </Card>
        )}
        <Card title="Senha">
          <form className="grid gap-3" onSubmit={(e) => { e.preventDefault(); password.mutate(); }}>
            <Field label="Senha atual"><Input type="password" autoComplete="current-password" value={pw.current_password} onChange={(e) => setPw({ ...pw, current_password: e.target.value })} /></Field>
            <Field label="Nova senha"><Input type="password" autoComplete="new-password" value={pw.new_password} onChange={(e) => setPw({ ...pw, new_password: e.target.value })} /></Field>
            <Field label="Repita a nova senha"><Input type="password" autoComplete="new-password" value={pw.again} onChange={(e) => setPw({ ...pw, again: e.target.value })} /></Field>
            <ErrorBox error={password.error} />
            <Button variant="primary" className="justify-self-end" loading={password.isPending}>Alterar senha</Button>
          </form>
        </Card>
        <Card title="Verificação em duas etapas">
          <div className="flex items-center gap-3">
            <ShieldCheck className={user.totp_enabled ? "h-8 w-8 text-ok" : "h-8 w-8 text-warn"} />
            <div>
              <p className="font-semibold">{user.totp_enabled ? "Ativa" : "Não ativada"}</p>
              <p className="text-sm text-muted">{user.totp_enabled ? "Se trocar ou perder o celular, peça ao administrador para remover e configure de novo." : "Ative para proteger sua conta."}</p>
            </div>
          </div>
        </Card>
        <Card title="Sessões abertas">
          <ul className="grid gap-2">
            {sessions.data?.map((s) => (
              <li key={s.id} className="flex items-center gap-3 rounded-xl border border-line p-3 text-sm">
                <Monitor className="h-5 w-5 shrink-0 text-muted" />
                <div className="min-w-0 flex-1">
                  <p className="truncate font-medium">{(s.user_agent || "Navegador").replace(/\(.*?\)/g, "").slice(0, 60)}</p>
                  <p className="text-xs text-muted">{s.ip} · ativo {fmtDateTime(s.last_seen_at)}</p>
                </div>
                {s.current ? <Badge tone="ok">Esta</Badge> : <Button size="sm" onClick={() => endSession.mutate(s.id)}>Encerrar</Button>}
              </li>
            ))}
          </ul>
        </Card>
      </div>
    </div>
  );
}
