import { useEffect, useRef, useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Building2, Clock, DoorOpen, ImageUp, MessageCircle, Plus, ShieldCheck, Trash2 } from "lucide-react";
import { del, post, put, upload } from "../lib/api";
import { WEEKDAYS, brl } from "../lib/format";
import { useRooms, useSettings } from "../lib/queries";
import type { Room, Settings } from "../lib/types";
import { Button, Card, ErrorBox, Field, Input, PageHeader, Sheet, Spinner, Textarea, Toggle, cx, toast } from "../components/ui";

function RoomSheet({ room, onClose }: { room: Partial<Room> | null; onClose: () => void }) {
  const qc = useQueryClient();
  const [f, setF] = useState<any>({});
  useEffect(() => { if (room) setF({ name: "", resources: "", area_m2: 0, hourly_rate: 40, active: true, sort_order: 0, ...room }); }, [room]);
  const done = (m: string) => { qc.invalidateQueries({ queryKey: ["rooms"] }); toast(m); onClose(); };
  const save = useMutation({
    mutationFn: () => { const b = { ...f, area_m2: Number(f.area_m2) || 0, hourly_rate: Number(f.hourly_rate) || 0, sort_order: Number(f.sort_order) || 0 };
      return room?.id ? put(`/rooms/${room.id}`, b) : post("/rooms", b); },
    onSuccess: () => done("Sala salva"),
  });
  const remove = useMutation({ mutationFn: () => del<{ result: string }>(`/rooms/${room!.id}`), onSuccess: (r) => done(r.result === "deleted" ? "Sala excluída" : "Sala desativada (tem histórico)") });
  const set = (k: string) => (e: any) => setF({ ...f, [k]: e?.target ? e.target.value : e });
  return (
    <Sheet open={!!room} onClose={onClose} title={room?.id ? "Editar sala" : "Nova sala"}
      footer={<>{room?.id && <Button variant="ghost" className="mr-auto text-bad" loading={remove.isPending} onClick={() => remove.mutate()}><Trash2 className="h-4 w-4" />Excluir</Button>}
        <Button onClick={onClose}>Cancelar</Button><Button variant="primary" loading={save.isPending} onClick={() => save.mutate()}>Salvar</Button></>}>
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="Nome" className="sm:col-span-2"><Input value={f.name ?? ""} onChange={set("name")} /></Field>
        <Field label="Recursos" className="sm:col-span-2"><Input value={f.resources ?? ""} onChange={set("resources")} placeholder="divã, maca, pia, balança…" /></Field>
        <Field label="Valor por hora (R$)"><Input type="number" step="0.01" value={f.hourly_rate} onChange={set("hourly_rate")} /></Field>
        <Field label="Área (m²)"><Input type="number" step="0.1" value={f.area_m2} onChange={set("area_m2")} /></Field>
        <Field label="Ordem na grade"><Input type="number" value={f.sort_order} onChange={set("sort_order")} /></Field>
        <div className="self-end"><Toggle checked={!!f.active} onChange={set("active")} label="Ativa" /></div>
        <div className="sm:col-span-2"><ErrorBox error={save.error || remove.error} /></div>
      </div>
    </Sheet>
  );
}

function Section({ icon: Icon, title, text, children }: { icon: typeof Clock; title: string; text?: string; children: React.ReactNode }) {
  return (
    <Card>
      <div className="mb-4 flex items-start gap-3">
        <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-brand-soft text-brand"><Icon className="h-5 w-5" /></span>
        <div><h2 className="font-semibold">{title}</h2>{text && <p className="text-sm text-muted">{text}</p>}</div>
      </div>
      {children}
    </Card>
  );
}

export function SettingsPage() {
  const qc = useQueryClient();
  const { data } = useSettings();
  const { data: rooms } = useRooms(true);
  const [f, setF] = useState<Settings | null>(null);
  const [count, setCount] = useState<number>(0);
  const [room, setRoom] = useState<Partial<Room> | null>(null);
  const logoRef = useRef<HTMLInputElement>(null);
  useEffect(() => { if (data) setF(data); }, [data]);
  useEffect(() => { if (rooms) setCount(rooms.filter((r) => r.active).length); }, [rooms]);

  const save = useMutation({
    mutationFn: () => put<Settings>("/settings", f),
    onSuccess: (s) => { qc.setQueryData(["settings"], s); qc.invalidateQueries({ queryKey: ["branding"] }); toast("Configurações salvas"); },
  });
  const setRooms = useMutation({ mutationFn: () => post("/rooms/set-count", { count }), onSuccess: () => { qc.invalidateQueries({ queryKey: ["rooms"] }); toast("Quantidade de salas atualizada"); } });
  const logo = useMutation({ mutationFn: (file: File) => upload("/settings/logo", file), onSuccess: () => { qc.invalidateQueries({ queryKey: ["branding"] }); qc.invalidateQueries({ queryKey: ["settings"] }); toast("Logo atualizada"); } });
  const removeLogo = useMutation({ mutationFn: () => del("/settings/logo"), onSuccess: () => { qc.invalidateQueries({ queryKey: ["branding"] }); qc.invalidateQueries({ queryKey: ["settings"] }); } });

  if (!f || !rooms) return <Spinner />;
  const set = (k: keyof Settings) => (e: any) => setF({ ...f, [k]: e?.target ? e.target.value : e });
  const num = (k: keyof Settings) => (e: any) => setF({ ...f, [k]: e.target.value === "" ? "" : Number(e.target.value) });
  const dayToggle = (d: number) => setF({ ...f, open_weekdays: f.open_weekdays.includes(d) ? f.open_weekdays.filter((x) => x !== d) : [...f.open_weekdays, d].sort() });

  return (
    <div className="grid gap-4 pb-20">
      <PageHeader title="Configurações" subtitle="Tudo o que muda o funcionamento da clínica" />

      <Section icon={Building2} title="Clínica" text="Nome, contato e logo exibidos no sistema.">
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Nome"><Input value={f.clinic_name} onChange={set("clinic_name")} /></Field>
          <Field label="Subtítulo"><Input value={f.clinic_tagline} onChange={set("clinic_tagline")} /></Field>
          <Field label="Telefone"><Input value={f.clinic_phone} onChange={set("clinic_phone")} /></Field>
          <Field label="Endereço"><Input value={f.clinic_address} onChange={set("clinic_address")} /></Field>
          <Field label="Cidade (para datas em documentos)"><Input value={f.clinic_city} onChange={set("clinic_city")} /></Field>
          <Field label="CNPJ"><Input value={f.clinic_document} onChange={set("clinic_document")} /></Field>
          <Field label="Rodapé dos documentos (prontuário e recibos)" className="sm:col-span-2"><Input value={f.record_footer} onChange={set("record_footer")} /></Field>
          <div className="flex flex-wrap items-center gap-3 sm:col-span-2">
            {data?.logo_url ? <img src={data.logo_url} alt="Logo" className="h-16 rounded-lg border border-line bg-white object-contain p-1" />
              : <span className="text-sm text-muted">Nenhuma logo enviada.</span>}
            <input ref={logoRef} type="file" accept="image/png,image/jpeg,image/webp" hidden onChange={(e) => e.target.files?.[0] && logo.mutate(e.target.files[0])} />
            <Button loading={logo.isPending} onClick={() => logoRef.current?.click()}><ImageUp className="h-4 w-4" />Enviar logo</Button>
            {data?.logo_url && <Button variant="ghost" onClick={() => removeLogo.mutate()}>Remover</Button>}
            <ErrorBox error={logo.error} />
          </div>
        </div>
      </Section>

      <Section icon={DoorOpen} title="Salas" text="Quantidade, nomes, recursos e valor por hora.">
        <div className="mb-4 flex flex-wrap items-end gap-3">
          <Field label="Quantidade de salas ativas"><Input id="room-count" type="number" min={0} max={200} className="w-32" value={count} onChange={(e) => setCount(Number(e.target.value))} /></Field>
          <Button loading={setRooms.isPending} onClick={() => setRooms.mutate()}>Aplicar</Button>
          <Button variant="ghost" onClick={() => setRoom({})}><Plus className="h-4 w-4" />Sala personalizada</Button>
        </div>
        <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
          {rooms.map((r) => (
            <button key={r.id} onClick={() => setRoom(r)} className={cx("rounded-xl border p-3 text-left transition hover:border-brand/50", r.active ? "border-line" : "border-dashed border-line opacity-60")}>
              <p className="font-semibold">{r.name} {!r.active && <span className="text-xs font-normal text-muted">(inativa)</span>}</p>
              <p className="truncate text-xs text-muted">{r.resources || "sem recursos cadastrados"}</p>
              <p className="mt-1 text-sm font-semibold text-brand">{brl(r.hourly_rate)}/h{r.area_m2 ? ` · ${r.area_m2} m²` : ""}</p>
            </button>
          ))}
        </div>
      </Section>

      <Section icon={Clock} title="Funcionamento e agenda">
        <div className="grid gap-4 sm:grid-cols-3">
          <Field label="Abre às"><Input type="time" value={f.open_time} onChange={set("open_time")} /></Field>
          <Field label="Fecha às"><Input type="time" value={f.close_time} onChange={set("close_time")} /></Field>
          <Field label="Intervalo da grade (min)"><Input type="number" value={f.slot_minutes} onChange={num("slot_minutes")} /></Field>
          <div className="grid gap-1.5 sm:col-span-3">
            <span className="text-[13px] font-medium text-muted">Dias de funcionamento</span>
            <div className="flex flex-wrap gap-2">
              {WEEKDAYS.map((w, i) => (
                <button key={w} onClick={() => dayToggle(i)} className={cx("h-10 w-14 rounded-xl border text-sm font-semibold", f.open_weekdays.includes(i) ? "brand-gradient border-transparent text-white" : "border-line text-muted")}>{w}</button>
              ))}
            </div>
          </div>
          <Field label="Duração padrão da consulta (min)"><Input type="number" value={f.default_session_minutes} onChange={num("default_session_minutes")} /></Field>
          <Field label="Valor padrão da consulta (R$)"><Input type="number" step="0.01" value={f.default_price} onChange={num("default_price")} /></Field>
          <Field label="Valor padrão de sala nova (R$/h)"><Input type="number" step="0.01" value={f.default_room_rate} onChange={num("default_room_rate")} /></Field>
          <Field label="Cancelamento sem custo até (horas antes)"><Input type="number" value={f.cancel_hours} onChange={num("cancel_hours")} /></Field>
          <Field label="Vencimento da fatura (dia do mês)"><Input type="number" min={1} max={28} value={f.invoice_due_day} onChange={num("invoice_due_day")} /></Field>
          <div className="grid gap-3 sm:col-span-3">
            <Toggle checked={f.professionals_can_book_rooms} onChange={set("professionals_can_book_rooms")} label="Profissionais podem reservar salas" hint="Se desligado, só a administração e a recepção reservam." />
            <Toggle checked={f.require_room_for_in_person} onChange={set("require_room_for_in_person")} label="Consulta presencial exige sala reservada" />
          </div>
        </div>
      </Section>

      <Section icon={MessageCircle} title="Mensagens do WhatsApp" text="Textos prontos. As variáveis entre chaves são trocadas automaticamente.">
        <div className="grid gap-4">
          <Field label="Lembrete de consulta" hint="{paciente}, {profissional}, {data}, {hora}, {clinica}, {link} (link para o paciente confirmar ou pedir remarcação)">
            <Textarea rows={3} value={f.whatsapp_template} onChange={set("whatsapp_template")} /></Field>
          <Field label="Cobrança" hint="{paciente}, {valor}, {itens}, {profissional}, {clinica}">
            <Textarea rows={3} value={f.whatsapp_charge_template} onChange={set("whatsapp_charge_template")} /></Field>
          <Field label="Aniversário" hint="{paciente}, {clinica}">
            <Textarea rows={2} className="min-h-[64px]" value={f.whatsapp_birthday_template} onChange={set("whatsapp_birthday_template")} /></Field>
        </div>
      </Section>

      <Section icon={ShieldCheck} title="Segurança" text="Regras de acesso de todos os usuários.">
        <div className="grid gap-4 sm:grid-cols-2">
          <div className="sm:col-span-2"><Toggle checked={f.mfa_required} onChange={set("mfa_required")} label="Verificação em duas etapas obrigatória" hint="Recomendado: prontuários são dados sensíveis (LGPD art. 11)." /></div>
          <Field label="Encerrar sessão após inatividade (min)"><Input type="number" value={f.session_idle_minutes} onChange={num("session_idle_minutes")} /></Field>
          <Field label="Tamanho mínimo da senha"><Input type="number" min={8} value={f.min_password_length} onChange={num("min_password_length")} /></Field>
          <Field label="Tentativas de senha antes do bloqueio"><Input type="number" min={3} value={f.max_failed_logins} onChange={num("max_failed_logins")} /></Field>
          <Field label="Tempo de bloqueio (min)"><Input type="number" min={1} value={f.lockout_minutes} onChange={num("lockout_minutes")} /></Field>
        </div>
      </Section>

      <div className="fixed inset-x-0 bottom-16 z-20 border-t border-line bg-surface/95 px-4 py-3 backdrop-blur lg:bottom-0 lg:left-[260px]">
        <div className="mx-auto flex max-w-[1280px] items-center justify-end gap-3">
          <ErrorBox error={save.error} />
          <Button onClick={() => data && setF(data)}>Descartar</Button>
          <Button variant="primary" loading={save.isPending} onClick={() => save.mutate()}>Salvar configurações</Button>
        </div>
      </div>
      <RoomSheet room={room} onClose={() => setRoom(null)} />
    </div>
  );
}
