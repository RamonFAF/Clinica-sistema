import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useParams } from "react-router-dom";
import { CalendarCheck, CalendarClock, CheckCircle2, MapPin, Video } from "lucide-react";
import { get, post } from "../lib/api";
import { fmtDayLong } from "../lib/format";
import { Button, ErrorBox, Spinner } from "../components/ui";

interface Info {
  clinic_name: string; clinic_phone: string; clinic_address: string; logo_url: string | null; patient_first_name: string;
  professional: string; specialty: string | null; date: string; start: string; end: string; online: boolean; status: string;
  patient_response: "confirmed" | "reschedule" | null; can_answer: boolean;
}

/** Página pública que o paciente abre pelo link do WhatsApp. Não exige login e não mostra dado clínico. */
export function ConfirmPage() {
  const { token } = useParams();
  const q = useQuery({ queryKey: ["public-appt", token], queryFn: () => get<Info>(`/public/appointment/${token}`), retry: false });
  const [info, setInfo] = useState<Info | null>(null);
  const [busy, setBusy] = useState<string>("");
  const [error, setError] = useState<unknown>(null);
  const d = info ?? q.data;
  async function answer(kind: "confirm" | "reschedule") {
    setBusy(kind); setError(null);
    try { setInfo(await post<Info>(`/public/appointment/${token}/${kind}`)); } catch (e) { setError(e); } finally { setBusy(""); }
  }
  return (
    <div className="flex min-h-full items-center justify-center bg-bg px-5 py-10">
      <div className="w-full max-w-sm">
        <div className="mx-auto mb-6 w-fit rounded-3xl bg-white p-3">
          <img src={d?.logo_url ?? "/logo-full.png"} alt={d?.clinic_name ?? "NeuroInsight"} className="h-28 w-auto object-contain" />
        </div>
        {q.isLoading ? <Spinner /> : !d ? (
          <div className="rounded-2xl border border-line bg-surface p-6 text-center shadow-card">
            <p className="font-semibold">Link inválido ou expirado</p>
            <p className="mt-1 text-sm text-muted">Fale com a clínica pelo WhatsApp para confirmar ou remarcar.</p>
          </div>
        ) : (
          <div className="grid gap-4 rounded-2xl border border-line bg-surface p-6 shadow-card">
            <p className="text-lg font-bold">Olá, {d.patient_first_name}!</p>
            <div className="grid gap-2 rounded-xl bg-sunk p-4 text-[15px]">
              <p className="flex items-center gap-2 font-semibold"><CalendarClock className="h-5 w-5 text-brand" />{fmtDayLong(d.date)}</p>
              <p className="pl-7 text-2xl font-bold tabular">{d.start}</p>
              <p className="pl-7 text-muted">com {d.professional}{d.specialty ? ` · ${d.specialty}` : ""}</p>
              <p className="flex items-center gap-2 text-sm text-muted">{d.online ? <><Video className="h-4 w-4" />Atendimento on-line</> : <><MapPin className="h-4 w-4" />{d.clinic_address}</>}</p>
            </div>
            {d.patient_response === "confirmed" || d.status === "confirmed" ? (
              <p className="flex items-center gap-2 rounded-xl bg-ok-soft p-3 font-semibold text-ok"><CheckCircle2 className="h-5 w-5" />Presença confirmada. Até lá!</p>
            ) : null}
            {d.patient_response === "reschedule" && (
              <p className="rounded-xl bg-warn-soft p-3 text-sm font-medium text-warn">Pedido de remarcação enviado. A clínica vai falar com você pelo WhatsApp.</p>
            )}
            {d.can_answer && d.patient_response !== "reschedule" && (
              <div className="grid gap-2">
                {d.status !== "confirmed" && <Button variant="primary" size="lg" loading={busy === "confirm"} onClick={() => answer("confirm")}><CalendarCheck className="h-5 w-5" />Confirmar presença</Button>}
                <Button size="lg" loading={busy === "reschedule"} onClick={() => answer("reschedule")}>Preciso remarcar</Button>
              </div>
            )}
            {!d.can_answer && <p className="text-sm text-muted">Esta consulta não pode mais ser alterada por aqui.</p>}
            <ErrorBox error={error} />
            {d.clinic_phone && <p className="text-center text-xs text-muted">{d.clinic_name} · {d.clinic_phone}</p>}
          </div>
        )}
      </div>
    </div>
  );
}
