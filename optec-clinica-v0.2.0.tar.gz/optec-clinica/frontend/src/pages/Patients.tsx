import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { ChevronRight, Plus, Search, UserRound } from "lucide-react";
import { get } from "../lib/api";
import { useMe } from "../lib/auth";
import { age } from "../lib/format";
import { useProfessionals } from "../lib/queries";
import type { Patient } from "../lib/types";
import { PatientForm } from "../components/PatientForm";
import { Avatar, Badge, Button, Card, Empty, Input, PageHeader, Segmented, Select, Spinner } from "../components/ui";

export function PatientsPage() {
  const { isStaff } = useMe();
  const { data: pros } = useProfessionals();
  const [q, setQ] = useState("");
  const [prof, setProf] = useState("");
  const [archived, setArchived] = useState<"0" | "1">("0");
  const [open, setOpen] = useState(false);
  const { data, isLoading } = useQuery({
    queryKey: ["patients", q, prof, archived],
    queryFn: () => get<Patient[]>(`/patients?archived=${archived === "1"}${q ? `&q=${encodeURIComponent(q)}` : ""}${prof ? `&professional_id=${prof}` : ""}`),
  });
  const profName = (id: number) => pros?.find((p) => p.id === id);
  return (
    <div className="grid gap-4">
      <PageHeader title="Pacientes" subtitle={isStaff ? "Todos os pacientes da clínica" : "Seus pacientes"}
        actions={<Button variant="primary" onClick={() => setOpen(true)}><Plus className="h-4 w-4" />Paciente</Button>} />
      <div className="flex flex-wrap gap-2">
        <div className="relative min-w-[220px] flex-1">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted" />
          <Input id="search" className="pl-9" placeholder="Buscar por nome ou telefone" value={q} onChange={(e) => setQ(e.target.value)} />
        </div>
        {isStaff && <Select className="w-auto" value={prof} onChange={(e) => setProf(e.target.value)}>
          <option value="">Todos os profissionais</option>
          {pros?.filter((p) => p.attends).map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
        </Select>}
        <Segmented value={archived} onChange={setArchived} options={[["0", "Ativos"], ["1", "Arquivados"]]} />
      </div>
      <Card className="p-0 sm:p-0">
        {isLoading ? <Spinner /> : !data?.length ? (
          <Empty icon={<UserRound className="h-8 w-8" />} title="Nenhum paciente encontrado" text="Cadastre o primeiro paciente para marcar consultas e abrir o prontuário." />
        ) : (
          <ul className="divide-y divide-line">
            {data.map((p) => {
              const pr = profName(p.professional_id);
              const a = age(p.birth_date);
              return (
                <li key={p.id}>
                  <Link to={`/pacientes/${p.id}`} className="flex items-center gap-3 px-4 py-3 hover:bg-sunk/60 sm:px-5">
                    <Avatar name={p.name} size={40} color="rgb(var(--indigo))" />
                    <div className="min-w-0 flex-1">
                      <p className="truncate font-semibold">{p.name}</p>
                      <p className="truncate text-xs text-muted">{[a != null && `${a} anos`, p.phone, isStaff && pr?.name].filter(Boolean).join(" · ")}</p>
                    </div>
                    {!p.consent_care && <Badge tone="warn">sem consentimento</Badge>}
                    <ChevronRight className="h-4 w-4 text-muted" />
                  </Link>
                </li>
              );
            })}
          </ul>
        )}
      </Card>
      <PatientForm open={open} onClose={() => setOpen(false)} />
    </div>
  );
}
