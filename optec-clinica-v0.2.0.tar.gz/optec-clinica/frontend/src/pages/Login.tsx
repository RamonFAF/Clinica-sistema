import { useState, type FormEvent } from "react";
import { useQuery } from "@tanstack/react-query";
import { KeyRound, ShieldCheck, Smartphone } from "lucide-react";
import { post } from "../lib/api";
import { useAuth } from "../lib/auth";
import type { AuthState } from "../lib/types";
import { Logo } from "../components/Logo";
import { Button, ErrorBox, Field, Input } from "../components/ui";

function Shell({ children }: { children: React.ReactNode }) {
  return (
    <div className="grid min-h-full lg:grid-cols-[1.1fr_1fr]">
      <div className="relative hidden overflow-hidden brand-gradient lg:block">
        <div className="absolute inset-0 opacity-20" style={{ backgroundImage: "radial-gradient(circle at 20% 30%, white 0, transparent 40%), radial-gradient(circle at 80% 70%, white 0, transparent 35%)" }} />
        <div className="relative flex h-full flex-col justify-end p-12 text-white">
          <p className="max-w-md text-3xl font-bold leading-tight">Agenda, salas, prontuário e financeiro da clínica em um só lugar.</p>
          <p className="mt-3 max-w-md text-white/80">Cada profissional acessa apenas os próprios pacientes. Prontuários cifrados e acesso com verificação em duas etapas.</p>
        </div>
      </div>
      <div className="flex items-center justify-center px-5 py-10">
        <div className="w-full max-w-sm">
          <Logo className="mb-8 justify-center" />
          {children}
        </div>
      </div>
    </div>
  );
}

export function LoginPage() {
  const { setState } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<unknown>(null);
  const [busy, setBusy] = useState(false);
  async function submit(e: FormEvent) {
    e.preventDefault();
    setBusy(true); setError(null);
    try { setState(await post<AuthState>("/auth/login", { email, password })); }
    catch (err) { setError(err); }
    finally { setBusy(false); }
  }
  return (
    <Shell>
      <form onSubmit={submit} className="grid gap-4">
        <div>
          <h1 className="text-xl font-bold">Entrar</h1>
          <p className="text-sm text-muted">Use o e-mail cadastrado pela clínica.</p>
        </div>
        <Field label="E-mail"><Input id="email" type="email" autoComplete="username" required value={email} onChange={(e) => setEmail(e.target.value)} /></Field>
        <Field label="Senha"><Input id="password" type="password" autoComplete="current-password" required value={password} onChange={(e) => setPassword(e.target.value)} /></Field>
        <ErrorBox error={error} />
        <Button variant="primary" size="lg" loading={busy}>Entrar</Button>
        <p className="text-center text-xs text-muted">Esqueceu a senha? Peça ao administrador da clínica para gerar uma nova.</p>
      </form>
    </Shell>
  );
}

function CodeInput({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  return (
    <Input id="code" inputMode="numeric" autoComplete="one-time-code" maxLength={6} autoFocus placeholder="000000"
      className="h-14 text-center text-2xl font-bold tracking-[0.5em]" value={value}
      onChange={(e) => onChange(e.target.value.replace(/\D/g, "").slice(0, 6))} />
  );
}

export function MfaPage() {
  const { setState, logout } = useAuth();
  const [code, setCode] = useState("");
  const [error, setError] = useState<unknown>(null);
  const [busy, setBusy] = useState(false);
  async function submit(e: FormEvent) {
    e.preventDefault(); setBusy(true); setError(null);
    try { setState(await post<AuthState>("/auth/mfa", { code })); } catch (err) { setError(err); setCode(""); } finally { setBusy(false); }
  }
  return (
    <Shell>
      <form onSubmit={submit} className="grid gap-4">
        <div className="flex items-center gap-3">
          <span className="grid h-11 w-11 place-items-center rounded-xl bg-brand-soft text-brand"><Smartphone className="h-5 w-5" /></span>
          <div><h1 className="text-xl font-bold">Verificação</h1><p className="text-sm text-muted">Digite o código do app autenticador.</p></div>
        </div>
        <CodeInput value={code} onChange={setCode} />
        <ErrorBox error={error} />
        <Button variant="primary" size="lg" loading={busy} disabled={code.length !== 6}>Verificar</Button>
        <Button type="button" variant="ghost" onClick={logout}>Usar outra conta</Button>
      </form>
    </Shell>
  );
}

export function ChangePasswordPage() {
  const { setState, logout } = useAuth();
  const [cur, setCur] = useState("");
  const [n1, setN1] = useState("");
  const [n2, setN2] = useState("");
  const [error, setError] = useState<unknown>(null);
  const [busy, setBusy] = useState(false);
  async function submit(e: FormEvent) {
    e.preventDefault();
    if (n1 !== n2) { setError(new Error("As senhas novas não são iguais.")); return; }
    setBusy(true); setError(null);
    try { setState(await post<AuthState>("/auth/password", { current_password: cur, new_password: n1 })); } catch (err) { setError(err); } finally { setBusy(false); }
  }
  return (
    <Shell>
      <form onSubmit={submit} className="grid gap-4">
        <div className="flex items-center gap-3">
          <span className="grid h-11 w-11 place-items-center rounded-xl bg-brand-soft text-brand"><KeyRound className="h-5 w-5" /></span>
          <div><h1 className="text-xl font-bold">Crie sua senha</h1><p className="text-sm text-muted">Troque a senha provisória por uma só sua.</p></div>
        </div>
        <Field label="Senha provisória"><Input type="password" autoComplete="current-password" required value={cur} onChange={(e) => setCur(e.target.value)} /></Field>
        <Field label="Nova senha" hint="Mínimo de 10 caracteres, com letras e números."><Input type="password" autoComplete="new-password" required value={n1} onChange={(e) => setN1(e.target.value)} /></Field>
        <Field label="Repita a nova senha"><Input type="password" autoComplete="new-password" required value={n2} onChange={(e) => setN2(e.target.value)} /></Field>
        <ErrorBox error={error} />
        <Button variant="primary" size="lg" loading={busy}>Salvar senha</Button>
        <Button type="button" variant="ghost" onClick={logout}>Sair</Button>
      </form>
    </Shell>
  );
}

export function MfaSetupPage() {
  const { setState, logout } = useAuth();
  const setup = useQuery({ queryKey: ["mfa-setup"], queryFn: () => post<{ secret: string; qr: string }>("/auth/mfa/setup"), staleTime: Infinity, retry: false });
  const [code, setCode] = useState("");
  const [error, setError] = useState<unknown>(null);
  const [busy, setBusy] = useState(false);
  async function submit(e: FormEvent) {
    e.preventDefault(); setBusy(true); setError(null);
    try { setState(await post<AuthState>("/auth/mfa/enable", { code })); } catch (err) { setError(err); } finally { setBusy(false); }
  }
  return (
    <Shell>
      <form onSubmit={submit} className="grid gap-4">
        <div className="flex items-center gap-3">
          <span className="grid h-11 w-11 place-items-center rounded-xl bg-brand-soft text-brand"><ShieldCheck className="h-5 w-5" /></span>
          <div><h1 className="text-xl font-bold">Verificação em duas etapas</h1><p className="text-sm text-muted">Obrigatória para proteger os dados dos pacientes.</p></div>
        </div>
        <ol className="grid gap-1 text-sm text-muted">
          <li>1. Instale o Google Authenticator, Microsoft Authenticator ou similar.</li>
          <li>2. Escaneie o QR abaixo (ou digite a chave).</li>
          <li>3. Digite o código de 6 dígitos que aparecer.</li>
        </ol>
        {setup.data ? (
          <div className="grid justify-items-center gap-2 rounded-2xl border border-line bg-white p-4">
            <img src={setup.data.qr} alt="QR code para o app autenticador" className="h-48 w-48" />
            <code className="select-all break-all text-center text-xs text-[#1e1b4b]">{setup.data.secret}</code>
          </div>
        ) : <ErrorBox error={setup.error} />}
        <CodeInput value={code} onChange={setCode} />
        <ErrorBox error={error} />
        <Button variant="primary" size="lg" loading={busy} disabled={code.length !== 6}>Ativar</Button>
        <Button type="button" variant="ghost" onClick={logout}>Sair</Button>
      </form>
    </Shell>
  );
}
