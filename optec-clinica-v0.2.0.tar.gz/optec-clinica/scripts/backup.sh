#!/bin/sh
# Backup do banco e das fotos/logo. Uso: sh scripts/backup.sh   (guarda em ./backups, mantém 30 dias)
# Sugestão de cron diário às 2h:  0 2 * * * cd /opt/optec-clinica && sh scripts/backup.sh >/dev/null 2>&1
set -e
cd "$(dirname "$0")/.."
mkdir -p backups && chmod 700 backups
TS=$(date +%Y%m%d-%H%M%S)
docker compose exec -T db pg_dump -U clinica -d clinica -Fc > "backups/db-$TS.dump"
docker compose exec -T app tar -C /data -czf - uploads > "backups/uploads-$TS.tar.gz"
find backups -type f -mtime +30 -delete
echo "Backup salvo: backups/db-$TS.dump e backups/uploads-$TS.tar.gz"
echo "Lembrete: o backup do banco é inútil sem a ENCRYPTION_KEY do .env."
