#!/bin/sh
# Atualiza para a versão desta pasta (faz backup antes). Uso: sh scripts/update.sh
set -e
cd "$(dirname "$0")/.."
sh scripts/backup.sh
APP_VERSION=$(cat VERSION) docker compose up -d --build
docker image prune -f >/dev/null
echo "Atualizado para a versão $(cat VERSION)."
