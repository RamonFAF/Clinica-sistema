#!/bin/sh
set -e
# Aplica as migrações do banco antes de subir a API.
alembic upgrade head
exec uvicorn app.main:app --host 0.0.0.0 --port 8000 --workers "${WEB_WORKERS:-2}" \
  --proxy-headers --forwarded-allow-ips="*" --no-server-header
