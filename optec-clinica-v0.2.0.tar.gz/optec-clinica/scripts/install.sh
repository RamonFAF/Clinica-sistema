#!/bin/sh
# Primeira instalação no Debian 12. Rode de dentro da pasta do projeto: sudo sh scripts/install.sh
set -e
cd "$(dirname "$0")/.."
if ! command -v docker >/dev/null 2>&1; then
  echo "Docker não encontrado. Instale com:  curl -fsSL https://get.docker.com | sh"; exit 1
fi
if [ ! -f .env ]; then
  DBP=$(head -c 32 /dev/urandom | base64 | tr -dc 'A-Za-z0-9' | head -c 32)
  KEY=$(head -c 32 /dev/urandom | base64 | tr '+/' '-_')
  sed -e "s|^DB_PASSWORD=.*|DB_PASSWORD=$DBP|" -e "s|^ENCRYPTION_KEY=.*|ENCRYPTION_KEY=$KEY|" .env.example > .env
  chmod 600 .env
  echo ">> .env criado com senha do banco e chave de cifragem aleatórias."
  echo ">> FAÇA UMA CÓPIA DO .env EM LOCAL SEGURO (fora do servidor)."
fi
docker compose up -d --build
echo ">> Aguardando a aplicação..."
for i in $(seq 1 30); do
  if curl -fsS http://127.0.0.1:$(grep ^APP_PORT .env | cut -d= -f2)/api/health >/dev/null 2>&1; then echo ">> OK: aplicação no ar."; break; fi
  sleep 2
done
echo ""
echo "Próximo passo: crie o administrador:"
echo "  docker compose exec app python -m app.cli create-admin --email SEU@EMAIL --name \"Seu Nome\""
