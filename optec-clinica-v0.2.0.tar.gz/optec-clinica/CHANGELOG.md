# Histórico de versões

## v0.2.0 — fase 2

**Prontuário multiprofissional (modelo NeuroInsight)**
- Prontuário único com **equipe de cuidado** (responsável + profissionais que atendem). Agendar um paciente com outro
  profissional o inclui automaticamente na equipe.
- Visibilidade por registro: **equipe** (exige o consentimento "prontuário compartilhado") ou **privado** (só o autor).
  Registros da v0.1 viraram privados na migração.
- **Modelos estruturados**: anamnese geral, avaliação psicológica (PHQ-9, GAD-7, risco), avaliação nutricional,
  terapias corporais (EVA, contraindicações), avaliação fisioterapêutica (COFFITO 414/2012), PTI por área,
  evolução SOAP, sessão de psicoterapia (nasce privada — CFP 01/2009), evolução de fisioterapia, alta/encaminhamento.
- Alertas automáticos (ideação/plano suicida, contraindicações).
- **Anexos** (PDF/imagens até 15 MB) cifrados no disco.
- **PDF do prontuário** no layout da clínica; identificação completa do paciente (sexo, estado civil, RG, profissão,
  endereço, convênio, responsável) e os 4 consentimentos do termo.

**Financeiro**
- Clínica: visão geral (faturado, recebido, despesas, resultado, 6 meses), despesas por categoria e recorrentes,
  vencimento e atraso de faturas, descontos/acréscimos, detalhe das reservas, recibo de locação, exportação CSV.
- Profissional: pacotes de sessões, despesas próprias, a receber por paciente, recebido por forma de pagamento,
  gráfico de 6 meses, recibo por consulta/pacote/mês, exportação CSV.

**Comunicação sem API de WhatsApp**
- Link de confirmação por consulta (`/c/…`): o paciente confirma ou pede remarcação sem login; a agenda atualiza.
- Tela Comunicação: lembretes do dia seguinte com envio em um toque, pedidos de remarcação, aniversariantes e cobranças.
- Mensagens editáveis em Configurações (lembrete, cobrança, aniversário).

**Outros**
- Lista de espera, declaração de comparecimento em PDF, CPF/CNPJ do profissional nos recibos, logo oficial.
- Testes recusam qualquer banco que não termine em `_test` (proteção contra apagar produção).

## v0.1.0 — fase 1
Salas, reservas, equipe com foto, pacientes, prontuário cifrado, agenda, financeiro básico, 2FA, auditoria.
